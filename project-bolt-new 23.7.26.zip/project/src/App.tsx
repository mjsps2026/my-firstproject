import { useState, useEffect } from 'react';
import { Sidebar, MobileNav, TopBar } from './components/Layout';
import { ADMIN_NAV, TEACHER_NAV, STUDENT_NAV } from './constants';
import type { Role, StudentRow } from './types';
import { useStudents } from './lib/hooks';

import AdminOverview from './pages/admin/AdminOverview';
import TeacherManagement from './pages/admin/TeacherManagement';
import StudentManagement from './pages/admin/StudentManagement';
import ClassManagement from './pages/admin/ClassManagement';
import AnnouncementAdmin from './pages/admin/AnnouncementAdmin';
import TuitionManagement from './pages/admin/TuitionManagement';

import TeacherOverview from './pages/teacher/TeacherOverview';
import SmartAttendance from './pages/teacher/SmartAttendance';
import GradingSystem from './pages/teacher/GradingSystem';
import BehaviorTracking from './pages/teacher/BehaviorTracking';
import AnnouncementView from './pages/teacher/AnnouncementView';

import StudentOverview from './pages/student/StudentOverview';
import StudentProfile from './pages/student/StudentProfile';
import StudentAttendance from './pages/student/StudentAttendance';
import StudentSchedule from './pages/student/StudentSchedule';
import ReportCard from './pages/student/ReportCard';
import StudentTuition from './pages/student/StudentTuition';

export default function App() {
  const [role, setRole] = useState<Role>('admin');
  const [activeNav, setActiveNav] = useState('overview');
  const [selectedStudentId, setSelectedStudentId] = useState<string>('');
  const { students } = useStudents();

  useEffect(() => {
    setActiveNav('overview');
  }, [role]);

  useEffect(() => {
    if (students.length > 0 && !selectedStudentId) {
      setSelectedStudentId(students[0].id);
    }
  }, [students, selectedStudentId]);

  const selectedStudent: StudentRow | undefined = students.find((s) => s.id === selectedStudentId);

  const nav = role === 'admin' ? ADMIN_NAV : role === 'teacher' ? TEACHER_NAV : STUDENT_NAV;

  const renderPage = () => {
    if (role === 'admin') {
      switch (activeNav) {
        case 'overview': return <AdminOverview />;
        case 'teachers': return <TeacherManagement />;
        case 'students': return <StudentManagement />;
        case 'classes': return <ClassManagement />;
        case 'announcements': return <AnnouncementAdmin />;
        case 'tuition': return <TuitionManagement />;
        default: return <AdminOverview />;
      }
    }
    if (role === 'teacher') {
      switch (activeNav) {
        case 'overview': return <TeacherOverview />;
        case 'attendance': return <SmartAttendance />;
        case 'grading': return <GradingSystem />;
        case 'behavior': return <BehaviorTracking />;
        case 'announcements': return <AnnouncementView role="teacher" />;
        default: return <TeacherOverview />;
      }
    }
    if (!selectedStudent) return <div className="p-8 text-center text-ink-400">ກຳລັງໂຫຼດຂໍ້ມູນ...</div>;
    switch (activeNav) {
      case 'overview': return <StudentOverview student={selectedStudent} />;
      case 'profile': return <StudentProfile student={selectedStudent} />;
      case 'attendance': return <StudentAttendance student={selectedStudent} />;
      case 'schedule': return <StudentSchedule student={selectedStudent} />;
      case 'report': return <ReportCard student={selectedStudent} />;
      case 'tuition': return <StudentTuition student={selectedStudent} />;
      default: return <StudentOverview student={selectedStudent} />;
    }
  };

  const studentSelector = role === 'student' && students.length > 0 ? (
    <select
      value={selectedStudentId}
      onChange={(e) => setSelectedStudentId(e.target.value)}
      className="px-3 py-2 rounded-lg border border-ink-200 text-sm bg-white max-w-[200px] sm:max-w-xs"
    >
      {students.map((s) => (
        <option key={s.id} value={s.id}>{s.full_name}</option>
      ))}
    </select>
  ) : undefined;

  return (
    <div className="min-h-screen flex bg-ink-50">
      <Sidebar role={role} nav={nav} active={activeNav} onNavigate={setActiveNav} />
      <div className="flex-1 min-w-0 flex flex-col">
        <MobileNav role={role} nav={nav} active={activeNav} onNavigate={setActiveNav} />
        <TopBar role={role} onRoleChange={setRole} studentSelector={studentSelector} />
        <main className="flex-1 p-4 md:p-6 animate-fade-in">
          {renderPage()}
        </main>
      </div>
    </div>
  );
}
