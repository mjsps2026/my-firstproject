import { forwardRef } from 'react';
import { School, Printer } from 'lucide-react';
import type { TuitionWithStudent, BankConfigRow } from '../types';
import { formatCurrency, formatDate, formatDateShort, SCHOOL_NAME } from '../constants';

interface InvoicePrintProps {
  tuition: TuitionWithStudent;
  bank: BankConfigRow | null;
  onClose: () => void;
}

export const InvoiceModal = forwardRef<HTMLDivElement, InvoicePrintProps>(
  ({ tuition, bank, onClose }, ref) => {
    const balance = tuition.amount - tuition.paid_amount;
    const isPaid = tuition.status === 'paid';
    const invNum = tuition.invoice_number || 'INV-' + tuition.id.slice(0, 8).toUpperCase();

    return (
      <div className="fixed inset-0 z-50 bg-black/40 flex items-center justify-center p-4 animate-fade-in" onClick={onClose}>
        <div className="bg-white rounded-2xl shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto scrollbar-thin" onClick={(e) => e.stopPropagation()}>
          <div className="flex items-center justify-between px-6 py-4 border-b border-ink-100 no-print">
            <h2 className="text-lg font-semibold text-ink-900">ບິນເກັບເງິນຄ່າຮຽນ</h2>
            <div className="flex items-center gap-2">
              <button onClick={() => window.print()} className="btn-primary">
                <Printer className="w-4 h-4" />
                ພິມບິນ
              </button>
              <button onClick={onClose} className="btn-secondary">ປິດ</button>
            </div>
          </div>

          <div ref={ref} className="print-area p-8">
            <div className="flex items-start justify-between mb-8">
              <div className="flex items-center gap-3">
                <div className="flex items-center justify-center w-12 h-12 rounded-xl bg-brand-500 text-white">
                  <School className="w-6 h-6" />
                </div>
                <div>
                  <h1 className="text-xl font-bold text-ink-900">{SCHOOL_NAME}</h1>
                  <p className="text-sm text-ink-400">ໃບເກັບເງິນຄ່າຮຽນ</p>
                </div>
              </div>
              <div className="text-right">
                <p className="text-xs text-ink-400">ເລກທີ່ບິນ</p>
                <p className="text-sm font-bold text-ink-900">{invNum}</p>
                <p className="text-xs text-ink-400 mt-2">ວັນທີອອກບິນ</p>
                <p className="text-sm text-ink-900">{formatDateShort(tuition.created_at)}</p>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-6 mb-6 pb-6 border-b border-ink-200">
              <div>
                <p className="text-xs text-ink-400 mb-1">ນັກຮຽນ</p>
                <p className="text-sm font-semibold text-ink-900">{tuition.student_name || '—'}</p>
                <p className="text-sm text-ink-500 mt-1">{tuition.class_name || '—'}</p>
                {tuition.parent_name && <p className="text-sm text-ink-500">ຜູ້ປົກຄອງ: {tuition.parent_name}</p>}
                {tuition.parent_phone && <p className="text-sm text-ink-500">ເບີຕິດຕໍ່: {tuition.parent_phone}</p>}
              </div>
              <div className="text-right">
                <p className="text-xs text-ink-400 mb-1">ພາກຮຽນ</p>
                <p className="text-sm font-semibold text-ink-900">{tuition.term}</p>
                <p className="text-xs text-ink-400 mt-2">ກຳນົດຊຳລະ</p>
                <p className="text-sm text-ink-900">{formatDate(tuition.due_date)}</p>
              </div>
            </div>

            <table className="w-full mb-6">
              <thead>
                <tr className="border-b-2 border-ink-200">
                  <th className="text-left py-2 text-xs font-semibold text-ink-500 uppercase">ລາຍການ</th>
                  <th className="text-right py-2 text-xs font-semibold text-ink-500 uppercase">ຈຳນວນເງິນ</th>
                </tr>
              </thead>
              <tbody>
                <tr className="border-b border-ink-100">
                  <td className="py-3 text-sm text-ink-900">ຄ່າຮຽນປະຈຳພາກ — {tuition.term}</td>
                  <td className="py-3 text-right text-sm font-medium text-ink-900">{formatCurrency(tuition.amount)}</td>
                </tr>
              </tbody>
              <tfoot>
                <tr className="border-t-2 border-ink-200">
                  <td className="py-3 text-sm font-bold text-ink-900">ລວມທັງໝົດ</td>
                  <td className="py-3 text-right text-base font-bold text-brand-600">{formatCurrency(tuition.amount)}</td>
                </tr>
              </tfoot>
            </table>

            <div className="grid grid-cols-3 gap-4 mb-6">
              <div className="bg-ink-50 rounded-xl p-3">
                <p className="text-xs text-ink-400">ເງິນທີ່ຈ່າຍແລ້ວ</p>
                <p className="text-sm font-bold text-brand-600">{formatCurrency(tuition.paid_amount)}</p>
              </div>
              <div className="bg-ink-50 rounded-xl p-3">
                <p className="text-xs text-ink-400">ຍັງຄ້າງ</p>
                <p className={`text-sm font-bold ${balance > 0 ? 'text-red-500' : 'text-brand-600'}`}>{formatCurrency(balance)}</p>
              </div>
              <div className="bg-ink-50 rounded-xl p-3">
                <p className="text-xs text-ink-400">ສະຖານະ</p>
                <p className={`text-sm font-bold ${isPaid ? 'text-brand-600' : 'text-red-500'}`}>
                  {isPaid ? 'ຈ່າຍແລ້ວ' : 'ຄ້າງຈ່າຍ'}
                </p>
              </div>
            </div>

            {bank && (
              <div className="bg-brand-50 rounded-xl p-4 mb-6">
                <p className="text-xs font-semibold text-brand-700 mb-2">ຊ່ອງທາງການຊຳລະ</p>
                <div className="text-sm text-ink-700 space-y-1">
                  <p>ທະນາຄານ: {bank.bank_name}</p>
                  <p>ຊື່ບັນຊີ: {bank.account_name}</p>
                  <p>ເບີບັນຊີ: {bank.account_number}</p>
                </div>
              </div>
            )}

            <div className="flex justify-between items-end mt-8">
              <div className="text-xs text-ink-400">
                <p>ກະລຸນາຊຳລະກ່ອນວັນທີ {formatDate(tuition.due_date)}</p>
                <p>ຂອບໃຈສຳລັບການຮ່ວມມື</p>
              </div>
              <div className="text-center">
                <div className="w-32 h-20 border-b border-ink-300" />
                <p className="text-xs text-ink-400 mt-1">ລາຍເຊັນ ຜູ້ອຳນວຍການ</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  },
);

InvoiceModal.displayName = 'InvoiceModal';
