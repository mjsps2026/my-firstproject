import { useState } from 'react';
import { Menu, X, School, ChevronDown } from 'lucide-react';
import type { Role } from '../types';
import { ROLES, SCHOOL_NAME } from '../constants';
import { getIcon } from '../lib/icons';

interface NavItem {
  id: string;
  label: string;
  icon: string;
}

interface SidebarProps {
  role: Role;
  nav: NavItem[];
  active: string;
  onNavigate: (id: string) => void;
}

export function Sidebar({ role, nav, active, onNavigate }: SidebarProps) {
  return (
    <aside className="hidden md:flex w-64 shrink-0 flex-col bg-white border-r border-ink-100 h-screen sticky top-0">
      <div className="flex items-center gap-3 px-5 py-5 border-b border-ink-100">
        <div className="flex items-center justify-center w-10 h-10 rounded-xl bg-brand-500 text-white">
          <School className="w-5 h-5" />
        </div>
        <div className="min-w-0">
          <h1 className="text-sm font-bold text-ink-900 truncate">{SCHOOL_NAME}</h1>
          <p className="text-xs text-ink-400">{ROLES[role].label}</p>
        </div>
      </div>
      <nav className="flex-1 overflow-y-auto scrollbar-thin px-3 py-4 space-y-1">
        {nav.map((item) => {
          const Icon = getIcon(item.icon);
          const isActive = active === item.id;
          return (
            <button
              key={item.id}
              onClick={() => onNavigate(item.id)}
              className={`nav-item w-full ${isActive ? 'nav-item-active' : 'nav-item-idle'}`}
            >
              <Icon className="w-[18px] h-[18px] shrink-0" />
              <span>{item.label}</span>
            </button>
          );
        })}
      </nav>
    </aside>
  );
}

interface MobileNavProps {
  role: Role;
  nav: NavItem[];
  active: string;
  onNavigate: (id: string) => void;
}

export function MobileNav({ role, nav, active, onNavigate }: MobileNavProps) {
  const [open, setOpen] = useState(false);
  return (
    <>
      <div className="md:hidden sticky top-0 z-30 bg-white border-b border-ink-100 px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="flex items-center justify-center w-9 h-9 rounded-lg bg-brand-500 text-white">
            <School className="w-5 h-5" />
          </div>
          <span className="text-sm font-bold text-ink-900">{SCHOOL_NAME}</span>
        </div>
        <button onClick={() => setOpen(!open)} className="p-2 rounded-lg hover:bg-ink-100">
          {open ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
        </button>
      </div>
      {open && (
        <div className="md:hidden fixed inset-0 z-40 bg-black/30" onClick={() => setOpen(false)}>
          <div className="absolute left-0 top-0 bottom-0 w-72 bg-white shadow-xl animate-slide-up" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center gap-3 px-5 py-5 border-b border-ink-100">
              <div className="flex items-center justify-center w-10 h-10 rounded-xl bg-brand-500 text-white">
                <School className="w-5 h-5" />
              </div>
              <div>
                <h1 className="text-sm font-bold text-ink-900">{SCHOOL_NAME}</h1>
                <p className="text-xs text-ink-400">{ROLES[role].label}</p>
              </div>
            </div>
            <nav className="px-3 py-4 space-y-1" onClick={() => setOpen(false)}>
              {nav.map((item) => {
                const Icon = getIcon(item.icon);
                const isActive = active === item.id;
                return (
                  <button key={item.id} onClick={() => onNavigate(item.id)} className={`nav-item w-full ${isActive ? 'nav-item-active' : 'nav-item-idle'}`}>
                    <Icon className="w-[18px] h-[18px]" />
                    <span>{item.label}</span>
                  </button>
                );
              })}
            </nav>
          </div>
        </div>
      )}
    </>
  );
}

interface TopBarProps {
  role: Role;
  onRoleChange: (role: Role) => void;
  studentSelector?: React.ReactNode;
}

export function TopBar({ role, onRoleChange, studentSelector }: TopBarProps) {
  const [dropdown, setDropdown] = useState(false);
  return (
    <div className="sticky top-0 z-20 bg-white/90 backdrop-blur border-b border-ink-100 px-4 md:px-6 py-3 flex items-center justify-between">
      <div className="flex items-center gap-3 min-w-0">
        {studentSelector}
      </div>
      <div className="relative">
        <button
          onClick={() => setDropdown(!dropdown)}
          className="flex items-center gap-2 px-3 py-2 rounded-xl hover:bg-ink-100 transition-colors"
        >
          <span className={`w-2 h-2 rounded-full bg-${ROLES[role].color}-500`} />
          <span className="text-sm font-medium text-ink-700 hidden sm:inline">{ROLES[role].label}</span>
          <ChevronDown className="w-4 h-4 text-ink-400" />
        </button>
        {dropdown && (
          <>
            <div className="fixed inset-0 z-10" onClick={() => setDropdown(false)} />
            <div className="absolute right-0 mt-2 w-56 bg-white rounded-xl shadow-soft border border-ink-100 py-2 z-20 animate-scale-in">
              <p className="px-3 py-1.5 text-xs font-medium text-ink-400 uppercase tracking-wide">ສະລັບບົດບາດ</p>
              {(Object.keys(ROLES) as Role[]).map((r) => {
                const Icon = getIcon(ROLES[r].icon);
                return (
                  <button
                    key={r}
                    onClick={() => { onRoleChange(r); setDropdown(false); }}
                    className={`w-full flex items-center gap-3 px-3 py-2.5 text-sm transition-colors ${role === r ? 'bg-brand-50 text-brand-700 font-medium' : 'text-ink-600 hover:bg-ink-50'}`}
                  >
                    <Icon className="w-4 h-4" />
                    {ROLES[r].label}
                  </button>
                );
              })}
            </div>
          </>
        )}
      </div>
    </div>
  );
}
