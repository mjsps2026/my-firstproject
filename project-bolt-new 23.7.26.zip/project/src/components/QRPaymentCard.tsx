import { QRCodeSVG } from 'qrcode.react';
import { Download, Copy, Check, Building2, CreditCard, User } from 'lucide-react';
import { useRef, useState } from 'react';
import type { BankConfigRow } from '../types';
import { formatCurrency } from '../constants';

interface QRPaymentCardProps {
  bank: BankConfigRow;
  amount: number;
  studentName: string;
  reference: string;
}

export function QRPaymentCard({ bank, amount, studentName, reference }: QRPaymentCardProps) {
  const svgRef = useRef<HTMLDivElement>(null);
  const [copied, setCopied] = useState(false);

  const payload = bank.is_static && bank.qr_payload
    ? bank.qr_payload
    : `bank:${bank.bank_name}|acc:${bank.account_number}|name:${bank.account_name}|amount:${amount}|ref:${reference}|student:${studentName}`;

  const handleDownload = () => {
    const svgEl = svgRef.current?.querySelector('svg');
    if (!svgEl) return;
    const svgData = new XMLSerializer().serializeToString(svgEl);
    const blob = new Blob([svgData], { type: 'image/svg+xml' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `qr-${reference}.svg`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(bank.account_number);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="card p-5">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-base font-semibold text-ink-900">ຊຳລະຜ່ານ QR Code</h3>
        <span className={`chip ${bank.is_static ? 'bg-sky-50 text-sky-600' : 'bg-brand-50 text-brand-700'}`}>
          {bank.is_static ? 'Static QR' : 'Dynamic QR'}
        </span>
      </div>

      <div className="flex flex-col sm:flex-row gap-5">
        <div ref={svgRef} className="flex items-center justify-center bg-white border-2 border-ink-100 rounded-xl p-4 mx-auto sm:mx-0">
          <QRCodeSVG value={payload} size={180} level="M" includeMargin />
        </div>

        <div className="flex-1 space-y-3">
          <div className="flex items-start gap-3">
            <Building2 className="w-5 h-5 text-ink-400 mt-0.5 shrink-0" />
            <div>
              <p className="text-xs text-ink-400">ທະນາຄານ</p>
              <p className="text-sm font-medium text-ink-900">{bank.bank_name}</p>
            </div>
          </div>
          <div className="flex items-start gap-3">
            <User className="w-5 h-5 text-ink-400 mt-0.5 shrink-0" />
            <div>
              <p className="text-xs text-ink-400">ຊື່ບັນຊີ</p>
              <p className="text-sm font-medium text-ink-900">{bank.account_name}</p>
            </div>
          </div>
          <div className="flex items-start gap-3">
            <CreditCard className="w-5 h-5 text-ink-400 mt-0.5 shrink-0" />
            <div className="flex-1">
              <p className="text-xs text-ink-400">ເບີບັນຊີ</p>
              <div className="flex items-center gap-2">
                <p className="text-sm font-medium text-ink-900 tracking-wider">{bank.account_number}</p>
                <button onClick={handleCopy} className="p-1 rounded hover:bg-ink-100 transition-colors" title="ສຳເນົາເບີບັນຊີ">
                  {copied ? <Check className="w-3.5 h-3.5 text-brand-500" /> : <Copy className="w-3.5 h-3.5 text-ink-400" />}
                </button>
              </div>
            </div>
          </div>
          <div className="pt-2 border-t border-ink-100">
            <p className="text-xs text-ink-400">ຈຳນວນເງິນທີ່ຕ້ອງຊຳລະ</p>
            <p className="text-xl font-bold text-brand-600">{formatCurrency(amount)}</p>
            <p className="text-xs text-ink-400 mt-1">ອ້າງອີດ: {reference}</p>
          </div>
        </div>
      </div>

      <button onClick={handleDownload} className="btn-secondary w-full mt-4">
        <Download className="w-4 h-4" />
        ດາວໂຫຼດ QR Code
      </button>
      <p className="text-xs text-ink-400 mt-3 text-center">
        ສະແກນ QR ດ້ວຍແອັບທະນາຄານ ແລ້ວສົ່ງໃບບິນໂອນເງິນມາໄດ້ທີ່ໜ້ານີ້
      </p>
    </div>
  );
}
