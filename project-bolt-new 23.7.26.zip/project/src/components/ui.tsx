import { useEffect, type ReactNode } from 'react';
import { X } from 'lucide-react';

type ModalProps = {
  open: boolean; onClose: () => void; title: string;
  children: ReactNode; footer?: ReactNode; size?: 'sm' | 'md' | 'lg' | 'xl';
};

export function Modal({ open, onClose, title, children, footer, size = 'md' }: ModalProps) {
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && onClose();
    window.addEventListener('keydown', onKey);
    document.body.style.overflow = 'hidden';
    return () => { window.removeEventListener('keydown', onKey); document.body.style.overflow = ''; };
  }, [open, onClose]);
  if (!open) return null;
  const w = { sm: 'max-w-md', md: 'max-w-lg', lg: 'max-w-2xl', xl: 'max-w-4xl' }[size];
  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4">
      <div className="absolute inset-0 bg-ink-950/40 backdrop-blur-sm animate-fade-in" onClick={onClose} />
      <div className={`relative w-full ${w} card max-h-[92vh] flex flex-col animate-slide-up rounded-b-none sm:rounded-2xl`}>
        <div className="flex items-center justify-between border-b border-ink-100 px-5 py-4">
          <h3 className="text-base font-semibold text-ink-900">{title}</h3>
          <button onClick={onClose} className="rounded-lg p-1.5 text-ink-400 hover:bg-ink-100 hover:text-ink-700 transition-colors"><X size={18} /></button>
        </div>
        <div className="overflow-y-auto px-5 py-4 flex-1">{children}</div>
        {footer && <div className="border-t border-ink-100 px-5 py-3.5 flex justify-end gap-2 bg-ink-50/50 rounded-b-2xl">{footer}</div>}
      </div>
    </div>
  );
}

type ConfirmProps = {
  open: boolean; onClose: () => void; onConfirm: () => void;
  title: string; message: string; confirmText?: string; danger?: boolean;
};

export function ConfirmDialog({ open, onClose, onConfirm, title, message, confirmText = 'ຢືນຢັນ', danger }: ConfirmProps) {
  return (
    <Modal open={open} onClose={onClose} title={title} size="sm"
      footer={<><button className="btn-secondary" onClick={onClose}>ຍົກເລີກ</button>
        <button className={danger ? 'btn-danger' : 'btn-primary'} onClick={() => { onConfirm(); onClose(); }}>{confirmText}</button></>}>
      <p className="text-sm text-ink-600 leading-relaxed">{message}</p>
    </Modal>
  );
}

export function EmptyState({ icon: Icon, title, hint }: { icon: any; title: string; hint?: string }) {
  return (
    <div className="flex flex-col items-center justify-center py-12 text-center">
      <div className="mb-3 rounded-2xl bg-ink-50 p-4 text-ink-300"><Icon size={32} /></div>
      <p className="text-sm font-medium text-ink-600">{title}</p>
      {hint && <p className="mt-1 text-xs text-ink-400">{hint}</p>}
    </div>
  );
}

export function Spinner({ size = 20 }: { size?: number }) {
  return <div className="inline-block animate-spin rounded-full border-2 border-brand-200 border-t-brand-600" style={{ width: size, height: size }} />;
}

export function LoadingPage({ label = 'ກຳລັງໂຫຼດ...' }: { label?: string }) {
  return <div className="flex flex-col items-center justify-center py-20 gap-3"><Spinner size={28} /><p className="text-sm text-ink-400">{label}</p></div>;
}

export function Toast({ show, message, type = 'success' }: { show: boolean; message: string; type?: 'success' | 'error' | 'info' }) {
  if (!show) return null;
  const styles = { success: 'bg-brand-600 text-white', error: 'bg-red-500 text-white', info: 'bg-ink-800 text-white' };
  return (
    <div className="fixed bottom-5 left-1/2 -translate-x-1/2 z-[60] animate-slide-up">
      <div className={`rounded-xl px-4 py-2.5 text-sm font-medium shadow-soft ${styles[type]}`}>{message}</div>
    </div>
  );
}
