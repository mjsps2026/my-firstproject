import { TrendingUp, TrendingDown, type LucideIcon } from 'lucide-react';

export function Avatar({ name, src, size = 40, className = '' }: { name: string; src?: string | null; size?: number; className?: string }) {
  const init = (() => {
    const clean = name.replace(/^(ນາງ|ທ\.|ທ້າວ|ອາຈານ|ດອກ)\s*/, '').trim();
    const parts = clean.split(/\s+/);
    return (parts[0]?.[0] || '') + (parts[1]?.[0] || '');
  })();
  if (src) return <img src={src} alt={name} className={`rounded-full object-cover ${className}`} style={{ width: size, height: size }} />;
  const colors = ['bg-brand-500','bg-sky-500','bg-amber-500','bg-rose-500','bg-violet-500','bg-teal-500'];
  const idx = name.charCodeAt(0) % colors.length;
  return (
    <div className={`rounded-full flex items-center justify-center text-white font-semibold ${colors[idx]} ${className}`}
      style={{ width: size, height: size, fontSize: size * 0.38 }}>{init}</div>
  );
}

export function StatCard({ icon: Icon, label, value, sub, trend, trendUp, accent = 'brand', loading }: {
  icon: LucideIcon; label: string; value: string | number; sub?: string;
  trend?: string; trendUp?: boolean; accent?: 'brand' | 'sky' | 'amber' | 'rose' | 'violet'; loading?: boolean;
}) {
  const accents: Record<string, string> = {
    brand: 'bg-brand-50 text-brand-600', sky: 'bg-sky-50 text-sky-600',
    amber: 'bg-amber-50 text-amber-600', rose: 'bg-rose-50 text-rose-600', violet: 'bg-violet-50 text-violet-600',
  };
  return (
    <div className="card p-5 hover:shadow-soft transition-shadow duration-200">
      <div className="flex items-start justify-between">
        <div className={`rounded-xl p-2.5 ${accents[accent]}`}><Icon size={22} /></div>
        {trend && <span className={`badge ${trendUp ? 'stat-trend-up' : 'stat-trend-down'}`}>
          {trendUp ? <TrendingUp size={12} /> : <TrendingDown size={12} />}{trend}</span>}
      </div>
      <div className="mt-4">
        {loading ? <div className="skeleton h-8 w-24" /> : <p className="text-2xl font-bold text-ink-900 tracking-tight">{value}</p>}
        <p className="mt-0.5 text-sm text-ink-500">{label}</p>
        {sub && <p className="mt-1 text-xs text-ink-400">{sub}</p>}
      </div>
    </div>
  );
}

export function ProgressBar({ value, max = 100, accent = 'brand', className = '' }: { value: number; max?: number; accent?: string; className?: string }) {
  const pct = Math.min(100, (value / max) * 100);
  const colors: Record<string, string> = { brand: 'bg-brand-500', sky: 'bg-sky-500', amber: 'bg-amber-500', rose: 'bg-rose-500' };
  return (
    <div className={`h-2 rounded-full bg-ink-100 overflow-hidden ${className}`}>
      <div className={`h-full rounded-full transition-all duration-500 ${colors[accent] || 'bg-brand-500'}`} style={{ width: `${pct}%` }} />
    </div>
  );
}

export function Donut({ segments, size = 140, stroke = 16, centerLabel, centerSub }: {
  segments: { value: number; color: string; label: string }[]; size?: number; stroke?: number;
  centerLabel?: string; centerSub?: string;
}) {
  const total = segments.reduce((s, x) => s + x.value, 0) || 1;
  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;
  let offset = 0;
  return (
    <div className="relative inline-flex items-center justify-center" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90">
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="#eaeef2" strokeWidth={stroke} />
        {segments.map((seg, i) => {
          const len = (seg.value / total) * c;
          const el = <circle key={i} cx={size / 2} cy={size / 2} r={r} fill="none" stroke={seg.color}
            strokeWidth={stroke} strokeDasharray={`${len} ${c - len}`} strokeDashoffset={-offset} strokeLinecap="round" />;
          offset += len; return el;
        })}
      </svg>
      {centerLabel && (
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <span className="text-xl font-bold text-ink-900">{centerLabel}</span>
          {centerSub && <span className="text-xs text-ink-400">{centerSub}</span>}
        </div>
      )}
    </div>
  );
}
