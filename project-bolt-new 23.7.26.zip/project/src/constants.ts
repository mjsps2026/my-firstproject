import type { Role } from './types';

export const SCHOOL_NAME = 'ໂຮງຮຽນສຸກປະເສີດ';

export const ROLES: Record<Role, { label: string; icon: string; color: string }> = {
  admin: { label: 'ຜູ້ອຳນວຍການ / ຜູ້ບໍລິຫານ', icon: 'Shield', color: 'brand' },
  teacher: { label: 'ຄູາອາຈານ', icon: 'GraduationCap', color: 'sky' },
  student: { label: 'ນັກຮຽນ / ຜູ້ປົກຄອງ', icon: 'Users', color: 'amber' },
};

export const ADMIN_NAV = [
  { id: 'overview', label: 'ໜ້າຫຼັກ', icon: 'LayoutDashboard' },
  { id: 'teachers', label: 'ຄູອາຈານ', icon: 'GraduationCap' },
  { id: 'students', label: 'ນັກຮຽນ', icon: 'Users' },
  { id: 'classes', label: 'ຫ້ອງຮຽນ', icon: 'School' },
  { id: 'announcements', label: 'ປະກາດ', icon: 'Megaphone' },
  { id: 'tuition', label: 'ຄ່າຮຽນ + ບິນ + QR', icon: 'Receipt' },
];

export const TEACHER_NAV = [
  { id: 'overview', label: 'ໜ້າຫຼັກ', icon: 'LayoutDashboard' },
  { id: 'attendance', label: 'ເຊັກລາຍຊື່', icon: 'CheckSquare' },
  { id: 'grading', label: 'ຄະແນນ', icon: 'ClipboardList' },
  { id: 'behavior', label: 'ພຶດຕິກຳ', icon: 'Heart' },
  { id: 'announcements', label: 'ປະກາດ', icon: 'Megaphone' },
];

export const STUDENT_NAV = [
  { id: 'overview', label: 'ໜ້າຫຼັກ', icon: 'LayoutDashboard' },
  { id: 'profile', label: 'ຂໍ້ມູນສ່ວນຕົວ', icon: 'User' },
  { id: 'attendance', label: 'ການມາຮຽນ', icon: 'CheckSquare' },
  { id: 'schedule', label: 'ຕາຕະລາງ', icon: 'CalendarDays' },
  { id: 'report', label: 'ໃບລາຍງານ', icon: 'FileText' },
  { id: 'tuition', label: 'ຄ່າຮຽນ + QR', icon: 'QrCode' },
];

export const ATTENDANCE_STATUSES = [
  { value: 'present', label: 'ມາຮຽນ', color: 'brand' },
  { value: 'absent', label: 'ຂາດ', color: 'red' },
  { value: 'late', label: 'ມາຊ້າ', color: 'amber' },
  { value: 'leave', label: 'ລາພັກ', color: 'sky' },
] as const;

export const ATTENDANCE_STATUS_STYLES: Record<string, { badge: string; dot: string }> = {
  present: { badge: 'bg-brand-50 text-brand-700', dot: 'bg-brand-500' },
  absent: { badge: 'bg-red-50 text-red-600', dot: 'bg-red-500' },
  late: { badge: 'bg-amber-50 text-amber-600', dot: 'bg-amber-500' },
  leave: { badge: 'bg-sky-50 text-sky-600', dot: 'bg-sky-500' },
};

export const TUITION_STATUS_STYLES: Record<string, { badge: string; dot: string; label: string }> = {
  unpaid: { badge: 'bg-red-50 text-red-600', dot: 'bg-red-500', label: 'ຄ້າງຈ່າຍ' },
  partial: { badge: 'bg-amber-50 text-amber-600', dot: 'bg-amber-500', label: 'ຈ່າຍບາງສ່ວນ' },
  paid: { badge: 'bg-brand-50 text-brand-700', dot: 'bg-brand-500', label: 'ຈ່າຍແລ້ວ' },
  overdue: { badge: 'bg-red-100 text-red-700', dot: 'bg-red-600', label: 'ເກີນກຳນົດ' },
};

export const SLIP_STATUS_STYLES: Record<string, { badge: string; dot: string; label: string }> = {
  pending: { badge: 'bg-amber-50 text-amber-600', dot: 'bg-amber-500', label: 'ລໍຖ້າກວດສອບ' },
  approved: { badge: 'bg-brand-50 text-brand-700', dot: 'bg-brand-500', label: 'ອະນຸມັດແລ້ວ' },
  rejected: { badge: 'bg-red-50 text-red-600', dot: 'bg-red-500', label: 'ປະຕິເສດ' },
};

export const ANNOUNCEMENT_CATEGORIES = [
  { value: 'general', label: 'ທົ່ວໄປ' },
  { value: 'event', label: 'ກິດຈະກຳ' },
  { value: 'exam', label: 'ສອບເສັງ' },
  { value: 'urgent', label: 'ດ່ວນ' },
];

export const ANNOUNCEMENT_AUDIENCES = [
  { value: 'all', label: 'ທຸກຄົນ' },
  { value: 'teachers', label: 'ຄູອາຈານ' },
  { value: 'students', label: 'ນັກຮຽນ' },
];

export const DAYS = ['ຈັນ', 'ອັງຄານ', 'ພຸດ', 'ພະຫັດ', 'ສຸກ', 'ເສົາ'];

export const TERMS = ['ພາກຮຽນທີ 1', 'ພາກຮຽນທີ 2', 'ພາກແລ້ງ'];

export const SUBJECTS = ['ພາສາລາວ', 'ຄະນິດສາດ', 'ວິທະຍາສາດ', 'ສັງຄົມສຶກສາ', 'ພາສາອັງກິດ', 'ພາສາຈີນ', 'ພາລະ','ສີລະປະ', 'ຫັດຖະກຳ', 'ຄຸນສົມບັດ'];

export const formatCurrency = (amount: number): string => {
  return new Intl.NumberFormat('lo-LA').format(amount) + ' ກີບ';
};

export const formatDate = (dateStr: string | null): string => {
  if (!dateStr) return '—';
  const d = new Date(dateStr);
  return d.toLocaleDateString('lo-LA', { year: 'numeric', month: 'long', day: 'numeric' });
};

export const formatDateShort = (dateStr: string | null): string => {
  if (!dateStr) return '—';
  const d = new Date(dateStr);
  return d.toLocaleDateString('lo-LA', { day: '2-digit', month: '2-digit', year: 'numeric' });
};

export const formatDateTime = (dateStr: string | null): string => {
  if (!dateStr) return '—';
  const d = new Date(dateStr);
  return d.toLocaleString('lo-LA', { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
};
