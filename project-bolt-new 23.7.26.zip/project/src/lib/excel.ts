import * as XLSX from 'xlsx';

export type ImportedRow = Record<string, string | number | null>;

export async function parseExcel(file: File): Promise<ImportedRow[]> {
  const buf = await file.arrayBuffer();
  const wb = XLSX.read(buf, { type: 'array' });
  const ws = wb.Sheets[wb.SheetNames[0]];
  if (!ws) return [];
  return XLSX.utils.sheet_to_json(ws, { defval: null, raw: false }) as ImportedRow[];
}

export function normalizeKey(s: string): string {
  return String(s ?? '').trim().toLowerCase().replace(/\s+/g, '_');
}

export function pick(row: ImportedRow, keys: string[]): string | null {
  const map: Record<string, string | number | null> = {};
  for (const k of Object.keys(row)) map[normalizeKey(k)] = row[k];
  for (const k of keys) {
    const v = map[normalizeKey(k)];
    if (v !== null && v !== undefined && String(v).trim() !== '') return String(v).trim();
  }
  return null;
}

export function downloadTemplate(filename: string, headers: string[], sampleRows: (string | number)[][]) {
  const ws = XLSX.utils.aoa_to_sheet([headers, ...sampleRows]);
  ws['!cols'] = headers.map((h) => ({ wch: Math.max(14, String(h).length + 4) }));
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');
  XLSX.writeFile(wb, filename);
}
