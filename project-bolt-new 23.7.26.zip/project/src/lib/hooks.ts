import { useState, useEffect, useCallback } from 'react';
import { supabase } from '../lib/supabase';
import type { StudentRow, ClassRow } from '../types';

export function useStudents() {
  const [students, setStudents] = useState<StudentRow[]>([]);
  const [classes, setClasses] = useState<ClassRow[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      const [{ data: s }, { data: c }] = await Promise.all([
        supabase.from('students').select('*').order('full_name'),
        supabase.from('classes').select('*').order('name'),
      ]);
      setStudents(s || []);
      setClasses(c || []);
      setLoading(false);
    })();
  }, []);

  return { students, classes, loading };
}

export function useStudentsByClass(classId: string | null) {
  const [students, setStudents] = useState<StudentRow[]>([]);
  const [loading, setLoading] = useState(false);

  const fetch = useCallback(async () => {
    if (!classId) { setStudents([]); return; }
    setLoading(true);
    const { data } = await supabase.from('students').select('*').eq('class_id', classId).order('full_name');
    setStudents(data || []);
    setLoading(false);
  }, [classId]);

  useEffect(() => { fetch(); }, [fetch]);
  return { students, loading, refresh: fetch };
}
