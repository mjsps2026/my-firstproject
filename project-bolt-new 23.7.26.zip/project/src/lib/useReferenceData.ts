import { useEffect, useState, useCallback } from 'react';
import { supabase } from './supabase';
import type { ClassRow, TeacherRow, BankConfigRow } from '../types';

let cachedClasses: ClassRow[] | null = null;
let cachedTeachers: TeacherRow[] | null = null;
let cachedBank: BankConfigRow | null = null;

export function useReferenceData() {
  const [classes, setClasses] = useState<ClassRow[]>(cachedClasses || []);
  const [teachers, setTeachers] = useState<TeacherRow[]>(cachedTeachers || []);
  const [bankConfig, setBankConfig] = useState<BankConfigRow | null>(cachedBank);
  const [loading, setLoading] = useState(!cachedClasses);

  const refresh = useCallback(async () => {
    setLoading(true);
    const [cls, tch, bank] = await Promise.all([
      supabase.from('classes').select('*').order('level').order('name'),
      supabase.from('teachers').select('*').order('full_name'),
      supabase.from('bank_config').select('*').eq('active', true).maybeSingle(),
    ]);
    if (cls.data) { cachedClasses = cls.data as ClassRow[]; setClasses(cls.data as ClassRow[]); }
    if (tch.data) { cachedTeachers = tch.data as TeacherRow[]; setTeachers(tch.data as TeacherRow[]); }
    if (bank.data) { cachedBank = bank.data as BankConfigRow; setBankConfig(bank.data as BankConfigRow); }
    setLoading(false);
  }, []);

  useEffect(() => { if (!cachedClasses) refresh(); }, [refresh]);
  return { classes, teachers, bankConfig, loading, refresh };
}

export function clearReferenceCache() { cachedClasses = null; cachedTeachers = null; cachedBank = null; }
