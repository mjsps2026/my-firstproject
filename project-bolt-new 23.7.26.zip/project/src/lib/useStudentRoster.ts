import { useEffect, useState, useCallback } from 'react';
import { supabase } from './supabase';
import type { StudentWithClass } from '../types';

let cachedStudents: StudentWithClass[] | null = null;

export function useStudentRoster() {
  const [students, setStudents] = useState<StudentWithClass[]>(cachedStudents || []);
  const [loading, setLoading] = useState(!cachedStudents);
  const [currentId, setCurrentId] = useState<string | null>(null);

  const refresh = useCallback(async () => {
    setLoading(true);
    const { data } = await supabase.from('students').select('*, classes(id, name, level, grade_level)').eq('status', 'active').order('full_name');
    const list = (data as StudentWithClass[]) || [];
    cachedStudents = list; setStudents(list); setLoading(false);
  }, []);

  useEffect(() => {
    (async () => {
      if (!cachedStudents) await refresh();
      if (!currentId && cachedStudents && cachedStudents.length) setCurrentId(cachedStudents[0].id);
    })();
  }, [refresh, currentId]);

  const current = students.find((s) => s.id === currentId) || null;
  return { students, loading, currentId, setCurrentId, current, refresh };
}
