import { useState, useEffect, useCallback } from 'react';
import { supabase } from '../../lib/supabase';
import { ATTENDANCE_STATUSES } from '../../constants';
import { formatDate } from '../../constants';
import type { AnnouncementRow } from '../../types';
import { Users, GraduationCap, School, Wallet, Megaphone, TrendingUp } from 'lucide-react';

const STATUS_COLORS: Record<string, string> = {
  present: '#16c07a',
  absent: '#ef4444',
  late: '#f59e0b',
  leave: '#06acf0',
};

interface DonutSegment {
  value: number;
  color: string;
  label: string;
}

export default function AdminOverview() {
  const [studentCount, setStudentCount] = useState(0);
  const [teacherCount, setTeacherCount] = useState(0);
  const [classCount, setClassCount] = useState(0);
  const [unpaidTotal, setUnpaidTotal] = useState(0);
  const [attendanceToday, setAttendanceToday] = useState<Record<string, number>>({});
  const [announcements, setAnnouncements] = useState<AnnouncementRow[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchData = useCallback(async () => {
    setLoading(true);
    const today = new Date().toISOString().slice(0, 10);

    const [
      { count: sCount },
      { count: tCount },
      { count: cCount },
      { data: tuitionData },
      { data: attData },
      { data: annData },
    ] = await Promise.all([
      supabase.from('students').select('*', { count: 'exact', head: true }),
      supabase.from('teachers').select('*', { count: 'exact', head: true }),
      supabase.from('classes').select('*', { count: 'exact', head: true }),
      supabase.from('tuition').select('amount, paid_amount, status'),
      supabase.from('attendance').select('status').eq('date', today),
      supabase.from('announcements').select('*').order('created_at', { ascending: false }).limit(5),
    ]);

    setStudentCount(sCount || 0);
    setTeacherCount(tCount || 0);
    setClassCount(cCount || 0);

    const unpaid = (tuitionData || []).reduce((sum, row: any) => {
      if (row.status === 'paid') return sum;
      return sum + ((row.amount || 0) - (row.paid_amount || 0));
    }, 0);
    setUnpaidTotal(unpaid);

    const attCounts: Record<string, number> = { present: 0, absent: 0, late: 0, leave: 0 };
    (attData || []).forEach((row: any) => {
      if (attCounts[row.status] !== undefined) attCounts[row.status] += 1;
    });
    setAttendanceToday(attCounts);

    setAnnouncements((annData || []) as AnnouncementRow[]);
    setLoading(false);
  }, []);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  const donutSegments: DonutSegment[] = ATTENDANCE_STATUSES.map((s) => ({
    value: attendanceToday[s.value] || 0,
    color: STATUS_COLORS[s.value] || '#eaeef2',
    label: s.label,
  })).filter((seg) => seg.value > 0);

  if (donutSegments.length === 0) donutSegments.push({ value: 1, color: '#eaeef2', label: 'ບໍ່ມີຂໍ້ມູນ' } as any);

  const donutTotal = donutSegments.reduce((sum, s) => sum + s.value, 0);
  let cumulativeAngle = 0;
  const donutPaths = donutSegments.map((seg) => {
    const fraction = seg.value / donutTotal;
    const startAngle = cumulativeAngle;
    const angle = fraction * 360;
    cumulativeAngle += angle;
    const startRad = (startAngle - 90) * (Math.PI / 180);
    const endRad = (startAngle + angle - 90) * (Math.PI / 180);
    const r = 60;
    const cx = 80;
    const cy = 80;
    const largeArc = angle > 180 ? 1 : 0;
    const x1 = cx + r * Math.cos(startRad);
    const y1 = cy + r * Math.sin(startRad);
    const x2 = cx + r * Math.cos(endRad);
    const y2 = cy + r * Math.sin(endRad);
    return {
      d: `M ${cx} ${cy} L ${x1} ${y1} A ${r} ${r} 0 ${largeArc} 1 ${x2} ${y2} Z`,
      color: seg.color,
      label: seg.label,
      value: seg.value,
    };
  });

  const totalAttendance = attendanceToday.present + attendanceToday.absent + attendanceToday.late + attendanceToday.leave;
  const presentRate = totalAttendance > 0 ? Math.round((attendanceToday.present / totalAttendance) * 100) : 0;

  if (loading) {
    return <div className="card p-8 text-center text-ink-400">ກຳລັງໂຫຼດ...</div>;
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-ink-900">ໜ້າຫຼັກຜູ້ອຳນວຍການ</h1>
        <p className="text-sm text-ink-400 mt-1">ພາບລວມຂອງໂຮງຮຽນ</p>
      </div>

      {/* Stat Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="stat-card">
          <div className="w-12 h-12 rounded-xl bg-brand-50 flex items-center justify-center">
            <Users className="w-6 h-6 text-brand-600" />
          </div>
          <div>
            <p className="text-sm text-ink-400">ນັກຮຽນທັງໝົດ</p>
            <p className="text-2xl font-bold text-ink-900">{studentCount}</p>
          </div>
        </div>
        <div className="stat-card">
          <div className="w-12 h-12 rounded-xl bg-sky-50 flex items-center justify-center">
            <GraduationCap className="w-6 h-6 text-sky-600" />
          </div>
          <div>
            <p className="text-sm text-ink-400">ຄູອາຈານທັງໝົດ</p>
            <p className="text-2xl font-bold text-ink-900">{teacherCount}</p>
          </div>
        </div>
        <div className="stat-card">
          <div className="w-12 h-12 rounded-xl bg-amber-50 flex items-center justify-center">
            <School className="w-6 h-6 text-amber-600" />
          </div>
          <div>
            <p className="text-sm text-ink-400">ຫ້ອງຮຽນທັງໝົດ</p>
            <p className="text-2xl font-bold text-ink-900">{classCount}</p>
          </div>
        </div>
        <div className="stat-card">
          <div className="w-12 h-12 rounded-xl bg-red-50 flex items-center justify-center">
            <Wallet className="w-6 h-6 text-red-600" />
          </div>
          <div>
            <p className="text-sm text-ink-400">ຄ່າຮຽນຄ້າງຮັບ</p>
            <p className="text-2xl font-bold text-ink-900">{new Intl.NumberFormat('lo-LA').format(unpaidTotal)} ກີບ</p>
          </div>
        </div>
      </div>

      {/* Attendance Donut + Recent Announcements */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Donut Chart */}
        <div className="card p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold text-ink-900">ການມາຮຽນມື້ນີ້</h2>
            {totalAttendance > 0 && (
              <span className="badge bg-brand-50 text-brand-700">
                <TrendingUp className="w-3.5 h-3.5" />
                ມາຮຽນ {presentRate}%
              </span>
            )}
          </div>

          {totalAttendance === 0 ? (
            <div className="flex flex-col items-center py-8 text-ink-400">
              <div className="w-32 h-32 mb-3">
                <svg viewBox="0 0 160 160" className="w-full h-full">
                  <circle cx="80" cy="80" r="60" fill="none" stroke="#eaeef2" strokeWidth="32" />
                </svg>
              </div>
              <p className="text-sm">ຍັງບໍ່ມີການບັນທຶກການມາຮຽນມື້ນີ້</p>
            </div>
          ) : (
            <div className="flex flex-col sm:flex-row items-center gap-6">
              <div className="relative w-40 h-40 flex-shrink-0">
                <svg viewBox="0 0 160 160" className="w-full h-full">
                  {donutPaths.map((path, i) => (
                    <path key={i} d={path.d} fill={path.color} />
                  ))}
                </svg>
                <div className="absolute inset-0 flex flex-col items-center justify-center">
                  <span className="text-2xl font-bold text-ink-900">{totalAttendance}</span>
                  <span className="text-xs text-ink-400">ຄົນ</span>
                </div>
              </div>
              <div className="flex-1 space-y-2 w-full">
                {ATTENDANCE_STATUSES.map((s) => {
                  const count = attendanceToday[s.value] || 0;
                  const pct = totalAttendance > 0 ? Math.round((count / totalAttendance) * 100) : 0;
                  return (
                    <div key={s.value} className="flex items-center justify-between text-sm">
                      <div className="flex items-center gap-2">
                        <span className="w-3 h-3 rounded-full" style={{ backgroundColor: STATUS_COLORS[s.value] }} />
                        <span className="text-ink-600">{s.label}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="font-medium text-ink-900">{count}</span>
                        <span className="text-xs text-ink-400">({pct}%)</span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>

        {/* Recent Announcements */}
        <div className="card p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold text-ink-900">ປະກາດຫາດີໆ</h2>
            <Megaphone className="w-5 h-5 text-ink-300" />
          </div>
          {announcements.length === 0 ? (
            <div className="text-center py-8">
              <Megaphone className="w-10 h-10 text-ink-300 mx-auto mb-3" />
              <p className="text-sm text-ink-400">ຍັງບໍ່ມີປະກາດ</p>
            </div>
          ) : (
            <div className="space-y-3">
              {announcements.map((ann) => (
                <div key={ann.id} className="flex items-start gap-3 p-3 rounded-xl hover:bg-ink-50 transition-colors">
                  <div className="w-9 h-9 rounded-lg bg-brand-50 flex items-center justify-center flex-shrink-0">
                    <Megaphone className="w-4 h-4 text-brand-600" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-ink-900 truncate">{ann.title}</p>
                    <p className="text-xs text-ink-400 mt-0.5">
                      {ann.author || 'ຜູ້ອຳນວຍການ'} · {formatDate(ann.created_at)}
                    </p>
                  </div>
                  <span className="chip bg-ink-100 text-ink-600 flex-shrink-0">{ann.category}</span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
