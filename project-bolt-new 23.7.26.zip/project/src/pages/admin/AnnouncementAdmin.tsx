import { useState, useEffect, useCallback } from 'react';
import { supabase } from '../../lib/supabase';
import type { AnnouncementRow } from '../../types';
import { ANNOUNCEMENT_CATEGORIES, ANNOUNCEMENT_AUDIENCES, formatDate } from '../../constants';
import {
  Megaphone, Plus, Trash2, X,
} from 'lucide-react';

const CATEGORY_LABELS: Record<string, string> = Object.fromEntries(
  ANNOUNCEMENT_CATEGORIES.map((c) => [c.value, c.label])
);
const AUDIENCE_LABELS: Record<string, string> = Object.fromEntries(
  ANNOUNCEMENT_AUDIENCES.map((a) => [a.value, a.label])
);

const CATEGORY_STYLES: Record<string, string> = {
  general: 'bg-ink-100 text-ink-600',
  event: 'bg-sky-50 text-sky-600',
  exam: 'bg-amber-50 text-amber-600',
  urgent: 'bg-red-50 text-red-600',
};

export default function AnnouncementAdmin() {
  const [announcements, setAnnouncements] = useState<AnnouncementRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);

  const fetchAnnouncements = useCallback(async () => {
    setLoading(true);
    const { data } = await supabase.from('announcements').select('*').order('created_at', { ascending: false });
    setAnnouncements((data || []) as AnnouncementRow[]);
    setLoading(false);
  }, []);

  useEffect(() => {
    fetchAnnouncements();
  }, [fetchAnnouncements]);

  const handleDelete = async (id: string) => {
    if (!confirm('ທ່ານແນ່ໃຈບໍ່ວ່າຕ້ອງການລຶບປະກາດນີ້?')) return;
    await supabase.from('announcements').delete().eq('id', id);
    fetchAnnouncements();
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold text-ink-900">ປະກາດ</h1>
          <p className="text-sm text-ink-400 mt-1">ຈັດການປະກາດຂອງໂຮງຮຽນ</p>
        </div>
        <button onClick={() => setShowModal(true)} className="btn-primary">
          <Plus className="w-4 h-4" />
          ສ້າງປະກາດ
        </button>
      </div>

      {loading ? (
        <div className="card p-8 text-center text-ink-400">ກຳລັງໂຫຼດ...</div>
      ) : announcements.length === 0 ? (
        <div className="card p-8 text-center">
          <Megaphone className="w-10 h-10 text-ink-300 mx-auto mb-3" />
          <p className="text-ink-400">ຍັງບໍ່ມີປະກາດ. ກົດ "ສ້າງປະກາດ" ເພື່ອເລີ່ມຕົ້ນ.</p>
        </div>
      ) : (
        <div className="space-y-3">
          {announcements.map((ann) => (
            <div key={ann.id} className="card p-5">
              <div className="flex items-start justify-between gap-4">
                <div className="flex items-start gap-3 flex-1 min-w-0">
                  <div className="w-10 h-10 rounded-xl bg-brand-50 flex items-center justify-center flex-shrink-0">
                    <Megaphone className="w-5 h-5 text-brand-600" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap mb-1">
                      <h3 className="text-base font-semibold text-ink-900">{ann.title}</h3>
                      <span className={`chip ${CATEGORY_STYLES[ann.category] || CATEGORY_STYLES.general}`}>
                        {CATEGORY_LABELS[ann.category] || ann.category}
                      </span>
                      <span className="chip bg-ink-100 text-ink-500">
                        {AUDIENCE_LABELS[ann.audience] || ann.audience}
                      </span>
                    </div>
                    <p className="text-sm text-ink-500 line-clamp-2">{ann.content}</p>
                    <p className="text-xs text-ink-400 mt-2">
                      {ann.author || 'ຜູ້ອຳນວຍການ'} · {formatDate(ann.created_at)}
                    </p>
                  </div>
                </div>
                <button
                  onClick={() => handleDelete(ann.id)}
                  className="p-1.5 rounded-lg hover:bg-red-50 text-ink-500 hover:text-red-600 transition-colors flex-shrink-0"
                  title="ລຶບ"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {showModal && (
        <AnnouncementModal
          onClose={() => setShowModal(false)}
          onSaved={() => { setShowModal(false); fetchAnnouncements(); }}
        />
      )}
    </div>
  );
}

function AnnouncementModal({ onClose, onSaved }: {
  onClose: () => void;
  onSaved: () => void;
}) {
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [category, setCategory] = useState('general');
  const [audience, setAudience] = useState('all');
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  const handleSave = async () => {
    if (!title.trim()) { setError('ກະລຸນາລະບຸຫົວຂໍ້'); return; }
    if (!content.trim()) { setError('ກະລຸນາລະບຸເນື້ອໃນ'); return; }
    setSaving(true);
    await supabase.from('announcements').insert({
      title: title.trim(),
      content: content.trim(),
      category,
      audience,
      author: 'ຜູ້ອຳນວຍການ',
    });
    setSaving(false);
    onSaved();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/40 flex items-center justify-center p-4 animate-fade-in" onClick={onClose}>
      <div className="bg-white rounded-2xl shadow-xl max-w-lg w-full" onClick={(e) => e.stopPropagation()}>
        <div className="px-6 py-4 border-b border-ink-100 flex items-center justify-between">
          <h2 className="text-lg font-semibold text-ink-900">ສ້າງປະກາດ</h2>
          <button onClick={onClose}><X className="w-5 h-5 text-ink-400" /></button>
        </div>
        <div className="p-6 space-y-4">
          <div>
            <label className="label">ຫົວຂໍ້</label>
            <input value={title} onChange={(e) => setTitle(e.target.value)} className="input" placeholder="ຫົວຂໍ້ປະກາດ" />
          </div>
          <div>
            <label className="label">ເນື້ອໃນ</label>
            <textarea value={content} onChange={(e) => setContent(e.target.value)} rows={4} className="input resize-none" placeholder="ເນື້ອໃນປະກາດ..." />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="label">ໝວດໝູ່</label>
              <select value={category} onChange={(e) => setCategory(e.target.value)} className="input">
                {ANNOUNCEMENT_CATEGORIES.map((c) => (
                  <option key={c.value} value={c.value}>{c.label}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="label">ຜູ້ຮັບ</label>
              <select value={audience} onChange={(e) => setAudience(e.target.value)} className="input">
                {ANNOUNCEMENT_AUDIENCES.map((a) => (
                  <option key={a.value} value={a.value}>{a.label}</option>
                ))}
              </select>
            </div>
          </div>
          {error && <p className="text-sm text-red-500">{error}</p>}
        </div>
        <div className="px-6 py-4 border-t border-ink-100 flex justify-end gap-2">
          <button onClick={onClose} className="btn-secondary">ຍົກເລີກ</button>
          <button onClick={handleSave} disabled={saving} className="btn-primary">
            {saving ? 'ກຳລັງສ້າງ...' : 'ສ້າງປະກາດ'}
          </button>
        </div>
      </div>
    </div>
  );
}
