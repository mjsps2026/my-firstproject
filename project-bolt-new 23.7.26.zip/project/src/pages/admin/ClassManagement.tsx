import { useState, useEffect, useCallback } from 'react';
import { supabase } from '../../lib/supabase';
import type { ClassRow, TeacherRow } from '../../types';
import {
  School, Plus, Pencil, Trash2, X, Users, GraduationCap,
} from 'lucide-react';

const LEVEL_LABELS: Record<string, string> = {
  preschool: 'ອະນຸບານ',
  primary: 'ປະຖົມ',
};

export default function ClassManagement() {
  const [classes, setClasses] = useState<(ClassRow & { teacher_name?: string; student_count?: number })[]>([]);
  const [teachers, setTeachers] = useState<TeacherRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [editing, setEditing] = useState<ClassRow | null>(null);

  const fetchClasses = useCallback(async () => {
    setLoading(true);
    const [{ data: cData }, { data: tData }, { data: sData }] = await Promise.all([
      supabase.from('classes').select('*').order('name'),
      supabase.from('teachers').select('*').order('full_name'),
      supabase.from('students').select('class_id'),
    ]);
    const teacherMap = new Map((tData || []).map((t: TeacherRow) => [t.id, t.full_name]));
    const countMap: Record<string, number> = {};
    (sData || []).forEach((s: any) => {
      if (s.class_id) countMap[s.class_id] = (countMap[s.class_id] || 0) + 1;
    });
    const enriched = (cData || []).map((c: any) => ({
      ...c,
      teacher_name: c.homeroom_teacher_id ? teacherMap.get(c.homeroom_teacher_id) || '—' : '—',
      student_count: countMap[c.id] || 0,
    }));
    setTeachers((tData || []) as TeacherRow[]);
    setClasses(enriched);
    setLoading(false);
  }, []);

  useEffect(() => {
    fetchClasses();
  }, [fetchClasses]);

  const handleDelete = async (id: string) => {
    if (!confirm('ທ່ານແນ່ໃຈບໍ່ວ່າຕ້ອງການລຶບຫ້ອງຮຽນນີ້?')) return;
    await supabase.from('classes').delete().eq('id', id);
    fetchClasses();
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold text-ink-900">ຫ້ອງຮຽນ</h1>
          <p className="text-sm text-ink-400 mt-1">ຈັດການຂໍ້ມູນຫ້ອງຮຽນ</p>
        </div>
        <button onClick={() => { setEditing(null); setShowModal(true); }} className="btn-primary">
          <Plus className="w-4 h-4" />
          ເພີ່ມຫ້ອງຮຽນ
        </button>
      </div>

      {loading ? (
        <div className="card p-8 text-center text-ink-400">ກຳລັງໂຫຼດ...</div>
      ) : classes.length === 0 ? (
        <div className="card p-8 text-center">
          <School className="w-10 h-10 text-ink-300 mx-auto mb-3" />
          <p className="text-ink-400">ຍັງບໍ່ມີຫ້ອງຮຽນ. ກົດ "ເພີ່ມຫ້ອງຮຽນ" ເພື່ອເລີ່ມຕົ້ນ.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {classes.map((c) => (
            <div key={c.id} className="card p-5">
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center gap-3">
                  <div className="w-11 h-11 rounded-xl bg-brand-50 flex items-center justify-center">
                    <School className="w-5 h-5 text-brand-600" />
                  </div>
                  <div>
                    <h3 className="text-base font-semibold text-ink-900">{c.name}</h3>
                    <span className="chip bg-ink-100 text-ink-600 mt-1">
                      {LEVEL_LABELS[c.level] || c.level}
                    </span>
                  </div>
                </div>
                <div className="flex items-center gap-1">
                  <button
                    onClick={() => { setEditing(c); setShowModal(true); }}
                    className="p-1.5 rounded-lg hover:bg-brand-50 text-ink-500 hover:text-brand-600 transition-colors"
                    title="ແກ້ໄຂ"
                  >
                    <Pencil className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => handleDelete(c.id)}
                    className="p-1.5 rounded-lg hover:bg-red-50 text-ink-500 hover:text-red-600 transition-colors"
                    title="ລຶບ"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>

              <div className="space-y-2.5 border-t border-ink-100 pt-4">
                <div className="flex items-center gap-2 text-sm">
                  <GraduationCap className="w-4 h-4 text-ink-400" />
                  <span className="text-ink-400">ຄູປະຈຳຫ້ອງ:</span>
                  <span className="font-medium text-ink-900">{c.teacher_name}</span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <Users className="w-4 h-4 text-ink-400" />
                  <span className="text-ink-400">ຈຳນວນນັກຮຽນ:</span>
                  <span className="font-medium text-ink-900">{c.student_count} ຄົນ</span>
                </div>
                {c.grade_level && (
                  <div className="flex items-center gap-2 text-sm">
                    <span className="text-ink-400">ຊັ້ນຮຽນ:</span>
                    <span className="font-medium text-ink-900">{c.grade_level}</span>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      )}

      {showModal && (
        <ClassModal
          classRow={editing}
          teachers={teachers}
          onClose={() => setShowModal(false)}
          onSaved={() => { setShowModal(false); fetchClasses(); }}
        />
      )}
    </div>
  );
}

function ClassModal({ classRow, teachers, onClose, onSaved }: {
  classRow: ClassRow | null;
  teachers: TeacherRow[];
  onClose: () => void;
  onSaved: () => void;
}) {
  const [name, setName] = useState(classRow?.name || '');
  const [level, setLevel] = useState<'preschool' | 'primary'>(classRow?.level || 'preschool');
  const [gradeLevel, setGradeLevel] = useState(classRow?.grade_level || '');
  const [homeroomTeacherId, setHomeroomTeacherId] = useState(classRow?.homeroom_teacher_id || '');
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  const handleSave = async () => {
    if (!name.trim()) { setError('ກະລຸນາລະບຸຊື່ຫ້ອງຮຽນ'); return; }
    setSaving(true);
    const payload = {
      name: name.trim(),
      level,
      grade_level: gradeLevel.trim() || null,
      homeroom_teacher_id: homeroomTeacherId || null,
    };
    if (classRow) {
      await supabase.from('classes').update(payload).eq('id', classRow.id);
    } else {
      await supabase.from('classes').insert(payload);
    }
    setSaving(false);
    onSaved();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/40 flex items-center justify-center p-4 animate-fade-in" onClick={onClose}>
      <div className="bg-white rounded-2xl shadow-xl max-w-lg w-full" onClick={(e) => e.stopPropagation()}>
        <div className="px-6 py-4 border-b border-ink-100 flex items-center justify-between">
          <h2 className="text-lg font-semibold text-ink-900">{classRow ? 'ແກ້ໄຂຫ້ອງຮຽນ' : 'ເພີ່ມຫ້ອງຮຽນ'}</h2>
          <button onClick={onClose}><X className="w-5 h-5 text-ink-400" /></button>
        </div>
        <div className="p-6 space-y-4">
          <div>
            <label className="label">ຊື່ຫ້ອງຮຽນ</label>
            <input value={name} onChange={(e) => setName(e.target.value)} className="input" placeholder="ເຊັ່ນ ມ.1" />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="label">ລະດັບ</label>
              <select value={level} onChange={(e) => setLevel(e.target.value as any)} className="input">
                <option value="preschool">ອະນຸບານ</option>
                <option value="primary">ປະຖົມ</option>
              </select>
            </div>
            <div>
              <label className="label">ຊັ້ນຮຽນ</label>
              <input value={gradeLevel} onChange={(e) => setGradeLevel(e.target.value)} className="input" placeholder="ເຊັ່ນ ປ.1" />
            </div>
          </div>
          <div>
            <label className="label">ຄູປະຈຳຫ້ອງ</label>
            <select value={homeroomTeacherId} onChange={(e) => setHomeroomTeacherId(e.target.value)} className="input">
              <option value="">— ເລືອກຄູ —</option>
              {teachers.map((t) => <option key={t.id} value={t.id}>{t.full_name}</option>)}
            </select>
          </div>
          {error && <p className="text-sm text-red-500">{error}</p>}
        </div>
        <div className="px-6 py-4 border-t border-ink-100 flex justify-end gap-2">
          <button onClick={onClose} className="btn-secondary">ຍົກເລີກ</button>
          <button onClick={handleSave} disabled={saving} className="btn-primary">
            {saving ? 'ກຳລັງບັນທຶກ...' : 'ບັນທຶກ'}
          </button>
        </div>
      </div>
    </div>
  );
}
