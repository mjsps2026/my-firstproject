import { useState, useEffect, useCallback, useRef } from 'react';
import { supabase } from '../../lib/supabase';
import type { StudentRow, ClassRow } from '../../types';
import * as XLSX from 'xlsx';
import {
  Users, Plus, Search, Pencil, Trash2, Upload, Download, X, Phone,
} from 'lucide-react';

export default function StudentManagement() {
  const [students, setStudents] = useState<(StudentRow & { class_name?: string })[]>([]);
  const [classes, setClasses] = useState<ClassRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [classFilter, setClassFilter] = useState('all');
  const [showModal, setShowModal] = useState(false);
  const [editing, setEditing] = useState<StudentRow | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const fetchStudents = useCallback(async () => {
    setLoading(true);
    const [{ data: sData }, { data: cData }] = await Promise.all([
      supabase.from('students').select('*').order('full_name'),
      supabase.from('classes').select('*').order('name'),
    ]);
    const classMap = new Map((cData || []).map((c: ClassRow) => [c.id, c.name]));
    const enriched = (sData || []).map((s: any) => ({
      ...s,
      class_name: s.class_id ? classMap.get(s.class_id) || '—' : '—',
    }));
    setClasses((cData || []) as ClassRow[]);
    setStudents(enriched);
    setLoading(false);
  }, []);

  useEffect(() => {
    fetchStudents();
  }, [fetchStudents]);

  const filtered = students.filter((s) => {
    const matchesSearch =
      s.full_name.toLowerCase().includes(search.toLowerCase()) ||
      (s.parent_name || '').toLowerCase().includes(search.toLowerCase());
    const matchesClass = classFilter === 'all' || s.class_id === classFilter;
    return matchesSearch && matchesClass;
  });

  const handleDelete = async (id: string) => {
    if (!confirm('ທ່ານແນ່ໃຈບໍ່ວ່າຕ້ອງການລຶບນັກຮຽນນີ້?')) return;
    await supabase.from('students').delete().eq('id', id);
    fetchStudents();
  };

  const handleExport = async () => {
    const { data: sData } = await supabase.from('students').select('*').order('full_name');
    const { data: cData } = await supabase.from('classes').select('*');
    const classMap = new Map((cData || []).map((c: any) => [c.id, c.name]));
    const rows = (sData || []).map((s: any) => ({
      'ຊື່ເຕັມ': s.full_name,
      'ຫ້ອງຮຽນ': s.class_id ? classMap.get(s.class_id) || '' : '',
      'ເພດ': s.gender === 'male' ? 'ຊາຍ' : s.gender === 'female' ? 'ຍິງ' : '',
      'ຊື່ຜູ້ປົກຄອງ': s.parent_name || '',
      'ເບີຜູ້ປົກຄອງ': s.parent_phone || '',
      'ສະຖານະ': s.status || '',
    }));
    const ws = XLSX.utils.json_to_sheet(rows);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'ນັກຮຽນ');
    XLSX.writeFile(wb, 'ນັກຮຽນ.xlsx');
  };

  const handleImportClick = () => {
    fileInputRef.current?.click();
  };

  const handleImportFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = async (event) => {
      try {
        const result = event.target?.result;
        const wb = XLSX.read(result, { type: 'array' });
        const ws = wb.Sheets[wb.SheetNames[0]];
        const json: any[] = XLSX.utils.sheet_to_json(ws);
        const classNameToId = new Map(classes.map((c) => [c.name, c.id]));
        const rows = json.map((row) => {
          const className = row['ຫ້ອງຮຽນ'] || row['class_name'] || '';
          return {
            full_name: row['ຊື່ເຕັມ'] || row['full_name'] || '',
            class_id: classNameToId.get(className) || null,
            gender: (row['ເພດ'] === 'ຊາຍ' || row['gender'] === 'male') ? 'male' :
                    (row['ເພດ'] === 'ຍິງ' || row['gender'] === 'female') ? 'female' : null,
            parent_name: row['ຊື່ຜູ້ປົກຄອງ'] || row['parent_name'] || null,
            parent_phone: row['ເບີຜູ້ປົກຄອງ'] || row['parent_phone'] || null,
            status: row['ສະຖານະ'] || row['status'] || 'active',
          };
        }).filter((r) => r.full_name);
        if (rows.length > 0) {
          await supabase.from('students').insert(rows);
          fetchStudents();
        }
      } catch (err) {
        alert('ບໍ່ສາມາດນຳເຂົ້າໄຟລ໌ Excel ໄດ້');
      }
    };
    reader.readAsArrayBuffer(file);
    e.target.value = '';
  };

  const genderLabel = (g: string | null) => {
    if (g === 'male') return 'ຊາຍ';
    if (g === 'female') return 'ຍິງ';
    return '—';
  };

  return (
    <div className="space-y-4">
      <input type="file" ref={fileInputRef} accept=".xlsx,.xls" onChange={handleImportFile} className="hidden" />

      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold text-ink-900">ນັກຮຽນ</h1>
          <p className="text-sm text-ink-400 mt-1">ຈັດການຂໍ້ມູນນັກຮຽນ</p>
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          <button onClick={handleImportClick} className="btn-secondary">
            <Upload className="w-4 h-4" />
            ນຳເຂົ້າ Excel
          </button>
          <button onClick={handleExport} className="btn-secondary">
            <Download className="w-4 h-4" />
            ສົ່ງອອກ Excel
          </button>
          <button onClick={() => { setEditing(null); setShowModal(true); }} className="btn-primary">
            <Plus className="w-4 h-4" />
            ເພີ່ມນັກຮຽນ
          </button>
        </div>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1 max-w-sm">
          <Search className="w-4 h-4 text-ink-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="ຄົ້ນຫາຕາມຊື່ ຫຼື ຜູ້ປົກຄອງ..."
            className="input pl-9"
          />
        </div>
        <select value={classFilter} onChange={(e) => setClassFilter(e.target.value)} className="input sm:w-56">
          <option value="all">ທຸກຫ້ອງຮຽນ</option>
          {classes.map((c) => (
            <option key={c.id} value={c.id}>{c.name}</option>
          ))}
        </select>
      </div>

      {loading ? (
        <div className="card p-8 text-center text-ink-400">ກຳລັງໂຫຼດ...</div>
      ) : filtered.length === 0 ? (
        <div className="card p-8 text-center">
          <Users className="w-10 h-10 text-ink-300 mx-auto mb-3" />
          <p className="text-ink-400">
            {search || classFilter !== 'all' ? 'ບໍ່ພົບນັກຮຽນທີ່ຄົ້ນຫາ' : 'ຍັງບໍ່ມີນັກຮຽນ. ກົດ "ເພີ່ມນັກຮຽນ" ເພື່ອເລີ່ມຕົ້ນ.'}
          </p>
        </div>
      ) : (
        <div className="card overflow-hidden">
          <div className="overflow-x-auto scrollbar-thin">
            <table className="w-full text-sm">
              <thead>
                <tr className="bg-ink-50 text-ink-500 text-xs uppercase">
                  <th className="text-left px-4 py-3 font-semibold">ຊື່ເຕັມ</th>
                  <th className="text-left px-4 py-3 font-semibold">ຫ້ອງຮຽນ</th>
                  <th className="text-left px-4 py-3 font-semibold">ເພດ</th>
                  <th className="text-left px-4 py-3 font-semibold">ຜູ້ປົກຄອງ</th>
                  <th className="text-left px-4 py-3 font-semibold">ເບີຜູ້ປົກຄອງ</th>
                  <th className="text-center px-4 py-3 font-semibold">ສະຖານະ</th>
                  <th className="text-center px-4 py-3 font-semibold">ການປະຕິບັດ</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((s) => (
                  <tr key={s.id} className="border-t border-ink-100 table-row">
                    <td className="px-4 py-3 font-medium text-ink-900">{s.full_name}</td>
                    <td className="px-4 py-3 text-ink-500">{s.class_name || '—'}</td>
                    <td className="px-4 py-3 text-ink-500">{genderLabel(s.gender)}</td>
                    <td className="px-4 py-3 text-ink-500">{s.parent_name || '—'}</td>
                    <td className="px-4 py-3 text-ink-500">
                      {s.parent_phone ? (
                        <span className="flex items-center gap-1.5">
                          <Phone className="w-3.5 h-3.5 text-ink-300" />
                          {s.parent_phone}
                        </span>
                      ) : '—'}
                    </td>
                    <td className="px-4 py-3 text-center">
                      <span className={`badge ${s.status === 'active' ? 'bg-brand-50 text-brand-700' : 'bg-ink-100 text-ink-500'}`}>
                        <span className={`w-1.5 h-1.5 rounded-full ${s.status === 'active' ? 'bg-brand-500' : 'bg-ink-400'}`} />
                        {s.status === 'active' ? 'ການຮຽນ' : 'ພັກ'}
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center justify-center gap-1">
                        <button
                          onClick={() => { setEditing(s); setShowModal(true); }}
                          className="p-1.5 rounded-lg hover:bg-brand-50 text-ink-500 hover:text-brand-600 transition-colors"
                          title="ແກ້ໄຂ"
                        >
                          <Pencil className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => handleDelete(s.id)}
                          className="p-1.5 rounded-lg hover:bg-red-50 text-ink-500 hover:text-red-600 transition-colors"
                          title="ລຶບ"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {showModal && (
        <StudentModal
          student={editing}
          classes={classes}
          onClose={() => setShowModal(false)}
          onSaved={() => { setShowModal(false); fetchStudents(); }}
        />
      )}
    </div>
  );
}

function StudentModal({ student, classes, onClose, onSaved }: {
  student: StudentRow | null;
  classes: ClassRow[];
  onClose: () => void;
  onSaved: () => void;
}) {
  const [fullName, setFullName] = useState(student?.full_name || '');
  const [classId, setClassId] = useState(student?.class_id || '');
  const [gender, setGender] = useState<'male' | 'female' | ''>(student?.gender || '');
  const [parentName, setParentName] = useState(student?.parent_name || '');
  const [parentPhone, setParentPhone] = useState(student?.parent_phone || '');
  const [status, setStatus] = useState(student?.status || 'active');
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  const handleSave = async () => {
    if (!fullName.trim()) { setError('ກະລຸນາລະບຸຊື່'); return; }
    setSaving(true);
    const payload = {
      full_name: fullName.trim(),
      class_id: classId || null,
      gender: gender || null,
      parent_name: parentName.trim() || null,
      parent_phone: parentPhone.trim() || null,
      status,
    };
    if (student) {
      await supabase.from('students').update(payload).eq('id', student.id);
    } else {
      await supabase.from('students').insert(payload);
    }
    setSaving(false);
    onSaved();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/40 flex items-center justify-center p-4 animate-fade-in" onClick={onClose}>
      <div className="bg-white rounded-2xl shadow-xl max-w-lg w-full" onClick={(e) => e.stopPropagation()}>
        <div className="px-6 py-4 border-b border-ink-100 flex items-center justify-between">
          <h2 className="text-lg font-semibold text-ink-900">{student ? 'ແກ້ໄຂນັກຮຽນ' : 'ເພີ່ມນັກຮຽນ'}</h2>
          <button onClick={onClose}><X className="w-5 h-5 text-ink-400" /></button>
        </div>
        <div className="p-6 space-y-4">
          <div>
            <label className="label">ຊື່ເຕັມ</label>
            <input value={fullName} onChange={(e) => setFullName(e.target.value)} className="input" placeholder="ຊື່ເຕັມ" />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="label">ຫ້ອງຮຽນ</label>
              <select value={classId} onChange={(e) => setClassId(e.target.value)} className="input">
                <option value="">— ເລືອກຫ້ອງ —</option>
                {classes.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
              </select>
            </div>
            <div>
              <label className="label">ເພດ</label>
              <select value={gender} onChange={(e) => setGender(e.target.value as any)} className="input">
                <option value="">— ເລືອກເພດ —</option>
                <option value="male">ຊາຍ</option>
                <option value="female">ຍິງ</option>
              </select>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="label">ຊື່ຜູ້ປົກຄອງ</label>
              <input value={parentName} onChange={(e) => setParentName(e.target.value)} className="input" placeholder="ຊື່ຜູ້ປົກຄອງ" />
            </div>
            <div>
              <label className="label">ເບີຜູ້ປົກຄອງ</label>
              <input value={parentPhone} onChange={(e) => setParentPhone(e.target.value)} className="input" placeholder="020 xxxx xxxx" />
            </div>
          </div>
          <div>
            <label className="label">ສະຖານະ</label>
            <select value={status} onChange={(e) => setStatus(e.target.value)} className="input">
              <option value="active">ການຮຽນ</option>
              <option value="inactive">ພັກ</option>
            </select>
          </div>
          {error && <p className="text-sm text-red-500">{error}</p>}
        </div>
        <div className="px-6 py-4 border-t border-ink-100 flex justify-end gap-2">
          <button onClick={onClose} className="btn-secondary">ຍົກເລີກ</button>
          <button onClick={handleSave} disabled={saving} className="btn-primary">
            {saving ? 'ກຳລັງບັນທຶກ...' : 'ບັນທຶກ'}
          </button>
        </div>
      </div>
    </div>
  );
}
