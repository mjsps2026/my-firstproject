import { useState, useEffect, useCallback, useRef } from 'react';
import { supabase } from '../../lib/supabase';
import type { TeacherRow } from '../../types';
import { SUBJECTS } from '../../constants';
import * as XLSX from 'xlsx';
import {
  GraduationCap, Plus, Search, Pencil, Trash2, Upload, Download, X, Mail, Phone,
} from 'lucide-react';

export default function TeacherManagement() {
  const [teachers, setTeachers] = useState<TeacherRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [showModal, setShowModal] = useState(false);
  const [editing, setEditing] = useState<TeacherRow | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const fetchTeachers = useCallback(async () => {
    setLoading(true);
    const { data } = await supabase.from('teachers').select('*').order('full_name');
    setTeachers((data || []) as TeacherRow[]);
    setLoading(false);
  }, []);

  useEffect(() => {
    fetchTeachers();
  }, [fetchTeachers]);

  const filtered = teachers.filter((t) =>
    t.full_name.toLowerCase().includes(search.toLowerCase()) ||
    (t.subject || '').toLowerCase().includes(search.toLowerCase())
  );

  const handleDelete = async (id: string) => {
    if (!confirm('ທ່ານແນ່ໃຈບໍ່ວ່າຕ້ອງການລຶບຄູອາຈານນີ້?')) return;
    await supabase.from('teachers').delete().eq('id', id);
    fetchTeachers();
  };

  const handleExport = async () => {
    const { data } = await supabase.from('teachers').select('*').order('full_name');
    const rows = (data || []).map((t: any) => ({
      'ຊື່ເຕັມ': t.full_name,
      'ອີເມວ': t.email || '',
      'ເບີໂທ': t.phone || '',
      'ວິຊາ': t.subject || '',
      'ເພດ': t.gender === 'male' ? 'ຍິງ' : t.gender === 'female' ? 'ຍິງ' : '',
      'ສະຖານະ': t.status || '',
    }));
    const ws = XLSX.utils.json_to_sheet(rows);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'ຄູອາຈານ');
    XLSX.writeFile(wb, 'ຄູອາຈານ.xlsx');
  };

  const handleImportClick = () => {
    fileInputRef.current?.click();
  };

  const handleImportFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = async (event) => {
      try {
        const result = event.target?.result;
        const wb = XLSX.read(result, { type: 'array' });
        const ws = wb.Sheets[wb.SheetNames[0]];
        const json: any[] = XLSX.utils.sheet_to_json(ws);
        const rows = json.map((row) => ({
          full_name: row['ຊື່ເຕັມ'] || row['full_name'] || '',
          email: row['ອີເມວ'] || row['email'] || null,
          phone: row['ເບີໂທ'] || row['phone'] || null,
          subject: row['ວິຊາ'] || row['subject'] || null,
          gender: (row['ເພດ'] === 'ຍິງ' || row['gender'] === 'male') ? 'male' :
                  (row['ເພດ'] === 'ຍິງ' || row['gender'] === 'female') ? 'female' : null,
          status: row['ສະຖານະ'] || row['status'] || 'active',
        })).filter((r) => r.full_name);
        if (rows.length > 0) {
          await supabase.from('teachers').insert(rows);
          fetchTeachers();
        }
      } catch (err) {
        alert('ບໍ່ສາມາດນຳເຂົ້າໄຟລ໌ Excel ໄດ້');
      }
    };
    reader.readAsArrayBuffer(file);
    e.target.value = '';
  };

  const genderLabel = (g: string | null) => {
    if (g === 'male') return 'ຊາຍ';
    if (g === 'female') return 'ຍິງ';
    return '—';
  };

  return (
    <div className="space-y-4">
      <input type="file" ref={fileInputRef} accept=".xlsx,.xls" onChange={handleImportFile} className="hidden" />

      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold text-ink-900">ຄູອາຈານ</h1>
          <p className="text-sm text-ink-400 mt-1">ຈັດການຂໍ້ມູນຄູອາຈານ</p>
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          <button onClick={handleImportClick} className="btn-secondary">
            <Upload className="w-4 h-4" />
            ນຳເຂົ້າ Excel
          </button>
          <button onClick={handleExport} className="btn-secondary">
            <Download className="w-4 h-4" />
            ສົ່ງອອກ Excel
          </button>
          <button onClick={() => { setEditing(null); setShowModal(true); }} className="btn-primary">
            <Plus className="w-4 h-4" />
            ເພີ່ມຄູ
          </button>
        </div>
      </div>

      {/* Search */}
      <div className="relative max-w-sm">
        <Search className="w-4 h-4 text-ink-400 absolute left-3 top-1/2 -translate-y-1/2" />
        <input
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="ຄົ້ນຫາຕາມຊື່ ຫຼື ວິຊາ..."
          className="input pl-9"
        />
      </div>

      {loading ? (
        <div className="card p-8 text-center text-ink-400">ກຳລັງໂຫຼດ...</div>
      ) : filtered.length === 0 ? (
        <div className="card p-8 text-center">
          <GraduationCap className="w-10 h-10 text-ink-300 mx-auto mb-3" />
          <p className="text-ink-400">
            {search ? 'ບໍ່ພົບຄູອາຈານທີ່ຄົ້ນຫາ' : 'ຍັງບໍ່ມີຄູອາຈານ. ກົດ "ເພີ່ມຄູ" ເພື່ອເລີ່ມຕົ້ນ.'}
          </p>
        </div>
      ) : (
        <div className="card overflow-hidden">
          <div className="overflow-x-auto scrollbar-thin">
            <table className="w-full text-sm">
              <thead>
                <tr className="bg-ink-50 text-ink-500 text-xs uppercase">
                  <th className="text-left px-4 py-3 font-semibold">ຊື່ເຕັມ</th>
                  <th className="text-left px-4 py-3 font-semibold">ອີເມວ</th>
                  <th className="text-left px-4 py-3 font-semibold">ເບີໂທ</th>
                  <th className="text-left px-4 py-3 font-semibold">ວິຊາ</th>
                  <th className="text-left px-4 py-3 font-semibold">ເພດ</th>
                  <th className="text-center px-4 py-3 font-semibold">ສະຖານະ</th>
                  <th className="text-center px-4 py-3 font-semibold">ການປະຕິບັດ</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((t) => (
                  <tr key={t.id} className="border-t border-ink-100 table-row">
                    <td className="px-4 py-3 font-medium text-ink-900">{t.full_name}</td>
                    <td className="px-4 py-3 text-ink-500">
                      {t.email ? (
                        <span className="flex items-center gap-1.5">
                          <Mail className="w-3.5 h-3.5 text-ink-300" />
                          {t.email}
                        </span>
                      ) : '—'}
                    </td>
                    <td className="px-4 py-3 text-ink-500">
                      {t.phone ? (
                        <span className="flex items-center gap-1.5">
                          <Phone className="w-3.5 h-3.5 text-ink-300" />
                          {t.phone}
                        </span>
                      ) : '—'}
                    </td>
                    <td className="px-4 py-3 text-ink-500">{t.subject || '—'}</td>
                    <td className="px-4 py-3 text-ink-500">{genderLabel(t.gender)}</td>
                    <td className="px-4 py-3 text-center">
                      <span className={`badge ${t.status === 'active' ? 'bg-brand-50 text-brand-700' : 'bg-ink-100 text-ink-500'}`}>
                        <span className={`w-1.5 h-1.5 rounded-full ${t.status === 'active' ? 'bg-brand-500' : 'bg-ink-400'}`} />
                        {t.status === 'active' ? 'ປະຈຳ' : 'ພັກວຽກ'}
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center justify-center gap-1">
                        <button
                          onClick={() => { setEditing(t); setShowModal(true); }}
                          className="p-1.5 rounded-lg hover:bg-brand-50 text-ink-500 hover:text-brand-600 transition-colors"
                          title="ແກ້ໄຂ"
                        >
                          <Pencil className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => handleDelete(t.id)}
                          className="p-1.5 rounded-lg hover:bg-red-50 text-ink-500 hover:text-red-600 transition-colors"
                          title="ລຶບ"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {showModal && (
        <TeacherModal
          teacher={editing}
          onClose={() => setShowModal(false)}
          onSaved={() => { setShowModal(false); fetchTeachers(); }}
        />
      )}
    </div>
  );
}

function TeacherModal({ teacher, onClose, onSaved }: {
  teacher: TeacherRow | null;
  onClose: () => void;
  onSaved: () => void;
}) {
  const [fullName, setFullName] = useState(teacher?.full_name || '');
  const [email, setEmail] = useState(teacher?.email || '');
  const [phone, setPhone] = useState(teacher?.phone || '');
  const [subject, setSubject] = useState(teacher?.subject || '');
  const [gender, setGender] = useState<'male' | 'female' | ''>(teacher?.gender || '');
  const [status, setStatus] = useState(teacher?.status || 'active');
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  const handleSave = async () => {
    if (!fullName.trim()) { setError('ກະລຸນາລະບຸຊື່'); return; }
    setSaving(true);
    const payload = {
      full_name: fullName.trim(),
      email: email.trim() || null,
      phone: phone.trim() || null,
      subject: subject || null,
      gender: gender || null,
      status,
    };
    if (teacher) {
      await supabase.from('teachers').update(payload).eq('id', teacher.id);
    } else {
      await supabase.from('teachers').insert(payload);
    }
    setSaving(false);
    onSaved();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/40 flex items-center justify-center p-4 animate-fade-in" onClick={onClose}>
      <div className="bg-white rounded-2xl shadow-xl max-w-lg w-full" onClick={(e) => e.stopPropagation()}>
        <div className="px-6 py-4 border-b border-ink-100 flex items-center justify-between">
          <h2 className="text-lg font-semibold text-ink-900">{teacher ? 'ແກ້ໄຂຄູອາຈານ' : 'ເພີ່ມຄູອາຈານ'}</h2>
          <button onClick={onClose}><X className="w-5 h-5 text-ink-400" /></button>
        </div>
        <div className="p-6 space-y-4">
          <div>
            <label className="label">ຊື່ເຕັມ</label>
            <input value={fullName} onChange={(e) => setFullName(e.target.value)} className="input" placeholder="ຊື່ເຕັມ" />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="label">ອີເມວ</label>
              <input value={email} onChange={(e) => setEmail(e.target.value)} className="input" placeholder="email@example.com" />
            </div>
            <div>
              <label className="label">ເບີໂທ</label>
              <input value={phone} onChange={(e) => setPhone(e.target.value)} className="input" placeholder="020 xxxx xxxx" />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="label">ວິຊາ</label>
              <select value={subject} onChange={(e) => setSubject(e.target.value)} className="input">
                <option value="">— ເລືອກວິຊາ —</option>
                {SUBJECTS.map((s) => <option key={s} value={s}>{s}</option>)}
              </select>
            </div>
            <div>
              <label className="label">ເພດ</label>
              <select value={gender} onChange={(e) => setGender(e.target.value as any)} className="input">
                <option value="">— ເລືອກເພດ —</option>
                <option value="male">ຊາຍ</option>
                <option value="female">ຍິງ</option>
              </select>
            </div>
          </div>
          <div>
            <label className="label">ສະຖານະ</label>
            <select value={status} onChange={(e) => setStatus(e.target.value)} className="input">
              <option value="active">ປະຈຳ</option>
              <option value="inactive">ພັກວຽກ</option>
            </select>
          </div>
          {error && <p className="text-sm text-red-500">{error}</p>}
        </div>
        <div className="px-6 py-4 border-t border-ink-100 flex justify-end gap-2">
          <button onClick={onClose} className="btn-secondary">ຍົກເລີກ</button>
          <button onClick={handleSave} disabled={saving} className="btn-primary">
            {saving ? 'ກຳລັງບັນທຶກ...' : 'ບັນທຶກ'}
          </button>
        </div>
      </div>
    </div>
  );
}
