import { useState, useEffect, useCallback } from 'react';
import { supabase } from '../../lib/supabase';
import type { TuitionWithStudent, PaymentSlipWithStudent, BankConfigRow, StudentRow, ClassRow } from '../../types';
import { TUITION_STATUS_STYLES, SLIP_STATUS_STYLES, formatCurrency, formatDate, formatDateTime, TERMS } from '../../constants';
import { InvoiceModal } from '../../components/InvoiceModal';
import {
  Receipt, FilePlus, Printer, Check, X, Eye, MessageSquare, Building2,
  Wallet, Clock, CheckCircle2, XCircle, Image as ImageIcon, Settings,
} from 'lucide-react';

const TABS = [
  { id: 'tuition', label: 'ບິນຄ່າຮຽນ', icon: Receipt },
  { id: 'slips', label: 'ໃບບິນໂອນເງິນ', icon: Wallet },
  { id: 'bank', label: 'ຕັ້ງຄ່າທະນາຄານ', icon: Building2 },
];

export default function TuitionManagement() {
  const [tab, setTab] = useState('tuition');
  return (
    <div>
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-ink-900">ຄ່າຮຽນ + ບິນ + QR</h1>
        <p className="text-sm text-ink-400 mt-1">ສ້າງບິນ, ພິມບິນ, ກວດສອບໃບບິນໂອນເງິນ, ແລະ ສົ່ງແຈ້ງເຕືອນ</p>
      </div>

      <div className="flex gap-1 mb-6 bg-white rounded-xl border border-ink-100 p-1 overflow-x-auto scrollbar-thin">
        {TABS.map((t) => {
          const Icon = t.icon;
          return (
            <button
              key={t.id}
              onClick={() => setTab(t.id)}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-lg text-sm font-medium whitespace-nowrap transition-all ${
                tab === t.id ? 'bg-brand-500 text-white' : 'text-ink-500 hover:bg-ink-50'
              }`}
            >
              <Icon className="w-4 h-4" />
              {t.label}
            </button>
          );
        })}
      </div>

      {tab === 'tuition' && <TuitionTab />}
      {tab === 'slips' && <SlipsTab />}
      {tab === 'bank' && <BankTab />}
    </div>
  );
}

function TuitionTab() {
  const [tuitions, setTuitions] = useState<TuitionWithStudent[]>([]);
  const [students, setStudents] = useState<StudentRow[]>([]);
  const [classes, setClasses] = useState<ClassRow[]>([]);
  const [bank, setBank] = useState<BankConfigRow | null>(null);
  const [loading, setLoading] = useState(true);
  const [showCreate, setShowCreate] = useState(false);
  const [printTarget, setPrintTarget] = useState<TuitionWithStudent | null>(null);
  const [smsTarget, setSmsTarget] = useState<TuitionWithStudent | null>(null);
  const [payTarget, setPayTarget] = useState<TuitionWithStudent | null>(null);

  const fetchData = useCallback(async () => {
    setLoading(true);
    const [{ data: t }, { data: s }, { data: c }, { data: b }] = await Promise.all([
      supabase.from('tuition').select('*').order('created_at', { ascending: false }),
      supabase.from('students').select('*').order('full_name'),
      supabase.from('classes').select('*').order('name'),
      supabase.from('bank_config').select('*').eq('active', true).maybeSingle(),
    ]);
    setBank(b as BankConfigRow | null);
    const classMap = new Map((c || []).map((x: ClassRow) => [x.id, x.name]));
    const studentMap = new Map((s || []).map((x: StudentRow) => [x.id, x]));
    const enriched: TuitionWithStudent[] = (t || []).map((row: any) => {
      const stu = studentMap.get(row.student_id);
      return {
        ...row,
        student_name: stu?.full_name,
        class_name: stu?.class_id ? classMap.get(stu.class_id) : undefined,
        parent_name: stu?.parent_name,
        parent_phone: stu?.parent_phone,
      };
    });
    setTuitions(enriched);
    setStudents(s || []);
    setClasses(c || []);
    setLoading(false);
  }, []);

  useEffect(() => { fetchData(); }, [fetchData]);

  return (
    <div>
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2 text-sm text-ink-500">
          <Receipt className="w-4 h-4" />
          <span>{tuitions.length} ບິນ</span>
        </div>
        <button onClick={() => setShowCreate(true)} className="btn-primary">
          <FilePlus className="w-4 h-4" />
          ສ້າງບິນເກັບເງິນ
        </button>
      </div>

      {loading ? (
        <div className="card p-8 text-center text-ink-400">ກຳລັງໂຫຼດ...</div>
      ) : tuitions.length === 0 ? (
        <div className="card p-8 text-center">
          <Receipt className="w-10 h-10 text-ink-300 mx-auto mb-3" />
          <p className="text-ink-400">ຍັງບໍ່ມີບິນເກັບເງິນ. ກົດ "ສ້າງບິນເກັບເງິນ" ເພື່ອເລີ່ມຕົ້ນ.</p>
        </div>
      ) : (
        <div className="card overflow-hidden">
          <div className="overflow-x-auto scrollbar-thin">
            <table className="w-full text-sm">
              <thead>
                <tr className="bg-ink-50 text-ink-500 text-xs uppercase">
                  <th className="text-left px-4 py-3 font-semibold">ເລກທີ່ບິນ</th>
                  <th className="text-left px-4 py-3 font-semibold">ນັກຮຽນ</th>
                  <th className="text-left px-4 py-3 font-semibold">ພາກຮຽນ</th>
                  <th className="text-right px-4 py-3 font-semibold">ຈຳນວນ</th>
                  <th className="text-right px-4 py-3 font-semibold">ຈ່າຍແລ້ວ</th>
                  <th className="text-center px-4 py-3 font-semibold">ສະຖານະ</th>
                  <th className="text-left px-4 py-3 font-semibold">ກຳນົດຊຳລະ</th>
                  <th className="text-center px-4 py-3 font-semibold">ການປະຕິບັດ</th>
                </tr>
              </thead>
              <tbody>
                {tuitions.map((t) => {
                  const st = TUITION_STATUS_STYLES[t.status] || TUITION_STATUS_STYLES.unpaid;
                  return (
                    <tr key={t.id} className="border-t border-ink-100 table-row">
                      <td className="px-4 py-3 font-mono text-xs text-ink-600">{t.invoice_number || '—'}</td>
                      <td className="px-4 py-3 font-medium text-ink-900">{t.student_name}</td>
                      <td className="px-4 py-3 text-ink-500">{t.term}</td>
                      <td className="px-4 py-3 text-right text-ink-900">{formatCurrency(t.amount)}</td>
                      <td className="px-4 py-3 text-right text-brand-600 font-medium">{formatCurrency(t.paid_amount)}</td>
                      <td className="px-4 py-3 text-center">
                        <span className={`badge ${st.badge}`}>
                          <span className={`w-1.5 h-1.5 rounded-full ${st.dot}`} />
                          {st.label}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-ink-500 text-xs">{formatDate(t.due_date)}</td>
                      <td className="px-4 py-3">
                        <div className="flex items-center justify-center gap-1">
                          <button onClick={() => setPrintTarget(t)} className="p-1.5 rounded-lg hover:bg-brand-50 text-ink-500 hover:text-brand-600 transition-colors" title="ພິມບິນ">
                            <Printer className="w-4 h-4" />
                          </button>
                          <button onClick={() => setSmsTarget(t)} className="p-1.5 rounded-lg hover:bg-sky-50 text-ink-500 hover:text-sky-600 transition-colors" title="ສົ່ງແຈ້ງເຕືອນ">
                            <MessageSquare className="w-4 h-4" />
                          </button>
                          {t.status !== 'paid' && (
                            <button onClick={() => setPayTarget(t)} className="p-1.5 rounded-lg hover:bg-amber-50 text-ink-500 hover:text-amber-600 transition-colors" title="ບັນທຶກການຊຳລະ">
                              <Wallet className="w-4 h-4" />
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {showCreate && (
        <CreateInvoiceModal
          students={students}
          classes={classes}
          onClose={() => setShowCreate(false)}
          onCreated={() => { setShowCreate(false); fetchData(); }}
        />
      )}

      {printTarget && (
        <InvoiceModal tuition={printTarget} bank={bank} onClose={() => setPrintTarget(null)} />
      )}

      {smsTarget && (
        <SmsModal tuition={smsTarget} onClose={() => setSmsTarget(null)} onSent={fetchData} />
      )}

      {payTarget && (
        <PaymentModal tuition={payTarget} onClose={() => setPayTarget(null)} onPaid={fetchData} />
      )}
    </div>
  );
}

function CreateInvoiceModal({ students, classes, onClose, onCreated }: {
  students: StudentRow[];
  classes: ClassRow[];
  onClose: () => void;
  onCreated: () => void;
}) {
  const [studentId, setStudentId] = useState('');
  const [term, setTerm] = useState(TERMS[0]);
  const [amount, setAmount] = useState('');
  const [dueDate, setDueDate] = useState('');
  const [note, setNote] = useState('');
  const [batchClass, setBatchClass] = useState('');
  const [batchMode, setBatchMode] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  const generateInvoiceNumber = async (): Promise<string> => {
    const now = new Date();
    const ym = `${now.getFullYear()}${String(now.getMonth() + 1).padStart(2, '0')}`;
    const { data } = await supabase
      .from('tuition')
      .select('invoice_number')
      .like('invoice_number', `INV-${ym}-%`)
      .order('invoice_number', { ascending: false })
      .limit(1);
    let next = 1;
    if (data && data.length > 0 && data[0].invoice_number) {
      const parts = data[0].invoice_number.split('-');
      next = parseInt(parts[2] || '0', 10) + 1;
    }
    return `INV-${ym}-${String(next).padStart(4, '0')}`;
  };

  const handleCreate = async () => {
    setError('');
    if (batchMode) {
      if (!batchClass) { setError('ກະລຸນາເລືອກຫ້ອງຮຽນ'); return; }
      if (!amount) { setError('ກະລຸນາລະບຸຈຳນວນເງິນ'); return; }
      setSaving(true);
      const targetStudents = students.filter((s) => s.class_id === batchClass);
      for (const stu of targetStudents) {
        const invNum = await generateInvoiceNumber();
        await supabase.from('tuition').insert({
          student_id: stu.id,
          term,
          amount: parseFloat(amount),
          paid_amount: 0,
          status: 'unpaid',
          due_date: dueDate || null,
          note: note || null,
          invoice_number: invNum,
        });
      }
      setSaving(false);
      onCreated();
    } else {
      if (!studentId) { setError('ກະລຸນາເລືອກນັກຮຽນ'); return; }
      if (!amount) { setError('ກະລຸນາລະບຸຈຳນວນເງິນ'); return; }
      setSaving(true);
      const invNum = await generateInvoiceNumber();
      const { error: insErr } = await supabase.from('tuition').insert({
        student_id: studentId,
        term,
        amount: parseFloat(amount),
        paid_amount: 0,
        status: 'unpaid',
        due_date: dueDate || null,
        note: note || null,
        invoice_number: invNum,
      });
      setSaving(false);
      if (insErr) { setError(insErr.message); return; }
      onCreated();
    }
  };

  const className = (id: string) => classes.find((c) => c.id === id)?.name || '—';

  return (
    <div className="fixed inset-0 z-50 bg-black/40 flex items-center justify-center p-4 animate-fade-in" onClick={onClose}>
      <div className="bg-white rounded-2xl shadow-xl max-w-lg w-full" onClick={(e) => e.stopPropagation()}>
        <div className="px-6 py-4 border-b border-ink-100">
          <h2 className="text-lg font-semibold text-ink-900">ສ້າງບິນເກັບເງິນຄ່າຮຽນ</h2>
        </div>
        <div className="p-6 space-y-4">
          <div className="flex gap-2 bg-ink-50 rounded-xl p-1">
            <button onClick={() => setBatchMode(false)} className={`flex-1 py-2 rounded-lg text-sm font-medium transition-all ${!batchMode ? 'bg-white shadow text-ink-900' : 'text-ink-500'}`}>
              ສ້າງໃຫ້ນັກຮຽນເລີຍ
            </button>
            <button onClick={() => setBatchMode(true)} className={`flex-1 py-2 rounded-lg text-sm font-medium transition-all ${batchMode ? 'bg-white shadow text-ink-900' : 'text-ink-500'}`}>
              ສ້າງໃຫ້ທັງຫ້ອງ
            </button>
          </div>

          {batchMode ? (
            <div>
              <label className="label">ເລືອກຫ້ອງຮຽນ</label>
              <select value={batchClass} onChange={(e) => setBatchClass(e.target.value)} className="input">
                <option value="">— ເລືອກຫ້ອງ —</option>
                {classes.map((c) => (
                  <option key={c.id} value={c.id}>{c.name}</option>
                ))}
              </select>
              {batchClass && (
                <p className="text-xs text-ink-400 mt-1">
                  ຈະສ້າງບິນໃຫ້ {students.filter((s) => s.class_id === batchClass).length} ນັກຮຽນ
                </p>
              )}
            </div>
          ) : (
            <div>
              <label className="label">ເລືອກນັກຮຽນ</label>
              <select value={studentId} onChange={(e) => setStudentId(e.target.value)} className="input">
                <option value="">— ເລືອກນັກຮຽນ —</option>
                {students.map((s) => (
                  <option key={s.id} value={s.id}>{s.full_name} — {className(s.class_id || '')}</option>
                ))}
              </select>
            </div>
          )}

          <div>
            <label className="label">ພາກຮຽນ</label>
            <select value={term} onChange={(e) => setTerm(e.target.value)} className="input">
              {TERMS.map((t) => <option key={t} value={t}>{t}</option>)}
            </select>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="label">ຈຳນວນເງິນ (ກີບ)</label>
              <input type="number" value={amount} onChange={(e) => setAmount(e.target.value)} className="input" placeholder="ເຊັ່ນ 500000" />
            </div>
            <div>
              <label className="label">ກຳນົດວັນຊຳລະ</label>
              <input type="date" value={dueDate} onChange={(e) => setDueDate(e.target.value)} className="input" />
            </div>
          </div>

          <div>
            <label className="label">ໝາຍເຫດ (ທາງເລືອກ)</label>
            <input value={note} onChange={(e) => setNote(e.target.value)} className="input" placeholder="ເຊັ່ນ ຄ່າຮຽນ + ຄ່າອາຫານ ແລະ ອື່ນໆ" />
          </div>

          {error && <p className="text-sm text-red-500">{error}</p>}
        </div>
        <div className="px-6 py-4 border-t border-ink-100 flex justify-end gap-2">
          <button onClick={onClose} className="btn-secondary">ຍົກເລີກ</button>
          <button onClick={handleCreate} disabled={saving} className="btn-primary">
            {saving ? 'ກຳລັງສ້າງ...' : 'ສ້າງບິນ'}
          </button>
        </div>
      </div>
    </div>
  );
}

function PaymentModal({ tuition, onClose, onPaid }: {
  tuition: TuitionWithStudent;
  onClose: () => void;
  onPaid: () => void;
}) {
  const [amount, setAmount] = useState(String(tuition.amount - tuition.paid_amount));
  const [method, setMethod] = useState('qr');
  const [saving, setSaving] = useState(false);

  const handleSave = async () => {
    setSaving(true);
    const payAmount = parseFloat(amount) || 0;
    const newPaid = tuition.paid_amount + payAmount;
    const newStatus = newPaid >= tuition.amount ? 'paid' : 'partial';
    const today = new Date().toISOString().slice(0, 10);
    await supabase.from('tuition').update({
      paid_amount: newPaid,
      status: newStatus,
      paid_date: newStatus === 'paid' ? today : tuition.paid_date,
      method,
    }).eq('id', tuition.id);
    setSaving(false);
    onPaid();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/40 flex items-center justify-center p-4 animate-fade-in" onClick={onClose}>
      <div className="bg-white rounded-2xl shadow-xl max-w-md w-full" onClick={(e) => e.stopPropagation()}>
        <div className="px-6 py-4 border-b border-ink-100">
          <h2 className="text-lg font-semibold text-ink-900">ບັນທຶກການຊຳລະ</h2>
          <p className="text-sm text-ink-400">{tuition.student_name} — {tuition.term}</p>
        </div>
        <div className="p-6 space-y-4">
          <div className="bg-ink-50 rounded-xl p-3 text-sm">
            <div className="flex justify-between"><span className="text-ink-400">ຍອດລວມ</span><span className="font-medium">{formatCurrency(tuition.amount)}</span></div>
            <div className="flex justify-between"><span className="text-ink-400">ຈ່າຍແລ້ວ</span><span className="font-medium text-brand-600">{formatCurrency(tuition.paid_amount)}</span></div>
            <div className="flex justify-between"><span className="text-ink-400">ຍັງຄ້າງ</span><span className="font-medium text-red-500">{formatCurrency(tuition.amount - tuition.paid_amount)}</span></div>
          </div>
          <div>
            <label className="label">ຈຳນວນທີ່ຮັບ</label>
            <input type="number" value={amount} onChange={(e) => setAmount(e.target.value)} className="input" />
          </div>
          <div>
            <label className="label">ວິທີຊຳລະ</label>
            <select value={method} onChange={(e) => setMethod(e.target.value)} className="input">
              <option value="qr">QR Code</option>
              <option value="cash">ເງິນສົດ</option>
              <option value="transfer">ໂອນທະນາຄານ</option>
            </select>
          </div>
        </div>
        <div className="px-6 py-4 border-t border-ink-100 flex justify-end gap-2">
          <button onClick={onClose} className="btn-secondary">ຍົກເລີກ</button>
          <button onClick={handleSave} disabled={saving} className="btn-primary">
            {saving ? 'ກຳລັງບັນທຶກ...' : 'ບັນທຶກ'}
          </button>
        </div>
      </div>
    </div>
  );
}

function SmsModal({ tuition, onClose, onSent }: {
  tuition: TuitionWithStudent;
  onClose: () => void;
  onSent: () => void;
}) {
  const [message, setMessage] = useState(
    `ສະບາຍດິ, ບິນເກັບເງິນຄ່າຮຽນ ${tuition.term} ຂອງ ${tuition.student_name} ຍັງຄ້າງຊຳລະ ${formatCurrency(tuition.amount - tuition.paid_amount)}. ກະລຸນາຊຳລະກ່ອນວັນທີ ${formatDate(tuition.due_date)}. ຂອບໃຈ.`
  );
  const [sending, setSending] = useState(false);
  const [sent, setSent] = useState(false);
  const phone = tuition.parent_phone || '';

  const handleSend = async () => {
    if (!phone) return;
    setSending(true);
    const { data: slipData } = await supabase
      .from('payment_slips')
      .select('id')
      .eq('tuition_id', tuition.id)
      .order('uploaded_at', { ascending: false })
      .limit(1)
      .maybeSingle();

    await supabase.from('tuition').update({
      sms_sent_at: new Date().toISOString(),
      sms_sent_count: (tuition.sms_sent_count || 0) + 1,
    }).eq('id', tuition.id);

    setSending(false);
    setSent(true);
    setTimeout(() => { onSent(); onClose(); }, 1500);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/40 flex items-center justify-center p-4 animate-fade-in" onClick={onClose}>
      <div className="bg-white rounded-2xl shadow-xl max-w-md w-full" onClick={(e) => e.stopPropagation()}>
        <div className="px-6 py-4 border-b border-ink-100">
          <h2 className="text-lg font-semibold text-ink-900">ສົ່ງແຈ້ງເຕືອນຜ່ານ SMS</h2>
          <p className="text-sm text-ink-400">{tuition.student_name} — {tuition.term}</p>
        </div>
        <div className="p-6 space-y-4">
          {!phone ? (
            <div className="bg-amber-50 rounded-xl p-4 text-sm text-amber-700">
              ບໍ່ມີເບີໂທລະສັບຂອງຜູ້ປົກຄອງ. ກະລຸນາແກ້ຂໍ້ມູນນັກຮຽນເພື່ອເພີ່ມເບີຕິດຕໍ່.
            </div>
          ) : (
            <>
              <div>
                <label className="label">ເບີໂທລະສັບຜູ້ປົກຄອງ</label>
                <input value={phone} readOnly className="input bg-ink-50" />
              </div>
              <div>
                <label className="label">ຂໍ້ຄວາມ</label>
                <textarea value={message} onChange={(e) => setMessage(e.target.value)} rows={4} className="input resize-none" />
                <p className="text-xs text-ink-400 mt-1">{message.length} ຕົວອັກສອນ</p>
              </div>
              {tuition.sms_sent_count > 0 && (
                <p className="text-xs text-ink-400">
                  ສົ່ງແຈ້ງເຕືອນແລ້ວ {tuition.sms_sent_count} ຄັ້ງ (ຄັ້ງລ່າສຸດ: {formatDateTime(tuition.sms_sent_at)})
                </p>
              )}
            </>
          )}
          {sent && (
            <div className="bg-brand-50 rounded-xl p-4 text-sm text-brand-700 flex items-center gap-2">
              <CheckCircle2 className="w-5 h-5" />
              ສົ່ງແຈ້ງເຕືອນສຳເລັດແລ້ວ!
            </div>
          )}
        </div>
        {phone && !sent && (
          <div className="px-6 py-4 border-t border-ink-100 flex justify-end gap-2">
            <button onClick={onClose} className="btn-secondary">ຍົກເລີກ</button>
            <button onClick={handleSend} disabled={sending} className="btn-primary">
              <MessageSquare className="w-4 h-4" />
              {sending ? 'ກຳລັງສົ່ງ...' : 'ສົ່ງ SMS'}
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

function SlipsTab() {
  const [slips, setSlips] = useState<PaymentSlipWithStudent[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('pending');
  const [previewSlip, setPreviewSlip] = useState<PaymentSlipWithStudent | null>(null);
  const [reviewSlip, setReviewSlip] = useState<PaymentSlipWithStudent | null>(null);
  const [rejectReason, setRejectReason] = useState('');
  const [reviewMode, setReviewMode] = useState<'approve' | 'reject'>('approve');

  const fetchSlips = useCallback(async () => {
    setLoading(true);
    const { data } = await supabase
      .from('payment_slips')
      .select('*')
      .order('uploaded_at', { ascending: false });
    const { data: students } = await supabase.from('students').select('id, full_name');
    const studentMap = new Map((students || []).map((s: any) => [s.id, s.full_name]));
    const enriched: PaymentSlipWithStudent[] = (data || []).map((row: any) => ({
      ...row,
      student_name: studentMap.get(row.student_id) || '—',
      student_full_name: studentMap.get(row.student_id) || '—',
    }));
    setSlips(enriched);
    setLoading(false);
  }, []);

  useEffect(() => { fetchSlips(); }, [fetchSlips]);

  const filtered = slips.filter((s) => filter === 'all' || s.status === filter);

  const handleApprove = async (slip: PaymentSlipWithStudent) => {
    const { data: tuition } = await supabase.from('tuition').select('*').eq('id', slip.tuition_id).maybeSingle();
    if (tuition) {
      const newPaid = (tuition.paid_amount || 0) + slip.amount;
      const newStatus = newPaid >= tuition.amount ? 'paid' : 'partial';
      const today = new Date().toISOString().slice(0, 10);
      await supabase.from('tuition').update({
        paid_amount: newPaid,
        status: newStatus,
        paid_date: newStatus === 'paid' ? today : tuition.paid_date,
        method: 'qr',
      }).eq('id', tuition.id);
    }
    await supabase.from('payment_slips').update({
      status: 'approved',
      reviewed_at: new Date().toISOString(),
      reviewed_by: 'admin',
    }).eq('id', slip.id);
    setReviewSlip(null);
    fetchSlips();
  };

  const handleReject = async (slip: PaymentSlipWithStudent, reason: string) => {
    await supabase.from('payment_slips').update({
      status: 'rejected',
      reviewed_at: new Date().toISOString(),
      reviewed_by: 'admin',
      admin_note: reason,
    }).eq('id', slip.id);
    setReviewSlip(null);
    fetchSlips();
  };

  const counts = {
    pending: slips.filter((s) => s.status === 'pending').length,
    approved: slips.filter((s) => s.status === 'approved').length,
    rejected: slips.filter((s) => s.status === 'rejected').length,
    all: slips.length,
  };

  return (
    <div>
      <div className="flex gap-2 mb-4 flex-wrap">
        {(['pending', 'approved', 'rejected', 'all'] as const).map((f) => (
          <button
            key={f}
            onClick={() => setFilter(f)}
            className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-all ${
              filter === f ? 'bg-brand-500 text-white' : 'bg-white border border-ink-200 text-ink-600 hover:bg-ink-50'
            }`}
          >
            {f === 'all' ? 'ທັງໝົດ' : f === 'pending' ? 'ລໍຖ້າກວດສອບ' : f === 'approved' ? 'ອະນຸມັດແລ້ວ' : 'ປະຕິເສດ'}
            <span className="ml-1.5 text-xs opacity-70">({counts[f]})</span>
          </button>
        ))}
      </div>

      {loading ? (
        <div className="card p-8 text-center text-ink-400">ກຳລັງໂຫຼດ...</div>
      ) : filtered.length === 0 ? (
        <div className="card p-8 text-center">
          <Wallet className="w-10 h-10 text-ink-300 mx-auto mb-3" />
          <p className="text-ink-400">ບໍ່ມີໃບບິນໂອນເງິນ</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {filtered.map((slip) => {
            const st = SLIP_STATUS_STYLES[slip.status] || SLIP_STATUS_STYLES.pending;
            return (
              <div key={slip.id} className="card overflow-hidden">
                <div className="relative aspect-video bg-ink-50 cursor-pointer" onClick={() => setPreviewSlip(slip)}>
                  <img src={slip.slip_url} alt="slip" className="w-full h-full object-cover" />
                  <div className="absolute top-2 right-2">
                    <span className={`badge ${st.badge}`}>
                      <span className={`w-1.5 h-1.5 rounded-full ${st.dot}`} />
                      {st.label}
                    </span>
                  </div>
                </div>
                <div className="p-4">
                  <p className="font-medium text-ink-900 text-sm">{slip.student_name}</p>
                  <p className="text-xs text-ink-400 mt-0.5">{formatCurrency(slip.amount)}</p>
                  <p className="text-xs text-ink-400 mt-0.5">{formatDateTime(slip.uploaded_at)}</p>
                  {slip.status === 'rejected' && slip.admin_note && (
                    <p className="text-xs text-red-500 mt-1">ເຫດຜົນປະຕິເສດ: {slip.admin_note}</p>
                  )}
                  <div className="flex items-center gap-2 mt-3">
                    <button onClick={() => setPreviewSlip(slip)} className="btn-ghost flex-1">
                      <Eye className="w-4 h-4" />ເບິ່ງ
                    </button>
                    {slip.status === 'pending' && (
                      <>
                        <button onClick={() => { setReviewSlip(slip); setReviewMode('approve'); }} className="p-2 rounded-lg bg-brand-50 text-brand-600 hover:bg-brand-100 transition-colors" title="ອະນຸມັດ">
                          <Check className="w-4 h-4" />
                        </button>
                        <button onClick={() => { setReviewSlip(slip); setReviewMode('reject'); }} className="p-2 rounded-lg bg-red-50 text-red-600 hover:bg-red-100 transition-colors" title="ປະຕິເສດ">
                          <X className="w-4 h-4" />
                        </button>
                      </>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {previewSlip && (
        <div className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4 animate-fade-in" onClick={() => setPreviewSlip(null)}>
          <img src={previewSlip.slip_url} alt="slip preview" className="max-w-full max-h-[90vh] rounded-xl" />
          <button className="absolute top-4 right-4 text-white p-2 rounded-lg bg-white/20 hover:bg-white/30">
            <X className="w-6 h-6" />
          </button>
        </div>
      )}

      {reviewSlip && (
        <div className="fixed inset-0 z-50 bg-black/40 flex items-center justify-center p-4 animate-fade-in" onClick={() => setReviewSlip(null)}>
          <div className="bg-white rounded-2xl shadow-xl max-w-lg w-full" onClick={(e) => e.stopPropagation()}>
            <div className="px-6 py-4 border-b border-ink-100 flex items-center justify-between">
              <h2 className="text-lg font-semibold text-ink-900">
                {reviewMode === 'approve' ? 'ອະນຸມັດໃບບິນ' : 'ປະຕິເສດໃບບິນ'}
              </h2>
              <button onClick={() => setReviewSlip(null)}><X className="w-5 h-5 text-ink-400" /></button>
            </div>
            <div className="p-6">
              <img src={reviewSlip.slip_url} alt="slip" className="w-full rounded-xl mb-4 max-h-60 object-contain bg-ink-50" />
              <p className="font-medium text-ink-900">{reviewSlip.student_name}</p>
              <p className="text-sm text-ink-500">{formatCurrency(reviewSlip.amount)}</p>
              <p className="text-xs text-ink-400 mt-1">{formatDateTime(reviewSlip.uploaded_at)}</p>
              {reviewMode === 'reject' && (
                <div className="mt-4">
                  <label className="label">ເຫດຜົນປະຕິເສດ</label>
                  <textarea value={rejectReason} onChange={(e) => setRejectReason(e.target.value)} rows={3} className="input resize-none" placeholder="ເຊັ່ນ ຈຳນວນເງິນບໍ່ຕົງ, ໃບບິນບໍ່ຈະແຈ້ງ..." />
                </div>
              )}
            </div>
            <div className="px-6 py-4 border-t border-ink-100 flex justify-end gap-2">
              <button onClick={() => setReviewSlip(null)} className="btn-secondary">ຍົກເລີກ</button>
              {reviewMode === 'approve' ? (
                <button onClick={() => handleApprove(reviewSlip)} className="btn-primary">
                  <Check className="w-4 h-4" />ອະນຸມັດ
                </button>
              ) : (
                <button onClick={() => handleReject(reviewSlip, rejectReason || 'ບໍ່ຮັບອະນຸມັດ')} disabled={!rejectReason} className="btn-danger">
                  <X className="w-4 h-4" />ປະຕິເສດ
                </button>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function BankTab() {
  const [bank, setBank] = useState<BankConfigRow | null>(null);
  const [loading, setLoading] = useState(true);
  const [showSettings, setShowSettings] = useState(false);

  useEffect(() => {
    (async () => {
      const { data } = await supabase.from('bank_config').select('*').eq('active', true).maybeSingle();
      setBank(data as BankConfigRow | null);
      setLoading(false);
    })();
  }, []);

  if (loading) return <div className="card p-8 text-center text-ink-400">ກຳລັງໂຫຼດ...</div>;
  if (!bank) return <div className="card p-8 text-center text-ink-400">ບໍ່ມີການຕັ້ງຄ່າທະນາຄານ</div>;

  return (
    <div>
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-lg font-semibold text-ink-900">ຂໍ້ມູນທະນາຄານ</h2>
        <button onClick={() => setShowSettings(true)} className="btn-secondary">
          <Settings className="w-4 h-4" />
          ແກ້ໄຂ
        </button>
      </div>

      <div className="card p-6 max-w-lg">
        <div className="flex items-start gap-4 mb-4">
          <div className="w-12 h-12 rounded-xl bg-brand-50 flex items-center justify-center">
            <Building2 className="w-6 h-6 text-brand-600" />
          </div>
          <div>
            <p className="text-xs text-ink-400">ທະນາຄານ</p>
            <p className="text-base font-semibold text-ink-900">{bank.bank_name}</p>
          </div>
        </div>
        <div className="space-y-3 border-t border-ink-100 pt-4">
          <div>
            <p className="text-xs text-ink-400">ຊື່ບັນຊີ</p>
            <p className="text-sm font-medium text-ink-900">{bank.account_name}</p>
          </div>
          <div>
            <p className="text-xs text-ink-400">ເບີບັນຊີ</p>
            <p className="text-sm font-medium text-ink-900 tracking-wider">{bank.account_number}</p>
          </div>
          <div>
            <p className="text-xs text-ink-400">ປະເພດ QR</p>
            <span className={`chip ${bank.is_static ? 'bg-sky-50 text-sky-600' : 'bg-brand-50 text-brand-700'}`}>
              {bank.is_static ? 'Static QR' : 'Dynamic QR'}
            </span>
          </div>
        </div>
      </div>

      {showSettings && (
        <BankSettingsModal bank={bank} onClose={() => setShowSettings(false)} onSaved={(b) => { setBank(b); setShowSettings(false); }} />
      )}
    </div>
  );
}

function BankSettingsModal({ bank, onClose, onSaved }: {
  bank: BankConfigRow;
  onClose: () => void;
  onSaved: (b: BankConfigRow) => void;
}) {
  const [bankName, setBankName] = useState(bank.bank_name);
  const [accountName, setAccountName] = useState(bank.account_name);
  const [accountNumber, setAccountNumber] = useState(bank.account_number);
  const [isStatic, setIsStatic] = useState(bank.is_static);
  const [qrPayload, setQrPayload] = useState(bank.qr_payload || '');
  const [saving, setSaving] = useState(false);

  const handleSave = async () => {
    setSaving(true);
    const { data } = await supabase.from('bank_config').update({
      bank_name: bankName,
      account_name: accountName,
      account_number: accountNumber,
      is_static: isStatic,
      qr_payload: isStatic ? qrPayload : null,
    }).eq('id', bank.id).select().single();
    setSaving(false);
    if (data) onSaved(data as BankConfigRow);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/40 flex items-center justify-center p-4 animate-fade-in" onClick={onClose}>
      <div className="bg-white rounded-2xl shadow-xl max-w-md w-full" onClick={(e) => e.stopPropagation()}>
        <div className="px-6 py-4 border-b border-ink-100">
          <h2 className="text-lg font-semibold text-ink-900">ຕັ້ງຄ່າທະນາຄານ</h2>
        </div>
        <div className="p-6 space-y-4">
          <div>
            <label className="label">ຊື່ທະນາຄານ</label>
            <input value={bankName} onChange={(e) => setBankName(e.target.value)} className="input" />
          </div>
          <div>
            <label className="label">ຊື່ບັນຊີ</label>
            <input value={accountName} onChange={(e) => setAccountName(e.target.value)} className="input" />
          </div>
          <div>
            <label className="label">ເບີບັນຊີ</label>
            <input value={accountNumber} onChange={(e) => setAccountNumber(e.target.value)} className="input" />
          </div>
          <div className="flex gap-2 bg-ink-50 rounded-xl p-1">
            <button onClick={() => setIsStatic(false)} className={`flex-1 py-2 rounded-lg text-sm font-medium transition-all ${!isStatic ? 'bg-white shadow text-ink-900' : 'text-ink-500'}`}>
              Dynamic QR
            </button>
            <button onClick={() => setIsStatic(true)} className={`flex-1 py-2 rounded-lg text-sm font-medium transition-all ${isStatic ? 'bg-white shadow text-ink-900' : 'text-ink-500'}`}>
              Static QR
            </button>
          </div>
          {isStatic && (
            <div>
              <label className="label">QR Payload (ສຳລັບ Static QR)</label>
              <textarea value={qrPayload} onChange={(e) => setQrPayload(e.target.value)} rows={3} className="input resize-none" placeholder="ໃສ່ payload ຈາກທະນາຄານ..." />
            </div>
          )}
        </div>
        <div className="px-6 py-4 border-t border-ink-100 flex justify-end gap-2">
          <button onClick={onClose} className="btn-secondary">ຍົກເລີກ</button>
          <button onClick={handleSave} disabled={saving} className="btn-primary">
            {saving ? 'ກຳລັງບັນທຶກ...' : 'ບັນທຶກ'}
          </button>
        </div>
      </div>
    </div>
  );
}
