import { useEffect, useState, useMemo, useCallback } from 'react';
import { Megaphone, Search, Filter } from 'lucide-react';
import { supabase } from '../../lib/supabase';
import type { Role, AnnouncementRow } from '../../types';
import { LoadingPage, EmptyState } from '../../components/ui';
import { ANNOUNCEMENT_CATEGORIES, AUDIENCES, timeAgo, formatDate } from '../../constants';

export function AnnouncementView({ role }: { role: Role }) {
  const [loading, setLoading] = useState(true);
  const [items, setItems] = useState<AnnouncementRow[]>([]);
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState<string>('all');

  const load = useCallback(async () => {
    setLoading(true);
    const { data } = await supabase.from('announcements').select('*').order('created_at', { ascending: false });
    setItems((data as AnnouncementRow[]) || []);
    setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  const roleAudience = role === 'teacher' ? 'teachers' : role === 'student' ? 'students' : null;
  const visible = useMemo(() => {
    return items
      .filter((a) => a.audience === 'all' || (roleAudience && a.audience === roleAudience))
      .filter((a) => category === 'all' || a.category === category)
      .filter((a) => {
        const q = search.trim().toLowerCase();
        if (!q) return true;
        return a.title.toLowerCase().includes(q) || a.content.toLowerCase().includes(q);
      });
  }, [items, roleAudience, category, search]);

  if (loading) return <LoadingPage label="ກຳລັງໂຫຼດແຈ້ງການ..." />;

  const catLabel = (val: string) => ANNOUNCEMENT_CATEGORIES.find((c) => c.value === val)?.label ?? val;
  const catColor = (val: string) => ANNOUNCEMENT_CATEGORIES.find((c) => c.value === val)?.color ?? 'bg-ink-100 text-ink-700';
  const audLabel = (val: string) => AUDIENCES.find((a) => a.value === val)?.label ?? val;

  return (
    <div className="space-y-5">
      <div>
        <h2 className="text-lg font-semibold text-ink-900">ແຈ້ງການ</h2>
        <p className="text-sm text-ink-500">ຂ່າວສານ ແລະ ກິດຈະກຳຈາກໂຮງຮຽນ</p>
      </div>

      {/* Filters */}
      <div className="card p-4 flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-ink-400" />
          <input
            className="input pl-10"
            placeholder="ຄົ້ນຫາແຈ້ງການ..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
        <div className="relative sm:w-52">
          <Filter size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-ink-400 pointer-events-none" />
          <select
            className="input pl-10 appearance-none"
            value={category}
            onChange={(e) => setCategory(e.target.value)}
          >
            <option value="all">ທຸກໝວດໝູ່</option>
            {ANNOUNCEMENT_CATEGORIES.map((c) => (
              <option key={c.value} value={c.value}>{c.label}</option>
            ))}
          </select>
        </div>
      </div>

      {/* List */}
      {visible.length === 0 ? (
        <div className="card"><EmptyState icon={Megaphone} title="ບໍ່ມີແຈ້ງການ" hint="ຍັງບໍ່ມີຂໍ້ມູນແຈ້ງການທີ່ກົງກັບ" /></div>
      ) : (
        <div className="grid grid-cols-1 gap-3">
          {visible.map((a) => (
            <div key={a.id} className="card p-5 hover:shadow-soft transition-shadow duration-200">
              <div className="flex items-start justify-between gap-3">
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-2 mb-2">
                    <span className={`badge ${catColor(a.category)}`}>{catLabel(a.category)}</span>
                    <span className="chip bg-ink-100 text-ink-600">{audLabel(a.audience)}</span>
                    {a.author && <span className="text-xs text-ink-400">ໂດຍ {a.author}</span>}
                  </div>
                  <h3 className="font-semibold text-ink-900">{a.title}</h3>
                  <p className="mt-1.5 text-sm text-ink-600 leading-relaxed whitespace-pre-line">{a.content}</p>
                </div>
              </div>
              <div className="mt-3 flex items-center gap-3 border-t border-ink-50 pt-2.5 text-xs text-ink-400">
                <span>{formatDate(a.created_at)}</span>
                <span className="text-ink-300">·</span>
                <span>{timeAgo(a.created_at)}</span>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
