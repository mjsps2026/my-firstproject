import { useState, useEffect, useCallback, useMemo } from 'react';
import { supabase } from '../../lib/supabase';
import type { StudentRow, ClassRow, GradeRow, BehaviorRow } from '../../types';
import { TERMS, SCHOOL_NAME, formatDate } from '../../constants';
import { FileText, Printer, Award, Heart, GraduationCap, TrendingUp, Calendar, User } from 'lucide-react';

const letterFromPct = (pct: number): string => {
  if (pct >= 90) return 'A';
  if (pct >= 80) return 'B';
  if (pct >= 70) return 'C';
  if (pct >= 60) return 'D';
  return 'F';
};

const gpaFromPct = (pct: number): number => {
  if (pct >= 90) return 4;
  if (pct >= 80) return 3;
  if (pct >= 70) return 2;
  if (pct >= 60) return 1;
  return 0;
};

interface SubjectSummary {
  subject: string;
  avgPct: number;
  letter: string;
  count: number;
}

export default function ReportCard({ student }: { student: StudentRow }) {
  const [term, setTerm] = useState(TERMS[0]);
  const [className, setClassName] = useState('—');
  const [grades, setGrades] = useState<GradeRow[]>([]);
  const [behavior, setBehavior] = useState<BehaviorRow[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchData = useCallback(async () => {
    setLoading(true);
    const [classRes, gradeRes, behRes] = await Promise.all([
      supabase.from('classes').select('*').eq('id', student.class_id || '').maybeSingle(),
      supabase.from('grades').select('*').eq('student_id', student.id).eq('term', term),
      supabase.from('behavior_records').select('*').eq('student_id', student.id),
    ]);
    setClassName((classRes.data as ClassRow | null)?.name || '—');
    setGrades((gradeRes.data || []) as GradeRow[]);
    setBehavior((behRes.data || []) as BehaviorRow[]);
    setLoading(false);
  }, [student.id, student.class_id, term]);

  useEffect(() => { fetchData(); }, [fetchData]);

  const subjects = useMemo<SubjectSummary[]>(() => {
    const map = new Map<string, GradeRow[]>();
    grades.forEach((g) => {
      const arr = map.get(g.subject) || [];
      arr.push(g);
      map.set(g.subject, arr);
    });
    return Array.from(map.entries()).map(([subject, gs]) => {
      const avgPct = gs.reduce((s, g) => s + (g.score / g.max_score) * 100, 0) / gs.length;
      const letters = gs.map((g) => g.grade_letter || letterFromPct((g.score / g.max_score) * 100));
      // pick the most common letter, fallback to letter derived from average
      const letter = letters[0] || letterFromPct(avgPct);
      return { subject, avgPct: Math.round(avgPct * 10) / 10, letter, count: gs.length };
    });
  }, [grades]);

  const gpa = useMemo(() => {
    if (!grades.length) return 0;
    const total = grades.reduce(
      (s, g) => s + gpaFromPct((g.score / g.max_score) * 100),
      0
    );
    return Math.round((total / grades.length) * 100) / 100;
  }, [grades]);

  const positivePts = behavior.filter((b) => b.type === 'positive').reduce((s, b) => s + b.points, 0);
  const negativePts = behavior.filter((b) => b.type === 'negative').reduce((s, b) => s + b.points, 0);
  const netPts = positivePts - negativePts;

  if (loading) return <div className="card p-8 text-center text-ink-400">ກຳລັງໂຫຼດ...</div>;

  return (
    <div>
      <div className="flex flex-wrap items-center justify-between gap-3 mb-6 no-print">
        <div>
          <h1 className="text-2xl font-bold text-ink-900">ໃບຜະລິດຜົນ</h1>
          <p className="text-sm text-ink-400 mt-1">ໃບຜະລິດຜົນການຮຽນຂອງ {student.full_name}</p>
        </div>
        <div className="flex items-center gap-2">
          <select value={term} onChange={(e) => setTerm(e.target.value)} className="input w-auto">
            {TERMS.map((t) => (
              <option key={t} value={t}>{t}</option>
            ))}
          </select>
          <button onClick={() => window.print()} className="btn-primary">
            <Printer className="w-4 h-4" />
            ພິມ
          </button>
        </div>
      </div>

      <div className="print-area card p-6 sm:p-8 max-w-3xl">
        {/* Header */}
        <div className="text-center border-b border-ink-200 pb-5 mb-6">
          <h2 className="text-xl font-bold text-ink-900">{SCHOOL_NAME}</h2>
          <p className="text-sm text-ink-500 mt-1">ໃບຜະລິດຜົນການຮຽນ</p>
          <p className="text-sm font-medium text-ink-700 mt-2">{term}</p>
        </div>

        {/* Student info */}
        <div className="grid grid-cols-2 gap-x-6 gap-y-3 mb-6 text-sm">
          <div className="flex items-center gap-2">
            <User className="w-4 h-4 text-ink-400" />
            <span className="text-ink-400">ຊື່ເຕັມ:</span>
            <span className="font-medium text-ink-900">{student.full_name}</span>
          </div>
          <div className="flex items-center gap-2">
            <GraduationCap className="w-4 h-4 text-ink-400" />
            <span className="text-ink-400">ຫ້ອງຮຽນ:</span>
            <span className="font-medium text-ink-900">{className}</span>
          </div>
          <div className="flex items-center gap-2">
            <Calendar className="w-4 h-4 text-ink-400" />
            <span className="text-ink-400">ວັນທີອອກໃບ:</span>
            <span className="font-medium text-ink-900">{formatDate(new Date().toISOString())}</span>
          </div>
        </div>

        {/* Grades */}
        {subjects.length === 0 ? (
          <div className="py-10 text-center">
            <FileText className="w-10 h-10 text-ink-300 mx-auto mb-2" />
            <p className="text-ink-400">ຍັງບໍ່ມີຄະແນນໃນພາກຮຽນນີ້</p>
          </div>
        ) : (
          <>
            <table className="w-full text-sm mb-6">
              <thead>
                <tr className="bg-ink-50 text-ink-500 text-xs uppercase">
                  <th className="text-left px-4 py-3 font-semibold">ວິຊາ</th>
                  <th className="text-center px-4 py-3 font-semibold">ຄະແນນສະເລ່ຍ (%)</th>
                  <th className="text-center px-4 py-3 font-semibold">ເກຣດ</th>
                </tr>
              </thead>
              <tbody>
                {subjects.map((s) => (
                  <tr key={s.subject} className="border-t border-ink-100">
                    <td className="px-4 py-3 font-medium text-ink-900">{s.subject}</td>
                    <td className="px-4 py-3 text-center text-ink-700">{s.avgPct}%</td>
                    <td className="px-4 py-3 text-center">
                      <span className="badge bg-brand-50 text-brand-700 font-bold">{s.letter}</span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>

            {/* GPA + behavior summary */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="rounded-xl bg-brand-50 p-4 flex items-center gap-3">
                <div className="w-11 h-11 rounded-xl bg-brand-500 flex items-center justify-center shrink-0">
                  <TrendingUp className="w-6 h-6 text-white" />
                </div>
                <div>
                  <p className="text-xs text-ink-500">ຄະແນນສະເລ່ຍລວມ (GPA)</p>
                  <p className="text-xl font-bold text-brand-700">{gpa.toFixed(2)} / 4.00</p>
                </div>
              </div>
              <div className="rounded-xl bg-amber-50 p-4 flex items-center gap-3">
                <div className="w-11 h-11 rounded-xl bg-amber-500 flex items-center justify-center shrink-0">
                  <Award className="w-6 h-6 text-white" />
                </div>
                <div>
                  <p className="text-xs text-ink-500">ຄະແນນບວກ</p>
                  <p className="text-xl font-bold text-amber-600">+{positivePts}</p>
                </div>
              </div>
              <div className="rounded-xl bg-red-50 p-4 flex items-center gap-3">
                <div className="w-11 h-11 rounded-xl bg-red-500 flex items-center justify-center shrink-0">
                  <Heart className="w-6 h-6 text-white" />
                </div>
                <div>
                  <p className="text-xs text-ink-500">ຄະແນນຫັກ</p>
                  <p className="text-xl font-bold text-red-500">-{negativePts}</p>
                </div>
              </div>
            </div>

            <div className="mt-4 text-center text-sm text-ink-600">
              ຄະແນນພຶດຕິກະພາບສຸດທິ: <span className="font-semibold text-ink-900">{netPts >= 0 ? '+' : ''}{netPts} ຄະແນນ</span>
            </div>
          </>
        )}

        {/* Footer */}
        <div className="mt-8 pt-5 border-t border-ink-200 flex justify-between text-sm text-ink-500">
          <div>
            <p>ລາຍເຊັນຄູປະຈຳຫ້ອງ</p>
            <div className="mt-8 border-t border-ink-300 w-40" />
          </div>
          <div className="text-right">
            <p>ອາຈານຜູ້ອຳນວຍການ</p>
            <div className="mt-8 border-t border-ink-300 w-40 ml-auto" />
          </div>
        </div>
      </div>
    </div>
  );
}
