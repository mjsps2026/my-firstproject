import { useState, useEffect, useCallback } from 'react';
import { supabase } from '../../lib/supabase';
import type { StudentRow, AttendanceRow } from '../../types';
import {
  ATTENDANCE_STATUSES, ATTENDANCE_STATUS_STYLES, formatDateShort,
} from '../../constants';
import { CheckCircle2, XCircle, Clock, CalendarOff, CalendarDays } from 'lucide-react';

const STATUS_ICONS: Record<string, typeof CheckCircle2> = {
  present: CheckCircle2,
  absent: XCircle,
  late: Clock,
  leave: CalendarOff,
};

const STATUS_COLOR: Record<string, string> = {
  present: 'bg-brand-50 text-brand-600',
  absent: 'bg-red-50 text-red-500',
  late: 'bg-amber-50 text-amber-600',
  leave: 'bg-sky-50 text-sky-600',
};

export default function StudentAttendance({ student }: { student: StudentRow }) {
  const [records, setRecords] = useState<AttendanceRow[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchData = useCallback(async () => {
    setLoading(true);
    const { data } = await supabase
      .from('attendance')
      .select('*')
      .eq('student_id', student.id)
      .order('date', { ascending: false });
    setRecords((data || []) as AttendanceRow[]);
    setLoading(false);
  }, [student.id]);

  useEffect(() => { fetchData(); }, [fetchData]);

  if (loading) return <div className="card p-8 text-center text-ink-400">ກຳລັງໂຫຼດ...</div>;

  const counts = ATTENDANCE_STATUSES.reduce<Record<string, number>>((acc, s) => {
    acc[s.value] = records.filter((r) => r.status === s.value).length;
    return acc;
  }, {});

  const statusLabel = (s: string) =>
    ATTENDANCE_STATUSES.find((a) => a.value === s)?.label || s;

  return (
    <div>
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-ink-900">ການມາຮຽນ</h1>
        <p className="text-sm text-ink-400 mt-1">ປະຫວັດການມາຮຽນຂອງ {student.full_name}</p>
      </div>

      {/* Summary */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        {ATTENDANCE_STATUSES.map((s) => {
          const Icon = STATUS_ICONS[s.value] || CheckCircle2;
          return (
            <div key={s.value} className="stat-card">
              <div className={`w-12 h-12 rounded-xl flex items-center justify-center shrink-0 ${STATUS_COLOR[s.value]}`}>
                <Icon className="w-6 h-6" />
              </div>
              <div>
                <p className="text-2xl font-bold text-ink-900">{counts[s.value] || 0}</p>
                <p className="text-xs text-ink-400">{s.label}</p>
              </div>
            </div>
          );
        })}
      </div>

      {/* Records */}
      {records.length === 0 ? (
        <div className="card p-8 text-center">
          <CalendarDays className="w-10 h-10 text-ink-300 mx-auto mb-3" />
          <p className="text-ink-400">ຍັງບໍ່ມີບົດບັນທຶກການມາຮຽນ</p>
        </div>
      ) : (
        <div className="card overflow-hidden">
          <div className="overflow-x-auto scrollbar-thin">
            <table className="w-full text-sm">
              <thead>
                <tr className="bg-ink-50 text-ink-500 text-xs uppercase">
                  <th className="text-left px-4 py-3 font-semibold">ວັນທີ</th>
                  <th className="text-center px-4 py-3 font-semibold">ສະຖານະ</th>
                  <th className="text-left px-4 py-3 font-semibold">ໝາຍເຫດ</th>
                </tr>
              </thead>
              <tbody>
                {records.map((r) => {
                  const st = ATTENDANCE_STATUS_STYLES[r.status] || { badge: 'bg-ink-100 text-ink-600', dot: 'bg-ink-400' };
                  return (
                    <tr key={r.id} className="border-t border-ink-100 table-row">
                      <td className="px-4 py-3 font-medium text-ink-900">{formatDateShort(r.date)}</td>
                      <td className="px-4 py-3 text-center">
                        <span className={`badge ${st.badge}`}>
                          <span className={`w-1.5 h-1.5 rounded-full ${st.dot}`} />
                          {statusLabel(r.status)}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-ink-500">{r.note || '—'}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
