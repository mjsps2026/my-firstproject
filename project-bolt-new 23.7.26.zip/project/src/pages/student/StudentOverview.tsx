import { useState, useEffect, useCallback } from 'react';
import { supabase } from '../../lib/supabase';
import type {
  StudentRow, ClassRow, ScheduleRow, TeacherRow,
  AttendanceRow, GradeRow, BehaviorRow, AnnouncementRow, TuitionRow,
} from '../../types';
import { DAYS, formatDate, formatDateTime } from '../../constants';
import {
  CheckCircle2, ClipboardList, Heart, Wallet, CalendarDays,
  Megaphone, Clock, BookOpen, MapPin, User, GraduationCap, Sparkles,
} from 'lucide-react';

const todayDayLabel = (): string | null => {
  const jsDay = new Date().getDay(); // 0=Sun..6=Sat
  const idx = jsDay === 0 ? -1 : jsDay - 1; // Mon=0..Sat=5
  return idx >= 0 ? DAYS[idx] : null;
};

export default function StudentOverview({ student }: { student: StudentRow }) {
  const [className, setClassName] = useState('—');
  const [todaySchedule, setTodaySchedule] = useState<(ScheduleRow & { teacher_name?: string })[]>([]);
  const [attendanceRate, setAttendanceRate] = useState(0);
  const [avgGrade, setAvgGrade] = useState(0);
  const [behaviorPoints, setBehaviorPoints] = useState(0);
  const [pendingTuition, setPendingTuition] = useState(0);
  const [announcements, setAnnouncements] = useState<AnnouncementRow[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchData = useCallback(async () => {
    setLoading(true);
    const monthStart = new Date(new Date().getFullYear(), new Date().getMonth(), 1)
      .toISOString().slice(0, 10);
    const todayDay = todayDayLabel();

    const [classRes, attRes, gradeRes, behRes, tuRes, annRes] = await Promise.all([
      supabase.from('classes').select('*').eq('id', student.class_id || '').maybeSingle(),
      supabase.from('attendance').select('*').eq('student_id', student.id).gte('date', monthStart),
      supabase.from('grades').select('*').eq('student_id', student.id),
      supabase.from('behavior_records').select('*').eq('student_id', student.id),
      supabase.from('tuition').select('*').eq('student_id', student.id),
      supabase.from('announcements')
        .select('*')
        .in('audience', ['all', 'students'])
        .order('created_at', { ascending: false })
        .limit(5),
    ]);

    setClassName((classRes.data as ClassRow | null)?.name || '—');

    const att = (attRes.data || []) as AttendanceRow[];
    const present = att.filter((a) => a.status === 'present').length;
    setAttendanceRate(att.length ? Math.round((present / att.length) * 100) : 0);

    const grades = (gradeRes.data || []) as GradeRow[];
    if (grades.length) {
      const pct = grades.reduce((s, g) => s + (g.score / g.max_score) * 100, 0) / grades.length;
      setAvgGrade(Math.round(pct * 10) / 10);
    } else {
      setAvgGrade(0);
    }

    const beh = (behRes.data || []) as BehaviorRow[];
    setBehaviorPoints(beh.reduce((s, b) => s + (b.type === 'positive' ? b.points : -b.points), 0));

    const tu = (tuRes.data || []) as TuitionRow[];
    setPendingTuition(tu.filter((t) => t.status !== 'paid').length);

    setAnnouncements((annRes.data || []) as AnnouncementRow[]);

    if (todayDay && student.class_id) {
      const { data: sched } = await supabase
        .from('schedule')
        .select('*')
        .eq('class_id', student.class_id)
        .eq('day', todayDay)
        .order('period', { ascending: true });
      const schedRows = (sched || []) as ScheduleRow[];
      const teacherIds = Array.from(
        new Set(schedRows.map((s) => s.teacher_id).filter((x): x is string => !!x))
      );
      let teacherMap = new Map<string, string>();
      if (teacherIds.length) {
        const { data: teachers } = await supabase
          .from('teachers')
          .select('id, full_name')
          .in('id', teacherIds);
        teacherMap = new Map((teachers as TeacherRow[] | null || []).map((t) => [t.id, t.full_name]));
      }
      setTodaySchedule(
        schedRows.map((s) => ({ ...s, teacher_name: s.teacher_id ? teacherMap.get(s.teacher_id) : undefined }))
      );
    } else {
      setTodaySchedule([]);
    }

    setLoading(false);
  }, [student.id, student.class_id]);

  useEffect(() => { fetchData(); }, [fetchData]);

  if (loading) return <div className="card p-8 text-center text-ink-400">ກຳລັງໂຫຼດ...</div>;

  const initials = student.full_name.split(' ').map((w) => w[0]).join('').slice(0, 2);

  const stats = [
    { label: 'ອັດຕາການມາຮຽນເດືອນນີ້', value: `${attendanceRate}%`, icon: CheckCircle2, color: 'bg-brand-50 text-brand-600' },
    { label: 'ຄະແນນສະເລ່ຍ', value: `${avgGrade}`, icon: ClipboardList, color: 'bg-sky-50 text-sky-600' },
    { label: 'ຄະແນນພຶດຕິກະພາບ', value: `${behaviorPoints}`, icon: Heart, color: 'bg-amber-50 text-amber-600' },
    { label: 'ບິນຄ້າງຈ່າຍ', value: `${pendingTuition}`, icon: Wallet, color: 'bg-red-50 text-red-500' },
  ];

  return (
    <div>
      {/* Welcome */}
      <div className="card overflow-hidden mb-6 bg-gradient-to-br from-brand-500 to-brand-600 border-0">
        <div className="p-6 sm:p-8 flex items-center gap-5">
          <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl bg-white/20 backdrop-blur flex items-center justify-center text-white text-2xl font-bold shrink-0">
            {initials || <User className="w-8 h-8" />}
          </div>
          <div className="min-w-0">
            <div className="flex items-center gap-2 text-white/80 text-sm mb-1">
              <Sparkles className="w-4 h-4" />
              ຍິນດີຕ້ອນຮັບ
            </div>
            <h1 className="text-2xl sm:text-3xl font-bold text-white">{student.full_name}</h1>
            <div className="flex items-center gap-1.5 text-white/90 text-sm mt-2">
              <GraduationCap className="w-4 h-4" />
              ຫ້ອງ {className}
            </div>
          </div>
        </div>
      </div>

      {/* Stat cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        {stats.map((s) => {
          const Icon = s.icon;
          return (
            <div key={s.label} className="stat-card">
              <div className={`w-12 h-12 rounded-xl flex items-center justify-center shrink-0 ${s.color}`}>
                <Icon className="w-6 h-6" />
              </div>
              <div className="min-w-0">
                <p className="text-2xl font-bold text-ink-900">{s.value}</p>
                <p className="text-xs text-ink-400 truncate">{s.label}</p>
              </div>
            </div>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Today's schedule */}
        <div className="card p-5">
          <div className="flex items-center gap-2 mb-4">
            <CalendarDays className="w-5 h-5 text-brand-600" />
            <h2 className="text-base font-semibold text-ink-900">ຕາຕະລາງມື້ນີ້</h2>
            {todayDayLabel() && (
              <span className="chip bg-brand-50 text-brand-700 ml-auto">ວັນ{todayDayLabel()}</span>
            )}
          </div>
          {todaySchedule.length === 0 ? (
            <div className="py-8 text-center">
              <CalendarDays className="w-10 h-10 text-ink-200 mx-auto mb-2" />
              <p className="text-sm text-ink-400">ມື້ນີ້ບໍ່ມີການຮຽນ ຫຼື ຍັງບໍ່ມີຕາຕະລາງ</p>
            </div>
          ) : (
            <div className="space-y-3">
              {todaySchedule.map((s) => (
                <div key={s.id} className="flex items-start gap-3 p-3 rounded-xl bg-ink-50">
                  <div className="flex items-center gap-1 text-xs text-ink-500 shrink-0 w-24">
                    <Clock className="w-3.5 h-3.5" />
                    {s.start_time}–{s.end_time}
                  </div>
                  <div className="min-w-0">
                    <div className="flex items-center gap-1.5 text-sm font-medium text-ink-900">
                      <BookOpen className="w-4 h-4 text-brand-500" />
                      {s.subject}
                    </div>
                    <div className="flex flex-wrap items-center gap-x-3 gap-y-1 mt-1 text-xs text-ink-400">
                      {s.teacher_name && (
                        <span className="flex items-center gap-1">
                          <User className="w-3 h-3" />{s.teacher_name}
                        </span>
                      )}
                      {s.room && (
                        <span className="flex items-center gap-1">
                          <MapPin className="w-3 h-3" />{s.room}
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Recent announcements */}
        <div className="card p-5">
          <div className="flex items-center gap-2 mb-4">
            <Megaphone className="w-5 h-5 text-brand-600" />
            <h2 className="text-base font-semibold text-ink-900">ປະກາດລ່າສຸດ</h2>
          </div>
          {announcements.length === 0 ? (
            <div className="py-8 text-center">
              <Megaphone className="w-10 h-10 text-ink-200 mx-auto mb-2" />
              <p className="text-sm text-ink-400">ຍັງບໍ່ມີປະກາດ</p>
            </div>
          ) : (
            <div className="space-y-3">
              {announcements.map((a) => (
                <div key={a.id} className="p-3 rounded-xl border border-ink-100">
                  <div className="flex items-center justify-between gap-2">
                    <p className="font-medium text-ink-900 text-sm">{a.title}</p>
                    <span className="text-xs text-ink-400 shrink-0">{formatDate(a.created_at)}</span>
                  </div>
                  {a.content && (
                    <p className="text-sm text-ink-500 mt-1 line-clamp-2">{a.content}</p>
                  )}
                  {a.author && (
                    <p className="text-xs text-ink-400 mt-1.5">ໂດຍ {a.author}</p>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
