import { useState, useEffect } from 'react';
import { supabase } from '../../lib/supabase';
import type { StudentRow, ClassRow } from '../../types';
import { formatDate } from '../../constants';
import {
  User, GraduationCap, Calendar, Phone, MapPin, Users,
  CalendarCheck, BadgeCheck,
} from 'lucide-react';

const STATUS_LABELS: Record<string, string> = {
  active: 'ກຳລັງຮຽນ',
  inactive: 'ໝົດສະຖານະ',
  graduated: 'ຈົບຮຽນ',
};

export default function StudentProfile({ student }: { student: StudentRow }) {
  const [className, setClassName] = useState('—');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      if (student.class_id) {
        const { data } = await supabase
          .from('classes')
          .select('*')
          .eq('id', student.class_id)
          .maybeSingle();
        setClassName((data as ClassRow | null)?.name || '—');
      }
      setLoading(false);
    })();
  }, [student.class_id]);

  if (loading) return <div className="card p-8 text-center text-ink-400">ກຳລັງໂຫຼດ...</div>;

  const initials = student.full_name.split(' ').map((w) => w[0]).join('').slice(0, 2);
  const genderLabel = student.gender === 'male' ? 'ຊາຍ' : student.gender === 'female' ? 'ຍິງ' : '—';
  const statusLabel = STATUS_LABELS[student.status] || student.status || '—';

  const rows = [
    { icon: GraduationCap, label: 'ຫ້ອງຮຽນ', value: className },
    { icon: Users, label: 'ເພດ', value: genderLabel },
    { icon: Calendar, label: 'ວັນເດືອນປີເກີດ', value: formatDate(student.birth_date) },
    { icon: Users, label: 'ຊື່ຜູ້ປົກຄອງ', value: student.parent_name || '—' },
    { icon: Phone, label: 'ເບີໂທຜູ້ປົກຄອງ', value: student.parent_phone || '—' },
    { icon: MapPin, label: 'ທີ່ຢູ່', value: student.address || '—' },
    { icon: CalendarCheck, label: 'ວັນທີສະໝັກ', value: formatDate(student.admission_date) },
  ];

  return (
    <div>
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-ink-900">ຂໍ້ມູນສ່ວນຕົວ</h1>
        <p className="text-sm text-ink-400 mt-1">ຂໍ້ມູນສ່ວນຕົວຂອງນັກຮຽນ</p>
      </div>

      <div className="card overflow-hidden max-w-2xl">
        {/* Header / avatar */}
        <div className="bg-gradient-to-br from-brand-500 to-brand-600 px-6 py-8 flex flex-col items-center text-center">
          <div className="w-24 h-24 rounded-full bg-white/20 backdrop-blur flex items-center justify-center text-white text-3xl font-bold mb-3">
            {initials || <User className="w-12 h-12" />}
          </div>
          <h2 className="text-xl font-bold text-white">{student.full_name}</h2>
          <div className="flex items-center gap-1.5 text-white/90 text-sm mt-1">
            <GraduationCap className="w-4 h-4" />
            ຫ້ອງ {className}
          </div>
          <span className="badge bg-white/20 text-white mt-3">
            <BadgeCheck className="w-3.5 h-3.5" />
            {statusLabel}
          </span>
        </div>

        {/* Info rows */}
        <div className="divide-y divide-ink-100">
          {rows.map((r) => {
            const Icon = r.icon;
            return (
              <div key={r.label} className="flex items-center gap-4 px-6 py-4">
                <div className="w-10 h-10 rounded-xl bg-ink-50 flex items-center justify-center shrink-0">
                  <Icon className="w-5 h-5 text-ink-500" />
                </div>
                <div className="min-w-0 flex-1">
                  <p className="text-xs text-ink-400">{r.label}</p>
                  <p className="text-sm font-medium text-ink-900 break-words">{r.value}</p>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
