import { useState, useEffect, useCallback } from 'react';
import { supabase } from '../../lib/supabase';
import type { StudentRow, ScheduleRow, TeacherRow } from '../../types';
import { DAYS } from '../../constants';
import { CalendarDays, BookOpen, User, MapPin, Clock } from 'lucide-react';

export default function StudentSchedule({ student }: { student: StudentRow }) {
  const [slots, setSlots] = useState<ScheduleRow[]>([]);
  const [teacherMap, setTeacherMap] = useState<Map<string, string>>(new Map());
  const [loading, setLoading] = useState(true);

  const fetchData = useCallback(async () => {
    setLoading(true);
    if (!student.class_id) { setLoading(false); return; }
    const { data: sched } = await supabase
      .from('schedule')
      .select('*')
      .eq('class_id', student.class_id)
      .order('period', { ascending: true });
    const schedRows = (sched || []) as ScheduleRow[];
    setSlots(schedRows);

    const teacherIds = Array.from(
      new Set(schedRows.map((s) => s.teacher_id).filter((x): x is string => !!x))
    );
    if (teacherIds.length) {
      const { data: teachers } = await supabase
        .from('teachers')
        .select('id, full_name')
        .in('id', teacherIds);
      setTeacherMap(new Map((teachers as TeacherRow[] | null || []).map((t) => [t.id, t.full_name])));
    }
    setLoading(false);
  }, [student.class_id]);

  useEffect(() => { fetchData(); }, [fetchData]);

  if (loading) return <div className="card p-8 text-center text-ink-400">ກຳລັງໂຫຼດ...</div>;

  const maxPeriod = slots.reduce((m, s) => Math.max(m, s.period), 0);
  const byKey = new Map<string, ScheduleRow>();
  slots.forEach((s) => byKey.set(`${s.day}-${s.period}`, s));
  const periods = Array.from({ length: Math.max(maxPeriod, 1) }, (_, i) => i + 1);

  return (
    <div>
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-ink-900">ຕາຕະລາງຮຽນ</h1>
        <p className="text-sm text-ink-400 mt-1">ຕາຕະລາງຮຽນປະຈຳອາທິດ</p>
      </div>

      {slots.length === 0 ? (
        <div className="card p-8 text-center">
          <CalendarDays className="w-10 h-10 text-ink-300 mx-auto mb-3" />
          <p className="text-ink-400">ຍັງບໍ່ມີຕາຕະລາງຮຽນ</p>
        </div>
      ) : (
        <div className="card overflow-hidden">
          <div className="overflow-x-auto scrollbar-thin">
            <table className="w-full text-sm border-collapse">
              <thead>
                <tr>
                  <th className="sticky left-0 bg-ink-50 text-ink-500 text-xs uppercase font-semibold text-left px-3 py-3 min-w-[90px]">
                    ເຮັກທີ
                  </th>
                  {DAYS.map((d) => (
                    <th key={d} className="bg-ink-50 text-ink-700 text-sm font-semibold px-2 py-3 min-w-[150px] text-center">
                      ວັນ{d}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {periods.map((p) => (
                  <tr key={p}>
                    <td className="sticky left-0 bg-white border-t border-ink-100 text-center font-semibold text-ink-700 px-3 py-2 align-top">
                      {p}
                    </td>
                    {DAYS.map((d) => {
                      const slot = byKey.get(`${d}-${p}`);
                      if (!slot) {
                        return (
                          <td key={d} className="border-t border-ink-100 px-2 py-2 text-center text-ink-300 align-top">
                            —
                          </td>
                        );
                      }
                      const teacherName = slot.teacher_id ? teacherMap.get(slot.teacher_id) : undefined;
                      return (
                        <td key={d} className="border-t border-ink-100 px-2 py-2 align-top">
                          <div className="rounded-lg bg-brand-50 p-2.5">
                            <div className="flex items-center gap-1.5 text-sm font-semibold text-brand-700">
                              <BookOpen className="w-3.5 h-3.5 shrink-0" />
                              {slot.subject}
                            </div>
                            <div className="flex items-center gap-1 text-xs text-ink-500 mt-1.5">
                              <Clock className="w-3 h-3 shrink-0" />
                              {slot.start_time}–{slot.end_time}
                            </div>
                            {teacherName && (
                              <div className="flex items-center gap-1 text-xs text-ink-500 mt-0.5">
                                <User className="w-3 h-3 shrink-0" />
                                {teacherName}
                              </div>
                            )}
                            {slot.room && (
                              <div className="flex items-center gap-1 text-xs text-ink-500 mt-0.5">
                                <MapPin className="w-3 h-3 shrink-0" />
                                {slot.room}
                              </div>
                            )}
                          </div>
                        </td>
                      );
                    })}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
