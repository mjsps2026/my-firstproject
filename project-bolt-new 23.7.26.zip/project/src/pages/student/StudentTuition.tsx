import { useState, useEffect, useCallback } from 'react';
import { supabase } from '../../lib/supabase';
import type { StudentRow, TuitionRow, PaymentSlipRow, BankConfigRow } from '../../types';
import { TUITION_STATUS_STYLES, SLIP_STATUS_STYLES, formatCurrency, formatDate, formatDateTime } from '../../constants';
import { QRPaymentCard } from '../../components/QRPaymentCard';
import { InvoiceModal } from '../../components/InvoiceModal';
import {
  Receipt, Printer, Upload, CheckCircle2, XCircle, Clock, Eye,
  QrCode, Wallet, FileText, X,
} from 'lucide-react';

export default function StudentTuition({ student }: { student: StudentRow }) {
  const [tuitions, setTuitions] = useState<TuitionRow[]>([]);
  const [slips, setSlips] = useState<PaymentSlipRow[]>([]);
  const [bank, setBank] = useState<BankConfigRow | null>(null);
  const [loading, setLoading] = useState(true);
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const [printTarget, setPrintTarget] = useState<TuitionRow | null>(null);
  const [uploadTuId, setUploadTuId] = useState<TuitionRow | null>(null);
  const [previewSlip, setPreviewSlip] = useState<PaymentSlipRow | null>(null);

  const fetchData = useCallback(async () => {
    setLoading(true);
    const [tuRes, slipRes, bankRes] = await Promise.all([
      supabase.from('tuition').select('*').eq('student_id', student.id).order('created_at', { ascending: false }),
      supabase.from('payment_slips').select('*').eq('student_id', student.id).order('uploaded_at', { ascending: false }),
      supabase.from('bank_config').select('*').eq('active', true).maybeSingle(),
    ]);
    setTuitions(tuRes.data || []);
    setSlips(slipRes.data || []);
    setBank(bankRes.data as BankConfigRow | null);
    setLoading(false);
  }, [student.id]);

  useEffect(() => { fetchData(); }, [fetchData]);

  const handleUpload = async (tuition: TuitionRow, file: File) => {
    const ext = file.name.split('.').pop();
    const fileName = `slip-${student.id}-${Date.now()}.${ext}`;
    const { error: uploadErr } = await supabase.storage.from('slips').upload(fileName, file);
    if (uploadErr) { alert('ອັບໂຫຼດຜິດພາດ: ' + uploadErr.message); return; }
    const { data: urlData } = supabase.storage.from('slips').getPublicUrl(fileName);
    await supabase.from('payment_slips').insert({
      tuition_id: tuition.id,
      student_id: student.id,
      slip_url: urlData.publicUrl,
      amount: tuition.amount - tuition.paid_amount,
      status: 'pending',
    });
    setUploadTuId(null);
    fetchData();
  };

  if (loading) return <div className="card p-8 text-center text-ink-400">ກຳລັງໂຫຼດ...</div>;

  const paidCount = tuitions.filter((t) => t.status === 'paid').length;
  const pendingCount = tuitions.filter((t) => t.status !== 'paid').length;
  const totalDue = tuitions.reduce((sum, t) => sum + (t.amount - t.paid_amount), 0);

  return (
    <div>
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-ink-900">ຄ່າຮຽນ + QR</h1>
        <p className="text-sm text-ink-400 mt-1">ເບິ່ງບິນ, ຊຳລະຜ່ານ QR, ແລະ ສົ່ງໃບບິນໂອນເງິນ</p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
        <div className="stat-card">
          <div className="w-12 h-12 rounded-xl bg-brand-50 flex items-center justify-center">
            <CheckCircle2 className="w-6 h-6 text-brand-600" />
          </div>
          <div>
            <p className="text-2xl font-bold text-ink-900">{paidCount}</p>
            <p className="text-sm text-ink-400">ຈ່າຍແລ້ວ</p>
          </div>
        </div>
        <div className="stat-card">
          <div className="w-12 h-12 rounded-xl bg-red-50 flex items-center justify-center">
            <Clock className="w-6 h-6 text-red-500" />
          </div>
          <div>
            <p className="text-2xl font-bold text-ink-900">{pendingCount}</p>
            <p className="text-sm text-ink-400">ຄ້າງຈ່າຍ</p>
          </div>
        </div>
        <div className="stat-card">
          <div className="w-12 h-12 rounded-xl bg-amber-50 flex items-center justify-center">
            <Wallet className="w-6 h-6 text-amber-500" />
          </div>
          <div>
            <p className="text-lg font-bold text-ink-900">{formatCurrency(totalDue)}</p>
            <p className="text-sm text-ink-400">ຍອດຄ້າງຊຳລະ</p>
          </div>
        </div>
      </div>

      {tuitions.length === 0 ? (
        <div className="card p-8 text-center">
          <Receipt className="w-10 h-10 text-ink-300 mx-auto mb-3" />
          <p className="text-ink-400">ຍັງບໍ່ມີບິນເກັບເງິນຄ່າຮຽນ</p>
        </div>
      ) : (
        <div className="space-y-4">
          {tuitions.map((tu) => {
            const st = TUITION_STATUS_STYLES[tu.status] || TUITION_STATUS_STYLES.unpaid;
            const balance = tu.amount - tu.paid_amount;
            const isExpanded = expandedId === tu.id;
            const tuSlips = slips.filter((s) => s.tuition_id === tu.id);
            return (
              <div key={tu.id} className="card overflow-hidden">
                <div
                  className="p-5 flex items-center justify-between cursor-pointer hover:bg-ink-25 transition-colors"
                  onClick={() => setExpandedId(isExpanded ? null : tu.id)}
                >
                  <div className="flex items-center gap-4 min-w-0">
                    <div className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${
                      tu.status === 'paid' ? 'bg-brand-50' : 'bg-red-50'
                    }`}>
                      {tu.status === 'paid' ? <CheckCircle2 className="w-5 h-5 text-brand-600" /> : <FileText className="w-5 h-5 text-red-500" />}
                    </div>
                    <div className="min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <p className="font-semibold text-ink-900 text-sm">{tu.term}</p>
                        <span className={`badge ${st.badge}`}>
                          <span className={`w-1.5 h-1.5 rounded-full ${st.dot}`} />
                          {st.label}
                        </span>
                      </div>
                      <p className="text-xs text-ink-400 mt-0.5">
                        ບິນເລກທີ {tu.invoice_number || '—'} • ກຳນົດຊຳລະ {formatDate(tu.due_date)}
                      </p>
                    </div>
                  </div>
                  <div className="text-right shrink-0 ml-2">
                    <p className="text-sm font-bold text-ink-900">{formatCurrency(tu.amount)}</p>
                    {balance > 0 && <p className="text-xs text-red-500">ຍັງຄ້າງ {formatCurrency(balance)}</p>}
                  </div>
                </div>

                {isExpanded && (
                  <div className="border-t border-ink-100 p-5 animate-slide-up">
                    {tu.status === 'paid' ? (
                      <div className="flex flex-col items-center py-6 text-center">
                        <div className="w-16 h-16 rounded-full bg-brand-50 flex items-center justify-center mb-3">
                          <CheckCircle2 className="w-8 h-8 text-brand-600" />
                        </div>
                        <p className="text-lg font-semibold text-brand-700">ຈ່າຍແລ້ວ</p>
                        <p className="text-sm text-ink-400 mt-1">
                          ຈຳນວຍ {formatCurrency(tu.paid_amount)} ເມື່ອ {formatDate(tu.paid_date)}
                        </p>
                        <button onClick={() => setPrintTarget(tu)} className="btn-secondary mt-4">
                          <Printer className="w-4 h-4" />
                          ພິມໃບໂອນ
                        </button>
                      </div>
                    ) : (
                      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
                        <div>
                          {bank && (
                            <QRPaymentCard
                              bank={bank}
                              amount={balance}
                              studentName={student.full_name}
                              reference={tu.invoice_number || tu.id.slice(0, 8)}
                            />
                          )}
                          <button onClick={() => setPrintTarget(tu)} className="btn-secondary w-full mt-3">
                            <Printer className="w-4 h-4" />
                            ພິມບິນເກັບເງິນ
                          </button>
                        </div>

                        <div>
                          <div className="card border-2 border-dashed border-ink-200 p-6">
                            <div className="text-center mb-4">
                              <Upload className="w-8 h-8 text-ink-300 mx-auto mb-2" />
                              <p className="text-sm font-medium text-ink-700">ອັບໂຫຼດໃບບິນໂອນເງິນ</p>
                              <p className="text-xs text-ink-400 mt-1">ສົ່ງຫຼັງຊຳລະເງິນແລ້ວ</p>
                            </div>
                            {uploadTuId?.id === tu.id ? (
                              <div>
                                <input
                                  type="file"
                                  accept="image/*"
                                  onChange={(e) => {
                                    const f = e.target.files?.[0];
                                    if (f) handleUpload(tu, f);
                                  }}
                                  className="hidden"
                                  id={`slip-upload-${tu.id}`}
                                />
                                <label htmlFor={`slip-upload-${tu.id}`} className="btn-primary w-full cursor-pointer">
                                  <Upload className="w-4 h-4" />
                                  ເລືອກໄຟລ໌
                                </label>
                                <button onClick={() => setUploadTuId(null)} className="btn-ghost w-full mt-2">ຍົກເລີກ</button>
                              </div>
                            ) : (
                              <button onClick={() => setUploadTuId(tu)} className="btn-primary w-full">
                                <Upload className="w-4 h-4" />
                                ອັບໂຫຼດໃບບິນ
                              </button>
                            )}
                          </div>

                          {tuSlips.length > 0 && (
                            <div className="mt-4">
                              <p className="text-sm font-medium text-ink-700 mb-2">ປະຫວັດໃບບິນ</p>
                              <div className="space-y-2">
                                {tuSlips.map((slip) => {
                                  const sst = SLIP_STATUS_STYLES[slip.status] || SLIP_STATUS_STYLES.pending;
                                  return (
                                    <div key={slip.id} className="flex items-center justify-between bg-white border border-ink-100 rounded-xl p-3">
                                      <div className="flex items-center gap-3 min-w-0">
                                        <button onClick={() => setPreviewSlip(slip)} className="w-10 h-10 rounded-lg bg-ink-50 flex items-center justify-center shrink-0 hover:bg-ink-100">
                                          <Eye className="w-4 h-4 text-ink-500" />
                                        </button>
                                        <div className="min-w-0">
                                          <span className={`badge ${sst.badge}`}>
                                            <span className={`w-1.5 h-1.5 rounded-full ${sst.dot}`} />
                                            {sst.label}
                                          </span>
                                          <p className="text-xs text-ink-400 mt-1">{formatDateTime(slip.uploaded_at)}</p>
                                          {slip.admin_note && <p className="text-xs text-red-500 mt-0.5">{slip.admin_note}</p>}
                                        </div>
                                      </div>
                                      <span className="text-sm font-medium text-ink-600 shrink-0">{formatCurrency(slip.amount)}</span>
                                    </div>
                                  );
                                })}
                              </div>
                            </div>
                          )}
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      {printTarget && (
        <InvoiceModal
          tuition={{
            ...printTarget,
            student_name: student.full_name,
            parent_name: student.parent_name,
            parent_phone: student.parent_phone,
          }}
          bank={bank}
          onClose={() => setPrintTarget(null)}
        />
      )}

      {previewSlip && (
        <div className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4 animate-fade-in" onClick={() => setPreviewSlip(null)}>
          <img src={previewSlip.slip_url} alt="slip" className="max-w-full max-h-[90vh] rounded-xl" />
          <button className="absolute top-4 right-4 text-white p-2 rounded-lg bg-white/20 hover:bg-white/30">
            <X className="w-6 h-6" />
          </button>
        </div>
      )}
    </div>
  );
}
