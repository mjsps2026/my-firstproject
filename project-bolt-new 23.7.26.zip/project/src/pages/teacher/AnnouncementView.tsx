import { useState, useEffect } from 'react';
import { supabase } from '../../lib/supabase';
import type { AnnouncementRow } from '../../types';
import { ANNOUNCEMENT_CATEGORIES, formatDate } from '../../constants';
import {
  Megaphone, Search, CalendarDays, Tag, User, Filter, Inbox,
} from 'lucide-react';

const CATEGORY_STYLES: Record<string, string> = {
  general: 'bg-ink-100 text-ink-600',
  event: 'bg-sky-50 text-sky-600',
  exam: 'bg-amber-50 text-amber-600',
  urgent: 'bg-red-50 text-red-600',
};

interface AnnouncementViewProps {
  role: string;
}

export default function AnnouncementView({ role }: AnnouncementViewProps) {
  const [announcements, setAnnouncements] = useState<AnnouncementRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [category, setCategory] = useState('all');
  const [query, setQuery] = useState('');

  useEffect(() => {
    (async () => {
      setLoading(true);
      const audiences = role === 'teacher' ? ['all', 'teachers'] : ['all', 'students'];
      const { data } = await supabase
        .from('announcements')
        .select('*')
        .in('audience', audiences)
        .order('created_at', { ascending: false });
      setAnnouncements((data as AnnouncementRow[]) || []);
      setLoading(false);
    })();
  }, [role]);

  const filtered = announcements.filter((a) => {
    const catOk = category === 'all' || a.category === category;
    const qOk =
      query.trim() === '' ||
      a.title.toLowerCase().includes(query.toLowerCase()) ||
      a.content.toLowerCase().includes(query.toLowerCase());
    return catOk && qOk;
  });

  return (
    <div>
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-ink-900 flex items-center gap-2">
          <Megaphone className="w-6 h-6 text-brand-600" />
          ປະກາດ
        </h1>
        <p className="text-sm text-ink-400 mt-1">ປະກາດ ແລະ ຂ່າວສານຈາກໂຮງຮຽນ</p>
      </div>

      <div className="card p-4 mb-4">
        <div className="flex flex-col sm:flex-row gap-3">
          <div className="relative flex-1">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-ink-400" />
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              className="input pl-9"
              placeholder="ຄົ້ນຫາປະກາດ..."
            />
          </div>
          <div className="relative">
            <Filter className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-ink-400 pointer-events-none" />
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value)}
              className="input pl-9 sm:w-48"
            >
              <option value="all">ທຸກໝວດໝູ່</option>
              {ANNOUNCEMENT_CATEGORIES.map((c) => (
                <option key={c.value} value={c.value}>{c.label}</option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {loading ? (
        <div className="card p-8 text-center text-ink-400">ກຳລັງໂຫຼດ...</div>
      ) : filtered.length === 0 ? (
        <div className="card p-8 text-center">
          <Inbox className="w-10 h-10 text-ink-300 mx-auto mb-3" />
          <p className="text-ink-400">
            {announcements.length === 0 ? 'ຍັງບໍ່ມີປະກາດ' : 'ບໍ່ພົບປະກາດທີ່ກົງກັບການຄົ້ນຫາ'}
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {filtered.map((a) => {
            const cat = ANNOUNCEMENT_CATEGORIES.find((c) => c.value === a.category);
            return (
              <div key={a.id} className="card p-5 flex flex-col">
                <div className="flex items-start justify-between gap-3 mb-2">
                  <h3 className="font-semibold text-ink-900 text-base leading-snug">{a.title}</h3>
                  <span className={`chip shrink-0 ${CATEGORY_STYLES[a.category] || 'bg-ink-100 text-ink-600'}`}>
                    <Tag className="w-3 h-3" />
                    {cat?.label || a.category}
                  </span>
                </div>
                <p className="text-sm text-ink-600 whitespace-pre-line flex-1">{a.content}</p>
                <div className="flex items-center justify-between mt-4 pt-3 border-t border-ink-100 text-xs text-ink-400">
                  <span className="flex items-center gap-1.5">
                    <User className="w-3.5 h-3.5" />
                    {a.author || 'ບໍ່ລະບຸ'}
                  </span>
                  <span className="flex items-center gap-1.5">
                    <CalendarDays className="w-3.5 h-3.5" />
                    {formatDate(a.created_at)}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
