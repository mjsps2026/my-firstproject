import { useState, useEffect, useCallback } from 'react';
import { supabase } from '../../lib/supabase';
import type { ClassRow, StudentRow, BehaviorRow } from '../../types';
import {
  Heart, School, Users, Plus, Trash2, ThumbsUp, ThumbsDown,
  Loader2, Save, CalendarDays, TrendingUp, TrendingDown,
} from 'lucide-react';

const TYPE_STYLES: Record<string, { badge: string; icon: typeof ThumbsUp; label: string }> = {
  positive: { badge: 'bg-brand-50 text-brand-700', icon: ThumbsUp, label: 'ດີ' },
  negative: { badge: 'bg-red-50 text-red-600', icon: ThumbsDown, label: 'ບໍ່ດີ' },
};

export default function BehaviorTracking() {
  const [classes, setClasses] = useState<ClassRow[]>([]);
  const [students, setStudents] = useState<StudentRow[]>([]);
  const [classId, setClassId] = useState('');
  const [studentId, setStudentId] = useState('');
  const [records, setRecords] = useState<BehaviorRow[]>([]);
  const [totals, setTotals] = useState<Record<string, number>>({});
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  const [form, setForm] = useState<{
    type: 'positive' | 'negative';
    description: string;
    points: string;
    date: string;
  }>({
    type: 'positive',
    description: '',
    points: '1',
    date: new Date().toISOString().slice(0, 10),
  });

  useEffect(() => {
    (async () => {
      const { data } = await supabase.from('classes').select('*').order('name');
      const cs = (data as ClassRow[]) || [];
      setClasses(cs);
      if (cs.length > 0) setClassId(cs[0].id);
      setLoading(false);
    })();
  }, []);

  const fetchStudents = useCallback(async () => {
    if (!classId) {
      setStudents([]);
      setStudentId('');
      return;
    }
    const { data } = await supabase
      .from('students')
      .select('*')
      .eq('class_id', classId)
      .order('full_name');
    const list = (data as StudentRow[]) || [];
    setStudents(list);
    setStudentId(list[0]?.id || '');
  }, [classId]);

  const fetchRecords = useCallback(async () => {
    if (!classId) {
      setRecords([]);
      setTotals({});
      return;
    }
    const { data } = await supabase
      .from('behavior_records')
      .select('*')
      .eq('class_id', classId)
      .order('date', { ascending: false })
      .order('created_at', { ascending: false });
    const all = (data as BehaviorRow[]) || [];
    setRecords(all);

    const t: Record<string, number> = {};
    all.forEach((r) => {
      t[r.student_id] = (t[r.student_id] || 0) + (r.type === 'positive' ? r.points : -r.points);
    });
    setTotals(t);
  }, [classId]);

  useEffect(() => { fetchStudents(); }, [fetchStudents]);
  useEffect(() => { fetchRecords(); }, [fetchRecords]);

  const handleAdd = async () => {
    if (!classId || !studentId) return;
    if (!form.description.trim()) return;
    setSaving(true);
    await supabase.from('behavior_records').insert({
      student_id: studentId,
      class_id: classId,
      date: form.date,
      type: form.type,
      description: form.description.trim(),
      points: parseInt(form.points, 10) || 1,
    });
    setSaving(false);
    setForm({ ...form, description: '' });
    fetchRecords();
  };

  const handleDelete = async (id: string) => {
    await supabase.from('behavior_records').delete().eq('id', id);
    fetchRecords();
  };

  const studentName = (id: string) => students.find((s) => s.id === id)?.full_name || '—';
  const selectedRecords = records.filter((r) => r.student_id === studentId);
  const selectedTotal = totals[studentId] || 0;

  if (loading && classes.length === 0) {
    return <div className="card p-8 text-center text-ink-400">ກຳລັງໂຫຼດ...</div>;
  }

  return (
    <div>
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-ink-900 flex items-center gap-2">
          <Heart className="w-6 h-6 text-brand-600" />
          ຕິດຕາມພຶດຕິກະພາບ
        </h1>
        <p className="text-sm text-ink-400 mt-1">ບັນທຶກ ແລະ ຕິດຕາມພຶດຕິກະພາບຂອງນັກຮຽນ</p>
      </div>

      <div className="card p-4 mb-4">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="label">
              <School className="w-4 h-4 inline mr-1" />
              ຫ້ອງຮຽນ
            </label>
            <select value={classId} onChange={(e) => setClassId(e.target.value)} className="input">
              <option value="">— ເລືອກຫ້ອງ —</option>
              {classes.map((c) => (
                <option key={c.id} value={c.id}>{c.name}</option>
              ))}
            </select>
          </div>
          <div>
            <label className="label">
              <Users className="w-4 h-4 inline mr-1" />
              ນັກຮຽນ
            </label>
            <select value={studentId} onChange={(e) => setStudentId(e.target.value)} className="input">
              <option value="">— ເລືອກນັກຮຽນ —</option>
              {students.map((s) => (
                <option key={s.id} value={s.id}>{s.full_name}</option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {!classId ? (
        <div className="card p-8 text-center">
          <School className="w-10 h-10 text-ink-300 mx-auto mb-3" />
          <p className="text-ink-400">ກະລຸນາເລືອກຫ້ອງຮຽນ</p>
        </div>
      ) : students.length === 0 ? (
        <div className="card p-8 text-center">
          <Users className="w-10 h-10 text-ink-300 mx-auto mb-3" />
          <p className="text-ink-400">ບໍ່ມີນັກຮຽນໃນຫ້ອງນີ້</p>
        </div>
      ) : !studentId ? (
        <div className="card p-8 text-center">
          <Users className="w-10 h-10 text-ink-300 mx-auto mb-3" />
          <p className="text-ink-400">ກະລຸນາເລືອກນັກຮຽນ</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-6">
            <div className="card p-5">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-lg font-semibold text-ink-900">ບັນທຶກພຶດຕິກະພາບ</h2>
                <div className="flex items-center gap-2">
                  <span className="text-sm text-ink-400">ຄະແນນລວມ:</span>
                  <span
                    className={`badge ${
                      selectedTotal > 0
                        ? 'bg-brand-50 text-brand-700'
                        : selectedTotal < 0
                        ? 'bg-red-50 text-red-600'
                        : 'bg-ink-100 text-ink-600'
                    }`}
                  >
                    {selectedTotal > 0 ? <TrendingUp className="w-3.5 h-3.5" /> : selectedTotal < 0 ? <TrendingDown className="w-3.5 h-3.5" /> : null}
                    {selectedTotal > 0 ? '+' : ''}{selectedTotal} ຄະແນນ
                  </span>
                </div>
              </div>

              {selectedRecords.length === 0 ? (
                <div className="text-center py-8">
                  <Heart className="w-10 h-10 text-ink-300 mx-auto mb-3" />
                  <p className="text-ink-400">ຍັງບໍ່ມີບັນທຶກພຶດຕິກະພາບ</p>
                </div>
              ) : (
                <div className="space-y-2">
                  {selectedRecords.map((r) => {
                    const st = TYPE_STYLES[r.type];
                    const Icon = st.icon;
                    return (
                      <div
                        key={r.id}
                        className="flex items-start gap-3 p-3 rounded-xl border border-ink-100"
                      >
                        <div
                          className={`w-9 h-9 rounded-lg flex items-center justify-center shrink-0 ${
                            r.type === 'positive' ? 'bg-brand-50' : 'bg-red-50'
                          }`}
                        >
                          <Icon
                            className={`w-4 h-4 ${
                              r.type === 'positive' ? 'text-brand-600' : 'text-red-600'
                            }`}
                          />
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 mb-0.5">
                            <span className={`badge ${st.badge}`}>{st.label}</span>
                            <span className="text-xs text-ink-400">{r.date}</span>
                          </div>
                          <p className="text-sm text-ink-700">{r.description}</p>
                        </div>
                        <div className="flex items-center gap-2 shrink-0">
                          <span
                            className={`text-sm font-semibold ${
                              r.type === 'positive' ? 'text-brand-600' : 'text-red-600'
                            }`}
                          >
                            {r.type === 'positive' ? '+' : '-'}{r.points}
                          </span>
                          <button
                            onClick={() => handleDelete(r.id)}
                            className="p-1.5 rounded-lg text-ink-400 hover:bg-red-50 hover:text-red-600 transition-colors"
                            title="ລຶບ"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </div>

          <div className="card p-5 h-fit">
            <h2 className="text-lg font-semibold text-ink-900 mb-4">ເພີ່ມບັນທຶກໃໝ່</h2>
            <div className="space-y-4">
              <div>
                <label className="label">ປະເພດ</label>
                <div className="flex gap-2">
                  {(['positive', 'negative'] as const).map((t) => {
                    const st = TYPE_STYLES[t];
                    const Icon = st.icon;
                    return (
                      <button
                        key={t}
                        onClick={() => setForm((f) => ({ ...f, type: t }))}
                        className={`flex-1 inline-flex items-center justify-center gap-1.5 py-2.5 rounded-xl text-sm font-medium transition-all ${
                          form.type === t ? st.badge + ' ring-2 ring-offset-1 ring-current' : 'bg-ink-50 text-ink-500 hover:bg-ink-100'
                        }`}
                      >
                        <Icon className="w-4 h-4" />
                        {st.label}
                      </button>
                    );
                  })}
                </div>
              </div>

              <div>
                <label className="label">ລາຍລະອຽດ</label>
                <textarea
                  value={form.description}
                  onChange={(e) => setForm((f) => ({ ...f, description: e.target.value }))}
                  rows={3}
                  className="input resize-none"
                  placeholder="ເຊັ່ນ ຊ່ວຍເຫຼືອໝູ່, ມາຊ້າ..."
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="label">ຄະແນນ</label>
                  <input
                    type="number"
                    value={form.points}
                    onChange={(e) => setForm((f) => ({ ...f, points: e.target.value }))}
                    className="input"
                    min="1"
                  />
                </div>
                <div>
                  <label className="label">
                    <CalendarDays className="w-4 h-4 inline mr-1" />
                    ວັນທີ
                  </label>
                  <input
                    type="date"
                    value={form.date}
                    onChange={(e) => setForm((f) => ({ ...f, date: e.target.value }))}
                    className="input"
                  />
                </div>
              </div>

              <button
                onClick={handleAdd}
                disabled={saving || !form.description.trim()}
                className="btn-primary w-full"
              >
                {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Plus className="w-4 h-4" />}
                {saving ? 'ກຳລັງບັນທຶກ...' : 'ເພີ່ມບັນທຶກ'}
              </button>
            </div>

            <div className="mt-6 pt-4 border-t border-ink-100">
              <p className="text-xs text-ink-400 mb-2">ຄະແນນລວມຂອງຫ້ອງ</p>
              <div className="space-y-1.5 max-h-48 overflow-y-auto scrollbar-thin">
                {students.map((s) => {
                  const t = totals[s.id] || 0;
                  return (
                    <div key={s.id} className="flex items-center justify-between text-sm">
                      <span className="text-ink-600 truncate">{s.full_name}</span>
                      <span
                        className={`font-medium shrink-0 ml-2 ${
                          t > 0 ? 'text-brand-600' : t < 0 ? 'text-red-600' : 'text-ink-400'
                        }`}
                      >
                        {t > 0 ? '+' : ''}{t}
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
