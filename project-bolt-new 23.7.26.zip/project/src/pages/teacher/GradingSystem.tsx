import { useState, useEffect, useCallback } from 'react';
import { supabase } from '../../lib/supabase';
import type { ClassRow, StudentRow, GradeRow } from '../../types';
import { SUBJECTS, TERMS } from '../../constants';
import {
  ClipboardList, School, BookOpen, CalendarDays, Save, Users,
  CheckCircle2, Loader2, GraduationCap,
} from 'lucide-react';

const calcGradeLetter = (score: number, max: number): string => {
  if (max <= 0) return 'F';
  const pct = (score / max) * 100;
  if (pct >= 80) return 'A';
  if (pct >= 70) return 'B';
  if (pct >= 60) return 'C';
  if (pct >= 50) return 'D';
  return 'F';
};

const GRADE_STYLES: Record<string, string> = {
  A: 'bg-brand-50 text-brand-700',
  B: 'bg-sky-50 text-sky-600',
  C: 'bg-amber-50 text-amber-600',
  D: 'bg-orange-50 text-orange-600',
  F: 'bg-red-50 text-red-600',
};

interface Entry {
  score: string;
  max: string;
  grade: string;
  savedId?: string;
}

export default function GradingSystem() {
  const [classes, setClasses] = useState<ClassRow[]>([]);
  const [students, setStudents] = useState<StudentRow[]>([]);
  const [classId, setClassId] = useState('');
  const [subject, setSubject] = useState(SUBJECTS[0]);
  const [term, setTerm] = useState(TERMS[0]);
  const [maxScore, setMaxScore] = useState('100');
  const [entries, setEntries] = useState<Record<string, Entry>>({});
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [savedAt, setSavedAt] = useState(false);

  useEffect(() => {
    (async () => {
      const { data } = await supabase.from('classes').select('*').order('name');
      const cs = (data as ClassRow[]) || [];
      setClasses(cs);
      if (cs.length > 0) setClassId(cs[0].id);
      setLoading(false);
    })();
  }, []);

  const fetchData = useCallback(async () => {
    if (!classId) {
      setStudents([]);
      setEntries({});
      return;
    }
    setLoading(true);
    const { data: sts } = await supabase
      .from('students')
      .select('*')
      .eq('class_id', classId)
      .order('full_name');
    const studentList = (sts as StudentRow[]) || [];
    setStudents(studentList);

    const { data: grades } = await supabase
      .from('grades')
      .select('*')
      .eq('class_id', classId)
      .eq('subject', subject)
      .eq('term', term);
    const byStudent: Record<string, GradeRow> = {};
    (grades as GradeRow[] || []).forEach((g) => { byStudent[g.student_id] = g; });

    const next: Record<string, Entry> = {};
    const defaultMax = byStudent[studentList[0]?.id]?.max_score || parseFloat(maxScore) || 100;
    studentList.forEach((s) => {
      const g = byStudent[s.id];
      next[s.id] = g
        ? {
            score: String(g.score),
            max: String(g.max_score),
            grade: g.grade_letter,
            savedId: g.id,
          }
        : { score: '', max: String(defaultMax), grade: '' };
    });
    setEntries(next);
    setLoading(false);
  }, [classId, subject, term, maxScore]);

  useEffect(() => { fetchData(); }, [fetchData]);

  const updateScore = (studentId: string, raw: string) => {
    setEntries((prev) => {
      const e = prev[studentId];
      if (!e) return prev;
      const max = parseFloat(e.max) || 0;
      const score = raw === '' ? '' : String(Math.max(0, Math.min(parseFloat(raw) || 0, max)));
      const grade = score === '' ? '' : calcGradeLetter(parseFloat(score), max);
      return { ...prev, [studentId]: { ...e, score, grade } };
    });
  };

  const updateMax = (studentId: string, raw: string) => {
    setEntries((prev) => {
      const e = prev[studentId];
      if (!e) return prev;
      const max = raw === '' ? '' : String(Math.max(1, parseFloat(raw) || 0));
      const scoreNum = e.score === '' ? 0 : parseFloat(e.score);
      const grade = e.score === '' ? '' : calcGradeLetter(scoreNum, parseFloat(max || '0'));
      return { ...prev, [studentId]: { ...e, max, grade } };
    });
  };

  const handleSave = async () => {
    if (!classId) return;
    setSaving(true);
    setSavedAt(false);
    for (const s of students) {
      const e = entries[s.id];
      if (!e || e.score === '') continue;
      const score = parseFloat(e.score);
      const max = parseFloat(e.max) || 100;
      const grade = calcGradeLetter(score, max);
      if (e.savedId) {
        await supabase
          .from('grades')
          .update({ score, max_score: max, grade_letter: grade })
          .eq('id', e.savedId);
      } else {
        await supabase.from('grades').insert({
          student_id: s.id,
          class_id: classId,
          subject,
          term,
          score,
          max_score: max,
          grade_letter: grade,
        });
      }
    }
    setSaving(false);
    setSavedAt(true);
    setTimeout(() => setSavedAt(false), 2500);
    fetchData();
  };

  const enteredCount = students.filter((s) => entries[s.id]?.score !== '').length;

  if (loading && classes.length === 0) {
    return <div className="card p-8 text-center text-ink-400">ກຳລັງໂຫຼດ...</div>;
  }

  return (
    <div>
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-ink-900 flex items-center gap-2">
          <ClipboardList className="w-6 h-6 text-brand-600" />
          ປ້ອນຄະແນນ
        </h1>
        <p className="text-sm text-ink-400 mt-1">ບັນທຶກຄະແນນນັກຮຽນຕາມວິຊາ ແລະ ພາກຮຽນ</p>
      </div>

      <div className="card p-4 mb-4">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <div>
            <label className="label">
              <School className="w-4 h-4 inline mr-1" />
              ຫ້ອງຮຽນ
            </label>
            <select value={classId} onChange={(e) => setClassId(e.target.value)} className="input">
              <option value="">— ເລືອກຫ້ອງ —</option>
              {classes.map((c) => (
                <option key={c.id} value={c.id}>{c.name}</option>
              ))}
            </select>
          </div>
          <div>
            <label className="label">
              <BookOpen className="w-4 h-4 inline mr-1" />
              ວິຊາ
            </label>
            <select value={subject} onChange={(e) => setSubject(e.target.value)} className="input">
              {SUBJECTS.map((s) => <option key={s} value={s}>{s}</option>)}
            </select>
          </div>
          <div>
            <label className="label">
              <CalendarDays className="w-4 h-4 inline mr-1" />
              ພາກຮຽນ
            </label>
            <select value={term} onChange={(e) => setTerm(e.target.value)} className="input">
              {TERMS.map((t) => <option key={t} value={t}>{t}</option>)}
            </select>
          </div>
          <div>
            <label className="label">
              <GraduationCap className="w-4 h-4 inline mr-1" />
              ຄະແນນເເຕັມ
            </label>
            <input
              type="number"
              value={maxScore}
              onChange={(e) => setMaxScore(e.target.value)}
              className="input"
              placeholder="ເຊັ່ນ 100"
            />
          </div>
        </div>
      </div>

      {!classId ? (
        <div className="card p-8 text-center">
          <School className="w-10 h-10 text-ink-300 mx-auto mb-3" />
          <p className="text-ink-400">ກະລຸນາເລືອກຫ້ອງຮຽນ</p>
        </div>
      ) : loading ? (
        <div className="card p-8 text-center text-ink-400">ກຳລັງໂຫຼດ...</div>
      ) : students.length === 0 ? (
        <div className="card p-8 text-center">
          <Users className="w-10 h-10 text-ink-300 mx-auto mb-3" />
          <p className="text-ink-400">ບໍ່ມີນັກຮຽນໃນຫ້ອງນີ້</p>
        </div>
      ) : (
        <>
          <div className="card overflow-hidden">
            <div className="overflow-x-auto scrollbar-thin">
              <table className="w-full text-sm">
                <thead>
                  <tr className="bg-ink-50 text-ink-500 text-xs uppercase">
                    <th className="text-left px-4 py-3 font-semibold w-12">#</th>
                    <th className="text-left px-4 py-3 font-semibold">ນັກຮຽນ</th>
                    <th className="text-right px-4 py-3 font-semibold w-32">ຄະແນນ</th>
                    <th className="text-right px-4 py-3 font-semibold w-28">ເເຕັມ</th>
                    <th className="text-center px-4 py-3 font-semibold w-20">%</th>
                    <th className="text-center px-4 py-3 font-semibold w-24">ເກຣດ</th>
                  </tr>
                </thead>
                <tbody>
                  {students.map((s, idx) => {
                    const e = entries[s.id];
                    if (!e) return null;
                    const scoreNum = parseFloat(e.score) || 0;
                    const maxNum = parseFloat(e.max) || 0;
                    const pct = maxNum > 0 ? Math.round((scoreNum / maxNum) * 100) : 0;
                    return (
                      <tr key={s.id} className="border-t border-ink-100 table-row">
                        <td className="px-4 py-3 text-ink-400">{idx + 1}</td>
                        <td className="px-4 py-3 font-medium text-ink-900">{s.full_name}</td>
                        <td className="px-4 py-3">
                          <input
                            type="number"
                            value={e.score}
                            onChange={(ev) => updateScore(s.id, ev.target.value)}
                            className="input text-right py-1.5"
                            placeholder="0"
                          />
                        </td>
                        <td className="px-4 py-3">
                          <input
                            type="number"
                            value={e.max}
                            onChange={(ev) => updateMax(s.id, ev.target.value)}
                            className="input text-right py-1.5"
                          />
                        </td>
                        <td className="px-4 py-3 text-center text-ink-600">
                          {e.score === '' ? '—' : `${pct}%`}
                        </td>
                        <td className="px-4 py-3 text-center">
                          {e.grade ? (
                            <span className={`badge ${GRADE_STYLES[e.grade]}`}>{e.grade}</span>
                          ) : (
                            <span className="text-xs text-ink-300">—</span>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>

          <div className="flex items-center justify-between mt-4">
            <p className="text-xs text-ink-400">
              ປ້ອນແລ້ວ {enteredCount}/{students.length} ນັກຮຽນ
            </p>
            <div className="flex items-center gap-3">
              {savedAt && (
                <span className="text-sm text-brand-600 flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4" />
                  ບັນທຶກສຳເລັດ!
                </span>
              )}
              <button onClick={handleSave} disabled={saving || enteredCount === 0} className="btn-primary">
                {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
                {saving ? 'ກຳລັງບັນທຶກ...' : 'ບັນທຶກຄະແນນ'}
              </button>
            </div>
          </div>

          <div className="card p-4 mt-4 bg-ink-50">
            <p className="text-xs text-ink-500 font-medium mb-2">ຕາຕະລາງເກຣດ</p>
            <div className="flex flex-wrap gap-2">
              {[
                { l: 'A', d: '≥ 80%' },
                { l: 'B', d: '≥ 70%' },
                { l: 'C', d: '≥ 60%' },
                { l: 'D', d: '≥ 50%' },
                { l: 'F', d: '< 50%' },
              ].map((g) => (
                <span key={g.l} className="inline-flex items-center gap-1.5">
                  <span className={`badge ${GRADE_STYLES[g.l]}`}>{g.l}</span>
                  <span className="text-xs text-ink-400">{g.d}</span>
                </span>
              ))}
            </div>
          </div>
        </>
      )}
    </div>
  );
}
