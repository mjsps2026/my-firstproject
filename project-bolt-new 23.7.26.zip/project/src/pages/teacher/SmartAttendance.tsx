import { useState, useEffect, useCallback } from 'react';
import { supabase } from '../../lib/supabase';
import type { ClassRow, StudentRow, AttendanceRow } from '../../types';
import { ATTENDANCE_STATUSES, ATTENDANCE_STATUS_STYLES } from '../../constants';
import {
  CheckSquare, CalendarDays, School, Save, Users, CheckCircle2,
  Loader2, AlertCircle,
} from 'lucide-react';

type StatusValue = typeof ATTENDANCE_STATUSES[number]['value'];

export default function SmartAttendance() {
  const [classes, setClasses] = useState<ClassRow[]>([]);
  const [students, setStudents] = useState<StudentRow[]>([]);
  const [classId, setClassId] = useState('');
  const [date, setDate] = useState(new Date().toISOString().slice(0, 10));
  const [marks, setMarks] = useState<Record<string, StatusValue>>({});
  const [savedRows, setSavedRows] = useState<Record<string, AttendanceRow>>({});
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [savedAt, setSavedAt] = useState(false);

  useEffect(() => {
    (async () => {
      const { data } = await supabase.from('classes').select('*').order('name');
      const cs = (data as ClassRow[]) || [];
      setClasses(cs);
      if (cs.length > 0) setClassId(cs[0].id);
      setLoading(false);
    })();
  }, []);

  const fetchStudentsAndAttendance = useCallback(async () => {
    if (!classId) {
      setStudents([]);
      setMarks({});
      setSavedRows({});
      return;
    }
    setLoading(true);
    const { data: sts } = await supabase
      .from('students')
      .select('*')
      .eq('class_id', classId)
      .order('full_name');
    const studentList = (sts as StudentRow[]) || [];
    setStudents(studentList);

    const { data: att } = await supabase
      .from('attendance')
      .select('*')
      .eq('class_id', classId)
      .eq('date', date);
    const byStudent: Record<string, AttendanceRow> = {};
    (att as AttendanceRow[] || []).forEach((r) => { byStudent[r.student_id] = r; });
    setSavedRows(byStudent);

    const initial: Record<string, StatusValue> = {};
    studentList.forEach((s) => {
      const existing = byStudent[s.id];
      initial[s.id] = (existing?.status as StatusValue) || 'present';
    });
    setMarks(initial);
    setLoading(false);
  }, [classId, date]);

  useEffect(() => { fetchStudentsAndAttendance(); }, [fetchStudentsAndAttendance]);

  const handleSave = async () => {
    if (!classId || students.length === 0) return;
    setSaving(true);
    setSavedAt(false);
    const rows = students.map((s) => ({
      student_id: s.id,
      class_id: classId,
      date,
      status: marks[s.id] || 'present',
    }));

    for (const r of rows) {
      const existing = savedRows[r.student_id];
      if (existing) {
        await supabase.from('attendance').update({ status: r.status }).eq('id', existing.id);
      } else {
        await supabase.from('attendance').insert({
          student_id: r.student_id,
          class_id: r.class_id,
          date: r.date,
          status: r.status,
        });
      }
    }
    setSaving(false);
    setSavedAt(true);
    setTimeout(() => setSavedAt(false), 2500);
    fetchStudentsAndAttendance();
  };

  const summary = ATTENDANCE_STATUSES.map((st) => ({
    ...st,
    count: students.filter((s) => marks[s.id] === st.value).length,
  }));

  const allMarked = students.length > 0 && students.every((s) => marks[s.id]);

  if (loading && classes.length === 0) {
    return <div className="card p-8 text-center text-ink-400">ກຳລັງໂຫຼດ...</div>;
  }

  return (
    <div>
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-ink-900 flex items-center gap-2">
          <CheckSquare className="w-6 h-6 text-brand-600" />
          ເຊັກຊື່ນັກຮຽນ
        </h1>
        <p className="text-sm text-ink-400 mt-1">ບັນທຶກການມາຮຽນຕາມຫ້ອງ ແລະ ວັນທີ</p>
      </div>

      <div className="card p-4 mb-4">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="label">
              <School className="w-4 h-4 inline mr-1" />
              ຫ້ອງຮຽນ
            </label>
            <select value={classId} onChange={(e) => setClassId(e.target.value)} className="input">
              <option value="">— ເລືອກຫ້ອງ —</option>
              {classes.map((c) => (
                <option key={c.id} value={c.id}>{c.name}</option>
              ))}
            </select>
          </div>
          <div>
            <label className="label">
              <CalendarDays className="w-4 h-4 inline mr-1" />
              ວັນທີ
            </label>
            <input type="date" value={date} onChange={(e) => setDate(e.target.value)} className="input" />
          </div>
        </div>
      </div>

      {!classId ? (
        <div className="card p-8 text-center">
          <School className="w-10 h-10 text-ink-300 mx-auto mb-3" />
          <p className="text-ink-400">ກະລຸນາເລືອກຫ້ອງຮຽນ</p>
        </div>
      ) : loading ? (
        <div className="card p-8 text-center text-ink-400">ກຳລັງໂຫຼດ...</div>
      ) : students.length === 0 ? (
        <div className="card p-8 text-center">
          <Users className="w-10 h-10 text-ink-300 mx-auto mb-3" />
          <p className="text-ink-400">ບໍ່ມີນັກຮຽນໃນຫ້ອງນີ້</p>
        </div>
      ) : (
        <>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-4">
            {summary.map((s) => {
              const style = ATTENDANCE_STATUS_STYLES[s.value];
              return (
                <div key={s.value} className="card p-3">
                  <div className="flex items-center gap-2">
                    <span className={`w-2.5 h-2.5 rounded-full ${style.dot}`} />
                    <span className="text-xs text-ink-500">{s.label}</span>
                  </div>
                  <p className="text-xl font-bold text-ink-900 mt-1">{s.count}</p>
                </div>
              );
            })}
          </div>

          <div className="card overflow-hidden">
            <div className="overflow-x-auto scrollbar-thin">
              <table className="w-full text-sm">
                <thead>
                  <tr className="bg-ink-50 text-ink-500 text-xs uppercase">
                    <th className="text-left px-4 py-3 font-semibold w-12">#</th>
                    <th className="text-left px-4 py-3 font-semibold">ຊື່ ແລະ ນາມສະກຸນ</th>
                    <th className="text-center px-4 py-3 font-semibold" colSpan={ATTENDANCE_STATUSES.length}>
                      ສະຖານະ
                    </th>
                    <th className="text-center px-4 py-3 font-semibold">ບັນທຶກເກົ່າ</th>
                  </tr>
                </thead>
                <tbody>
                  {students.map((s, idx) => {
                    const saved = savedRows[s.id];
                    return (
                      <tr key={s.id} className="border-t border-ink-100 table-row">
                        <td className="px-4 py-3 text-ink-400">{idx + 1}</td>
                        <td className="px-4 py-3 font-medium text-ink-900">{s.full_name}</td>
                        {ATTENDANCE_STATUSES.map((st) => {
                          const checked = marks[s.id] === st.value;
                          const style = ATTENDANCE_STATUS_STYLES[st.value];
                          return (
                            <td key={st.value} className="px-2 py-3 text-center">
                              <label className="inline-flex items-center justify-center cursor-pointer">
                                <input
                                  type="radio"
                                  name={`att-${s.id}`}
                                  value={st.value}
                                  checked={checked}
                                  onChange={() => setMarks((m) => ({ ...m, [s.id]: st.value }))}
                                  className="sr-only peer"
                                />
                                <span
                                  className={`px-2.5 py-1.5 rounded-lg text-xs font-medium transition-all ${
                                    checked ? style.badge + ' ring-2 ring-offset-1 ring-current' : 'bg-ink-50 text-ink-400 hover:bg-ink-100'
                                  }`}
                                >
                                  {st.label}
                                </span>
                              </label>
                            </td>
                          );
                        })}
                        <td className="px-4 py-3 text-center">
                          {saved ? (
                            <span className={`badge ${ATTENDANCE_STATUS_STYLES[saved.status]?.badge}`}>
                              <span className={`w-1.5 h-1.5 rounded-full ${ATTENDANCE_STATUS_STYLES[saved.status]?.dot}`} />
                              ບັນທຶກແລ້ວ
                            </span>
                          ) : (
                            <span className="text-xs text-ink-300">—</span>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>

          <div className="flex items-center justify-between mt-4">
            <p className="text-xs text-ink-400 flex items-center gap-1.5">
              {allMarked ? (
                <>
                  <CheckCircle2 className="w-4 h-4 text-brand-500" />
                  ເຊັກຄົບທຸກຄົນແລ້ວ
                </>
              ) : (
                <>
                  <AlertCircle className="w-4 h-4 text-amber-500" />
                  ຍັງເຊັກບໍ່ຄົບ
                </>
              )}
            </p>
            <div className="flex items-center gap-3">
              {savedAt && (
                <span className="text-sm text-brand-600 flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4" />
                  ບັນທຶກສຳເລັດ!
                </span>
              )}
              <button onClick={handleSave} disabled={saving || !allMarked} className="btn-primary">
                {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
                {saving ? 'ກຳລັງບັນທຶກ...' : 'ບັນທຶກ'}
              </button>
            </div>
          </div>
        </>
      )}
    </div>
  );
}
