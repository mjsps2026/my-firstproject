import { useState, useEffect } from 'react';
import { supabase } from '../../lib/supabase';
import type { TeacherRow, ClassRow, StudentRow, ScheduleRow, AnnouncementRow } from '../../types';
import { DAYS, formatDate, ANNOUNCEMENT_CATEGORIES } from '../../constants';
import {
  School, Users, CalendarDays, ClipboardList, Megaphone, Clock,
  GraduationCap, BookOpen, ChevronRight,
} from 'lucide-react';

const CATEGORY_STYLES: Record<string, string> = {
  general: 'bg-ink-100 text-ink-600',
  event: 'bg-sky-50 text-sky-600',
  exam: 'bg-amber-50 text-amber-600',
  urgent: 'bg-red-50 text-red-600',
};

export default function TeacherOverview() {
  const [teacher, setTeacher] = useState<TeacherRow | null>(null);
  const [myClasses, setMyClasses] = useState<ClassRow[]>([]);
  const [myStudents, setMyStudents] = useState<StudentRow[]>([]);
  const [todaySchedule, setTodaySchedule] = useState<ScheduleRow[]>([]);
  const [announcements, setAnnouncements] = useState<AnnouncementRow[]>([]);
  const [classMap, setClassMap] = useState<Record<string, string>>({});
  const [pendingGrading, setPendingGrading] = useState(0);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      const { data: teachers } = await supabase
        .from('teachers')
        .select('*')
        .order('created_at', { ascending: true })
        .limit(1);
      const me = (teachers as TeacherRow[] | null)?.[0] || null;
      setTeacher(me);

      const { data: allClasses } = await supabase.from('classes').select('*').order('name');
      const classes = (allClasses as ClassRow[]) || [];
      setClassMap(Object.fromEntries(classes.map((c) => [c.id, c.name])));

      const mine = classes.filter((c) => c.homeroom_teacher_id === me?.id);
      setMyClasses(mine);
      const classIds = mine.map((c) => c.id);

      if (classIds.length > 0) {
        const { data: sts } = await supabase
          .from('students')
          .select('*')
          .in('class_id', classIds)
          .order('full_name');
        setMyStudents((sts as StudentRow[]) || []);

        const { count } = await supabase
          .from('assignments')
          .select('*', { count: 'exact', head: true })
          .in('class_id', classIds);
        setPendingGrading(count || 0);
      }

      const today = new Date();
      const dayIndex = (today.getDay() + 6) % 7;
      const todayLabel = dayIndex < DAYS.length ? DAYS[dayIndex] : '';
      if (me && todayLabel) {
        const { data: sch } = await supabase
          .from('schedule')
          .select('*')
          .eq('teacher_id', me.id)
          .eq('day', todayLabel)
          .order('period', { ascending: true });
        setTodaySchedule((sch as ScheduleRow[]) || []);
      }

      const { data: ann } = await supabase
        .from('announcements')
        .select('*')
        .in('audience', ['all', 'teachers'])
        .order('created_at', { ascending: false })
        .limit(5);
      setAnnouncements((ann as AnnouncementRow[]) || []);

      setLoading(false);
    })();
  }, []);

  if (loading) {
    return <div className="card p-8 text-center text-ink-400">ກຳລັງໂຫຼດ...</div>;
  }

  const stats = [
    {
      label: 'ຫ້ອງຮຽນຂອງຂ້ອຍ',
      value: myClasses.length,
      icon: School,
      color: 'bg-brand-50 text-brand-600',
    },
    {
      label: 'ນັກຮຽນຂອງຂ້ອຍ',
      value: myStudents.length,
      icon: Users,
      color: 'bg-sky-50 text-sky-600',
    },
    {
      label: 'ຕາຕະລາງມື້ນີ້',
      value: todaySchedule.length,
      icon: CalendarDays,
      color: 'bg-amber-50 text-amber-600',
    },
    {
      label: 'ລໍຖ້າໃຫ້ຄະແນນ',
      value: pendingGrading,
      icon: ClipboardList,
      color: 'bg-red-50 text-red-600',
    },
  ];

  return (
    <div>
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-ink-900">
          ສະບາຍດິ, {teacher?.full_name || 'ຄູອາຈານ'} 👋
        </h1>
        <p className="text-sm text-ink-400 mt-1">
          {teacher?.subject ? `ວິຊາ ${teacher.subject}` : 'ໜ້າຫຼັກຄູອາຈານ'}
        </p>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        {stats.map((s) => {
          const Icon = s.icon;
          return (
            <div key={s.label} className="card p-5 flex items-center gap-4">
              <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${s.color}`}>
                <Icon className="w-6 h-6" />
              </div>
              <div>
                <p className="text-2xl font-bold text-ink-900">{s.value}</p>
                <p className="text-xs text-ink-400">{s.label}</p>
              </div>
            </div>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 card p-5">
          <div className="flex items-center gap-2 mb-4">
            <CalendarDays className="w-5 h-5 text-brand-600" />
            <h2 className="text-lg font-semibold text-ink-900">ຕາຕະລາງມື້ນີ້</h2>
          </div>
          {todaySchedule.length === 0 ? (
            <div className="text-center py-8">
              <BookOpen className="w-10 h-10 text-ink-300 mx-auto mb-3" />
              <p className="text-ink-400">ມື້ນີ້ບໍ່ມີການສອນ</p>
            </div>
          ) : (
            <div className="space-y-2">
              {todaySchedule.map((s) => (
                <div
                  key={s.id}
                  className="flex items-center gap-4 p-3 rounded-xl bg-ink-50 border border-ink-100"
                >
                  <div className="flex items-center gap-1.5 text-xs text-ink-500 w-28 shrink-0">
                    <Clock className="w-3.5 h-3.5" />
                    {s.start_time} - {s.end_time}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-medium text-ink-900 text-sm">{s.subject}</p>
                    <p className="text-xs text-ink-400">
                      {classMap[s.class_id] || '—'}
                      {s.room ? ` · ຫ້ອງ ${s.room}` : ''}
                    </p>
                  </div>
                  <span className="chip bg-brand-50 text-brand-700">ໄລຍະ {s.period}</span>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="card p-5">
          <div className="flex items-center gap-2 mb-4">
            <Megaphone className="w-5 h-5 text-brand-600" />
            <h2 className="text-lg font-semibold text-ink-900">ປະກາດລ່າສຸດ</h2>
          </div>
          {announcements.length === 0 ? (
            <div className="text-center py-8">
              <Megaphone className="w-10 h-10 text-ink-300 mx-auto mb-3" />
              <p className="text-ink-400">ຍັງບໍ່ມີປະກາດ</p>
            </div>
          ) : (
            <div className="space-y-3">
              {announcements.map((a) => {
                const cat = ANNOUNCEMENT_CATEGORIES.find((c) => c.value === a.category);
                return (
                  <div key={a.id} className="p-3 rounded-xl border border-ink-100 hover:bg-ink-50 transition-colors">
                    <div className="flex items-start justify-between gap-2 mb-1">
                      <p className="font-medium text-ink-900 text-sm line-clamp-1">{a.title}</p>
                      <span className={`chip shrink-0 ${CATEGORY_STYLES[a.category] || 'bg-ink-100 text-ink-600'}`}>
                        {cat?.label || a.category}
                      </span>
                    </div>
                    <p className="text-xs text-ink-400 line-clamp-2">{a.content}</p>
                    <p className="text-xs text-ink-300 mt-1.5">{formatDate(a.created_at)}</p>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-6">
        <div className="card p-5">
          <div className="flex items-center gap-2 mb-4">
            <School className="w-5 h-5 text-brand-600" />
            <h2 className="text-lg font-semibold text-ink-900">ຫ້ອງຮຽນຂອງຂ້ອຍ</h2>
          </div>
          {myClasses.length === 0 ? (
            <div className="text-center py-6">
              <GraduationCap className="w-10 h-10 text-ink-300 mx-auto mb-3" />
              <p className="text-ink-400">ທ່ານບໍ່ໄດ້ເປັນຄູປະຈຳຫ້ອງ</p>
            </div>
          ) : (
            <div className="space-y-2">
              {myClasses.map((c) => {
                const count = myStudents.filter((s) => s.class_id === c.id).length;
                return (
                  <div key={c.id} className="flex items-center justify-between p-3 rounded-xl bg-ink-50">
                    <div className="flex items-center gap-3">
                      <div className="w-9 h-9 rounded-lg bg-brand-100 flex items-center justify-center">
                        <School className="w-4 h-4 text-brand-600" />
                      </div>
                      <div>
                        <p className="font-medium text-ink-900 text-sm">{c.name}</p>
                        <p className="text-xs text-ink-400">
                          {c.level === 'preschool' ? 'ອະນຸບານ' : 'ປະຖົມ'}
                          {c.grade_level ? ` · ${c.grade_level}` : ''}
                        </p>
                      </div>
                    </div>
                    <span className="chip bg-sky-50 text-sky-600">
                      <Users className="w-3 h-3" />
                      {count} ນັກຮຽນ
                    </span>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        <div className="card p-5">
          <div className="flex items-center gap-2 mb-4">
            <ClipboardList className="w-5 h-5 text-brand-600" />
            <h2 className="text-lg font-semibold text-ink-900">ວຽກງານຄະແນນ</h2>
          </div>
          <div className="p-4 rounded-xl bg-amber-50 border border-amber-100">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-amber-100 flex items-center justify-center">
                <ClipboardList className="w-5 h-5 text-amber-600" />
              </div>
              <div>
                <p className="text-2xl font-bold text-amber-700">{pendingGrading}</p>
                <p className="text-xs text-amber-600">ບົດສົງຕອບແທນລໍຖ້າໃຫ້ຄະແນນ</p>
              </div>
            </div>
          </div>
          <p className="text-xs text-ink-400 mt-3">
            ກົດເມນູ "ຄະແນນ" ເພື່ອເຂົ້າໄປບັນທຶກຄະແນນນັກຮຽນ
            <ChevronRight className="w-3 h-3 inline ml-1" />
          </p>
        </div>
      </div>
    </div>
  );
}
