export type Role = 'admin' | 'teacher' | 'student';

export interface ClassRow {
  id: string;
  name: string;
  level: 'preschool' | 'primary';
  grade_level: string | null;
  homeroom_teacher_id: string | null;
  created_at: string;
}

export interface TeacherRow {
  id: string;
  full_name: string;
  email: string | null;
  phone: string | null;
  subject: string | null;
  gender: 'male' | 'female' | null;
  photo_url: string | null;
  status: string;
  created_at: string;
}

export interface StudentRow {
  id: string;
  full_name: string;
  class_id: string | null;
  gender: 'male' | 'female' | null;
  birth_date: string | null;
  parent_name: string | null;
  parent_phone: string | null;
  address: string | null;
  photo_url: string | null;
  status: string;
  admission_date: string | null;
  created_at: string;
}

export interface AttendanceRow {
  id: string;
  student_id: string;
  class_id: string;
  date: string;
  status: string;
  note: string | null;
  created_at: string;
}

export interface GradeRow {
  id: string;
  student_id: string;
  class_id: string;
  subject: string;
  term: string;
  score: number;
  max_score: number;
  grade_letter: string;
  created_at: string;
}

export interface BehaviorRow {
  id: string;
  student_id: string;
  class_id: string;
  date: string;
  type: 'positive' | 'negative';
  description: string;
  points: number;
  created_at: string;
}

export interface AnnouncementRow {
  id: string;
  title: string;
  content: string;
  category: string;
  audience: string;
  author: string | null;
  created_at: string;
}

export interface ScheduleRow {
  id: string;
  class_id: string;
  day: string;
  period: number;
  subject: string;
  teacher_id: string | null;
  start_time: string;
  end_time: string;
  room: string | null;
}

export interface AssignmentRow {
  id: string;
  class_id: string;
  subject: string;
  title: string;
  description: string | null;
  due_date: string | null;
  max_score: number;
  created_at: string;
}

export interface TuitionRow {
  id: string;
  student_id: string;
  term: string;
  amount: number;
  paid_amount: number;
  status: string;
  due_date: string | null;
  paid_date: string | null;
  method: string | null;
  note: string | null;
  invoice_number: string | null;
  sms_sent_at: string | null;
  sms_sent_count: number;
  created_at: string;
}

export interface TuitionWithStudent extends TuitionRow {
  student_name?: string;
  class_name?: string;
  parent_name?: string | null;
  parent_phone?: string | null;
}

export type SlipStatus = 'pending' | 'approved' | 'rejected';

export interface PaymentSlipRow {
  id: string;
  tuition_id: string | null;
  student_id: string;
  slip_url: string;
  amount: number;
  status: SlipStatus;
  uploaded_at: string;
  reviewed_at: string | null;
  reviewed_by: string | null;
  admin_note: string | null;
  created_at: string;
}

export interface PaymentSlipWithStudent extends PaymentSlipRow {
  student_name?: string;
  student_full_name?: string;
  term?: string;
}

export interface BankConfigRow {
  id: string;
  bank_name: string;
  account_name: string;
  account_number: string;
  is_static: boolean;
  qr_payload: string | null;
  active: boolean;
  created_at: string;
}
