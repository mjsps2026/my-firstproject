/*
# Smart School Web App - Core Schema

Creates the complete database for a school management system with three
role-based dashboards (Admin/Principal, Teacher, Student/Parent).

## 1. New Tables

- `classes`: Classrooms grouped by level (preschool "ອບ" and primary "ປ").
  Columns: id, name, level, grade_level, homeroom_teacher_id, created_at.
- `teachers`: Teacher profiles with subject and contact info.
  Columns: id, full_name, email, phone, subject, gender, photo_url, hire_date, status, created_at.
- `students`: Student profiles linked to a class and parent/guardian.
  Columns: id, full_name, class_id, gender, birth_date, parent_name, parent_phone, address, photo_url, status, admission_date, created_at.
- `attendance`: Daily per-student attendance (present/absent/late/leave).
  Columns: id, student_id, class_id, date, status, marked_by, note, created_at.
- `grades`: Per-subject assessment scores (quiz/homework/exam).
  Columns: id, student_id, subject, term, assessment_type, score, max_score, date, teacher_id, created_at.
- `behavior_records`: Positive/negative behavior notes with a score.
  Columns: id, student_id, date, type, score, description, recorded_by, created_at.
- `announcements`: School-wide notices targeted to audiences.
  Columns: id, title, content, category, audience, author, created_at.
- `schedule`: Weekly class timetable entries.
  Columns: id, class_id, day_of_week, period, subject, teacher_id, start_time, end_time, room, created_at.
- `assignments`: Homework/assignments given to a class.
  Columns: id, class_id, subject, title, description, due_date, assigned_by, created_at.
- `tuition`: Tuition fee tracking per student per term.
  Columns: id, student_id, term, amount, paid_amount, status, due_date, paid_date, method, note, created_at.

## 2. Relationships

- students.class_id -> classes.id (CASCADE)
- attendance.student_id -> students.id (CASCADE)
- attendance.class_id -> classes.id (CASCADE)
- grades.student_id -> students.id (CASCADE)
- behavior_records.student_id -> students.id (CASCADE)
- schedule.class_id -> classes.id (CASCADE)
- schedule.teacher_id -> teachers.id (SET NULL)
- assignments.class_id -> classes.id (CASCADE)
- assignments.assigned_by -> teachers.id (SET NULL)
- tuition.student_id -> students.id (CASCADE)
- classes.homeroom_teacher_id -> teachers.id (SET NULL)
- attendance.marked_by -> teachers.id (SET NULL)
- behavior_records.recorded_by -> teachers.id (SET NULL)

## 3. Indexes

- students.class_id (frequent class roster queries)
- attendance(student_id, date) (attendance history lookups)
- attendance(class_id, date) (mark attendance by class+day)
- grades(student_id, subject) (report card lookup)
- tuition.student_id (payment summary per student)

## 4. Security

This is a single-tenant demo app with a role switcher (no real auth).
All tables use RLS with TO anon, authenticated and USING (true) / WITH CHECK (true)
because the data is intentionally shared/public for the demo. The role switcher
is a client-side view filter, not a server-side identity.
*/

-- Classes
CREATE TABLE IF NOT EXISTS classes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  level text NOT NULL CHECK (level IN ('preschool', 'primary')),
  grade_level text,
  homeroom_teacher_id uuid,
  created_at timestamptz DEFAULT now()
);
ALTER TABLE classes ENABLE ROW LEVEL SECURITY;

-- Teachers
CREATE TABLE IF NOT EXISTS teachers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  full_name text NOT NULL,
  email text,
  phone text,
  subject text,
  gender text CHECK (gender IN ('male', 'female')),
  photo_url text,
  hire_date date,
  status text NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'inactive')),
  created_at timestamptz DEFAULT now()
);
ALTER TABLE teachers ENABLE ROW LEVEL SECURITY;

-- Students
CREATE TABLE IF NOT EXISTS students (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  full_name text NOT NULL,
  class_id uuid REFERENCES classes(id) ON DELETE CASCADE,
  gender text CHECK (gender IN ('male', 'female')),
  birth_date date,
  parent_name text,
  parent_phone text,
  address text,
  photo_url text,
  status text NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'inactive')),
  admission_date date DEFAULT CURRENT_DATE,
  created_at timestamptz DEFAULT now()
);
ALTER TABLE students ENABLE ROW LEVEL SECURITY;

-- Attendance
CREATE TABLE IF NOT EXISTS attendance (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id uuid NOT NULL REFERENCES students(id) ON DELETE CASCADE,
  class_id uuid REFERENCES classes(id) ON DELETE CASCADE,
  date date NOT NULL DEFAULT CURRENT_DATE,
  status text NOT NULL CHECK (status IN ('present', 'absent', 'late', 'leave')),
  marked_by uuid REFERENCES teachers(id) ON DELETE SET NULL,
  note text,
  created_at timestamptz DEFAULT now(),
  UNIQUE (student_id, date)
);
ALTER TABLE attendance ENABLE ROW LEVEL SECURITY;

-- Grades
CREATE TABLE IF NOT EXISTS grades (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id uuid NOT NULL REFERENCES students(id) ON DELETE CASCADE,
  subject text NOT NULL,
  term text NOT NULL,
  assessment_type text NOT NULL CHECK (assessment_type IN ('quiz', 'homework', 'exam', 'midterm', 'final')),
  score numeric NOT NULL DEFAULT 0,
  max_score numeric NOT NULL DEFAULT 100,
  date date DEFAULT CURRENT_DATE,
  teacher_id uuid REFERENCES teachers(id) ON DELETE SET NULL,
  created_at timestamptz DEFAULT now()
);
ALTER TABLE grades ENABLE ROW LEVEL SECURITY;

-- Behavior records
CREATE TABLE IF NOT EXISTS behavior_records (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id uuid NOT NULL REFERENCES students(id) ON DELETE CASCADE,
  date date NOT NULL DEFAULT CURRENT_DATE,
  type text NOT NULL CHECK (type IN ('positive', 'negative')),
  score int NOT NULL DEFAULT 1,
  description text NOT NULL,
  recorded_by uuid REFERENCES teachers(id) ON DELETE SET NULL,
  created_at timestamptz DEFAULT now()
);
ALTER TABLE behavior_records ENABLE ROW LEVEL SECURITY;

-- Announcements
CREATE TABLE IF NOT EXISTS announcements (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  content text NOT NULL,
  category text NOT NULL DEFAULT 'general' CHECK (category IN ('general', 'event', 'urgent', 'holiday', 'exam')),
  audience text NOT NULL DEFAULT 'all' CHECK (audience IN ('all', 'teachers', 'students')),
  author text,
  created_at timestamptz DEFAULT now()
);
ALTER TABLE announcements ENABLE ROW LEVEL SECURITY;

-- Schedule
CREATE TABLE IF NOT EXISTS schedule (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  class_id uuid NOT NULL REFERENCES classes(id) ON DELETE CASCADE,
  day_of_week int NOT NULL CHECK (day_of_week BETWEEN 0 AND 6),
  period int NOT NULL CHECK (period BETWEEN 1 AND 10),
  subject text NOT NULL,
  teacher_id uuid REFERENCES teachers(id) ON DELETE SET NULL,
  start_time time,
  end_time time,
  room text,
  created_at timestamptz DEFAULT now(),
  UNIQUE (class_id, day_of_week, period)
);
ALTER TABLE schedule ENABLE ROW LEVEL SECURITY;

-- Assignments
CREATE TABLE IF NOT EXISTS assignments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  class_id uuid NOT NULL REFERENCES classes(id) ON DELETE CASCADE,
  subject text NOT NULL,
  title text NOT NULL,
  description text,
  due_date date,
  assigned_by uuid REFERENCES teachers(id) ON DELETE SET NULL,
  created_at timestamptz DEFAULT now()
);
ALTER TABLE assignments ENABLE ROW LEVEL SECURITY;

-- Tuition
CREATE TABLE IF NOT EXISTS tuition (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id uuid NOT NULL REFERENCES students(id) ON DELETE CASCADE,
  term text NOT NULL,
  amount numeric NOT NULL DEFAULT 0,
  paid_amount numeric NOT NULL DEFAULT 0,
  status text NOT NULL DEFAULT 'unpaid' CHECK (status IN ('paid', 'partial', 'unpaid')),
  due_date date,
  paid_date date,
  method text CHECK (method IN ('cash', 'bank_transfer', 'card', 'other')),
  note text,
  created_at timestamptz DEFAULT now()
);
ALTER TABLE tuition ENABLE ROW LEVEL SECURITY;

-- Wire up homeroom teacher FK now that teachers exists
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.table_constraints
    WHERE constraint_name = 'classes_homeroom_teacher_id_fkey'
  ) THEN
    ALTER TABLE classes
      ADD CONSTRAINT classes_homeroom_teacher_id_fkey
      FOREIGN KEY (homeroom_teacher_id) REFERENCES teachers(id) ON DELETE SET NULL;
  END IF;
END $$;

-- Indexes
CREATE INDEX IF NOT EXISTS idx_students_class_id ON students(class_id);
CREATE INDEX IF NOT EXISTS idx_attendance_student_date ON attendance(student_id, date);
CREATE INDEX IF NOT EXISTS idx_attendance_class_date ON attendance(class_id, date);
CREATE INDEX IF NOT EXISTS idx_grades_student_subject ON grades(student_id, subject);
CREATE INDEX IF NOT EXISTS idx_tuition_student ON tuition(student_id);
CREATE INDEX IF NOT EXISTS idx_schedule_class_day ON schedule(class_id, day_of_week);

-- ===== RLS Policies (single-tenant demo: anon + authenticated, shared data) =====

-- classes
DROP POLICY IF EXISTS "anon_crud_classes" ON classes;
CREATE POLICY "anon_crud_classes" ON classes FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_ins_classes" ON classes;
CREATE POLICY "anon_ins_classes" ON classes FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_upd_classes" ON classes;
CREATE POLICY "anon_upd_classes" ON classes FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_del_classes" ON classes;
CREATE POLICY "anon_del_classes" ON classes FOR DELETE TO anon, authenticated USING (true);

-- teachers
DROP POLICY IF EXISTS "anon_sel_teachers" ON teachers;
CREATE POLICY "anon_sel_teachers" ON teachers FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_ins_teachers" ON teachers;
CREATE POLICY "anon_ins_teachers" ON teachers FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_upd_teachers" ON teachers;
CREATE POLICY "anon_upd_teachers" ON teachers FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_del_teachers" ON teachers;
CREATE POLICY "anon_del_teachers" ON teachers FOR DELETE TO anon, authenticated USING (true);

-- students
DROP POLICY IF EXISTS "anon_sel_students" ON students;
CREATE POLICY "anon_sel_students" ON students FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_ins_students" ON students;
CREATE POLICY "anon_ins_students" ON students FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_upd_students" ON students;
CREATE POLICY "anon_upd_students" ON students FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_del_students" ON students;
CREATE POLICY "anon_del_students" ON students FOR DELETE TO anon, authenticated USING (true);

-- attendance
DROP POLICY IF EXISTS "anon_sel_attendance" ON attendance;
CREATE POLICY "anon_sel_attendance" ON attendance FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_ins_attendance" ON attendance;
CREATE POLICY "anon_ins_attendance" ON attendance FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_upd_attendance" ON attendance;
CREATE POLICY "anon_upd_attendance" ON attendance FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_del_attendance" ON attendance;
CREATE POLICY "anon_del_attendance" ON attendance FOR DELETE TO anon, authenticated USING (true);

-- grades
DROP POLICY IF EXISTS "anon_sel_grades" ON grades;
CREATE POLICY "anon_sel_grades" ON grades FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_ins_grades" ON grades;
CREATE POLICY "anon_ins_grades" ON grades FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_upd_grades" ON grades;
CREATE POLICY "anon_upd_grades" ON grades FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_del_grades" ON grades;
CREATE POLICY "anon_del_grades" ON grades FOR DELETE TO anon, authenticated USING (true);

-- behavior_records
DROP POLICY IF EXISTS "anon_sel_behavior" ON behavior_records;
CREATE POLICY "anon_sel_behavior" ON behavior_records FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_ins_behavior" ON behavior_records;
CREATE POLICY "anon_ins_behavior" ON behavior_records FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_upd_behavior" ON behavior_records;
CREATE POLICY "anon_upd_behavior" ON behavior_records FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_del_behavior" ON behavior_records;
CREATE POLICY "anon_del_behavior" ON behavior_records FOR DELETE TO anon, authenticated USING (true);

-- announcements
DROP POLICY IF EXISTS "anon_sel_announcements" ON announcements;
CREATE POLICY "anon_sel_announcements" ON announcements FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_ins_announcements" ON announcements;
CREATE POLICY "anon_ins_announcements" ON announcements FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_upd_announcements" ON announcements;
CREATE POLICY "anon_upd_announcements" ON announcements FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_del_announcements" ON announcements;
CREATE POLICY "anon_del_announcements" ON announcements FOR DELETE TO anon, authenticated USING (true);

-- schedule
DROP POLICY IF EXISTS "anon_sel_schedule" ON schedule;
CREATE POLICY "anon_sel_schedule" ON schedule FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_ins_schedule" ON schedule;
CREATE POLICY "anon_ins_schedule" ON schedule FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_upd_schedule" ON schedule;
CREATE POLICY "anon_upd_schedule" ON schedule FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_del_schedule" ON schedule;
CREATE POLICY "anon_del_schedule" ON schedule FOR DELETE TO anon, authenticated USING (true);

-- assignments
DROP POLICY IF EXISTS "anon_sel_assignments" ON assignments;
CREATE POLICY "anon_sel_assignments" ON assignments FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_ins_assignments" ON assignments;
CREATE POLICY "anon_ins_assignments" ON assignments FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_upd_assignments" ON assignments;
CREATE POLICY "anon_upd_assignments" ON assignments FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_del_assignments" ON assignments;
CREATE POLICY "anon_del_assignments" ON assignments FOR DELETE TO anon, authenticated USING (true);

-- tuition
DROP POLICY IF EXISTS "anon_sel_tuition" ON tuition;
CREATE POLICY "anon_sel_tuition" ON tuition FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_ins_tuition" ON tuition;
CREATE POLICY "anon_ins_tuition" ON tuition FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_upd_tuition" ON tuition;
CREATE POLICY "anon_upd_tuition" ON tuition FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_del_tuition" ON tuition;
CREATE POLICY "anon_del_tuition" ON tuition FOR DELETE TO anon, authenticated USING (true);
