/*
# Bank QR Payment & Slip Verification System

Adds payment slip upload tracking and bank configuration for QR-based tuition payments.

## 1. New Tables

- `payment_slips`: Records of bank transfer slip uploads from students/parents.
  Columns: id, tuition_id (FK), student_id (FK), slip_url, amount, status (pending/approved/rejected),
  uploaded_at, reviewed_at, reviewed_by, admin_note.
- `bank_config`: Single-row school bank account configuration for QR payment generation.
  Columns: id, bank_name, account_name, account_number, is_static, qr_payload, active.

## 2. Relationships

- payment_slips.tuition_id -> tuition.id (CASCADE)
- payment_slips.student_id -> students.id (CASCADE)

## 3. Security

Single-tenant demo app: RLS enabled, TO anon + authenticated, USING(true) / WITH CHECK(true).
All tables are intentionally shared/public.
*/

-- payment_slips
CREATE TABLE IF NOT EXISTS payment_slips (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tuition_id uuid REFERENCES tuition(id) ON DELETE CASCADE,
  student_id uuid NOT NULL REFERENCES students(id) ON DELETE CASCADE,
  slip_url text NOT NULL,
  amount numeric NOT NULL DEFAULT 0,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected')),
  uploaded_at timestamptz DEFAULT now(),
  reviewed_at timestamptz,
  reviewed_by text,
  admin_note text,
  created_at timestamptz DEFAULT now()
);
ALTER TABLE payment_slips ENABLE ROW LEVEL SECURITY;

-- bank_config
CREATE TABLE IF NOT EXISTS bank_config (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  bank_name text NOT NULL DEFAULT 'ທະນາຄານການຄ້ານອກແຫ່ງປະເທດລາວ',
  account_name text NOT NULL DEFAULT 'ໂຮງຮຽນສຸກປະເສີດ',
  account_number text NOT NULL DEFAULT '0101234567890',
  is_static boolean NOT NULL DEFAULT false,
  qr_payload text,
  active boolean NOT NULL DEFAULT true,
  created_at timestamptz DEFAULT now()
);
ALTER TABLE bank_config ENABLE ROW LEVEL SECURITY;

-- Indexes
CREATE INDEX IF NOT EXISTS idx_payment_slips_tuition ON payment_slips(tuition_id);
CREATE INDEX IF NOT EXISTS idx_payment_slips_status ON payment_slips(status);

-- RLS policies (shared demo data)
DROP POLICY IF EXISTS "anon_sel_payment_slips" ON payment_slips;
CREATE POLICY "anon_sel_payment_slips" ON payment_slips FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_ins_payment_slips" ON payment_slips;
CREATE POLICY "anon_ins_payment_slips" ON payment_slips FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_upd_payment_slips" ON payment_slips;
CREATE POLICY "anon_upd_payment_slips" ON payment_slips FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_del_payment_slips" ON payment_slips;
CREATE POLICY "anon_del_payment_slips" ON payment_slips FOR DELETE TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_sel_bank_config" ON bank_config;
CREATE POLICY "anon_sel_bank_config" ON bank_config FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_ins_bank_config" ON bank_config;
CREATE POLICY "anon_ins_bank_config" ON bank_config FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_upd_bank_config" ON bank_config;
CREATE POLICY "anon_upd_bank_config" ON bank_config FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_del_bank_config" ON bank_config;
CREATE POLICY "anon_del_bank_config" ON bank_config FOR DELETE TO anon, authenticated USING (true);

-- Seed default bank config (only if none exists)
INSERT INTO bank_config (bank_name, account_name, account_number, is_static, qr_payload, active)
SELECT 'ທະນາຄານການຄ້ານອກແຫ່ງປະເທດລາວ', 'ໂຮງຮຽນສຸກປະເສີດ', '0101234567890', false, null, true
WHERE NOT EXISTS (SELECT 1 FROM bank_config WHERE active = true);
