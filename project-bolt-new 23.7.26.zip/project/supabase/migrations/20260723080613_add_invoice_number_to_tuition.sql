/*
# Add invoice number to tuition table

1. Modified Tables
- `tuition`: Added `invoice_number` (text, unique) — auto-generated invoice number for each tuition record (format: INV-YYYYMM-XXXX)
- `tuition`: Added `sms_sent_at` (timestamptz, nullable) — tracks when SMS payment notification was last sent to parent
- `tuition`: Added `sms_sent_count` (int, default 0) — tracks number of SMS notifications sent

2. Indexes
- Unique index on `invoice_number` for fast lookups

3. Security
- No RLS policy changes (table already has anon+authenticated CRUD policies from previous migration)

4. Important Notes
- invoice_number is nullable so existing records won't break
- New invoices should be generated with format INV-YYYYMM-XXXX (e.g., INV-202607-0001)
- SMS notification tracking is for display purposes only (actual SMS sending would require external API)
*/
ALTER TABLE tuition ADD COLUMN IF NOT EXISTS invoice_number text;
ALTER TABLE tuition ADD COLUMN IF NOT EXISTS sms_sent_at timestamptz;
ALTER TABLE tuition ADD COLUMN IF NOT EXISTS sms_sent_count integer NOT NULL DEFAULT 0;

CREATE UNIQUE INDEX IF NOT EXISTS idx_tuition_invoice_number ON tuition(invoice_number) WHERE invoice_number IS NOT NULL;